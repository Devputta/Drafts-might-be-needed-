import type { Config } from 'tailwindcss';
const config: Config = { content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'], theme: { extend: { colors: { ink:'#172033', muted:'#667085', line:'#e5e7eb', paper:'#f7f8fa', accent:'#275dad', warm:'#f4a261' }, boxShadow:{soft:'0 10px 30px rgba(23,32,51,.07)'} } }, plugins:[] };
export default config;
