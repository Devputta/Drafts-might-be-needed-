# CampusConnect Web

A realistic web-first local college events platform based on the uploaded CampusConnect Android feature set.

## Features in this starter
- Event discovery
- Search and category filters
- Event detail modal
- Registration flow
- QR ticket generation
- Organizer event creation
- Responsive desktop/tablet/mobile layout
- Local demo data

## Run

1. Install Node.js 18+.
2. Open this folder in a terminal.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open the local URL shown by Next.js.

## Next production steps
- Supabase authentication
- PostgreSQL event/registration tables
- Organizer/admin roles
- Real email confirmations
- QR scanner using device camera
- My Tickets page
- Organizer dashboard
- Admin moderation
- Event reports
- College/location profiles
- Image upload
- Rate limiting and RLS

The initial UI deliberately avoids fake AI-style visuals and fake statistics.
