import './globals.css';
export const metadata={title:'CampusConnect — Local College Events',description:'Discover, register for, and manage events across your college campus.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
