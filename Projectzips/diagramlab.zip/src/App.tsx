import React, { useState, useEffect } from 'react';
import { DiagramProject } from './types/diagram';
import {
  loadProjects,
  saveProject,
  getProject,
  getActiveProjectId,
  createNewProject,
  duplicateProject,
  deleteProject,
} from './lib/storage';
import { TEMPLATE_CATALOG } from './templates/catalog';
import { LandingView } from './components/views/LandingView';
import { DashboardView } from './components/views/DashboardView';
import { EditorView } from './components/views/EditorView';
import { TemplatesModal } from './components/dialogs/TemplatesModal';

export default function App() {
  const [view, setView] = useState<'editor' | 'dashboard' | 'landing'>('editor');
  const [projects, setProjects] = useState<DiagramProject[]>([]);
  const [currentProject, setCurrentProject] = useState<DiagramProject | null>(null);
  const [globalTemplatesOpen, setGlobalTemplatesOpen] = useState(false);

  // Initialize projects on load
  useEffect(() => {
    const loaded = loadProjects();
    setProjects(loaded);

    const activeId = getActiveProjectId();
    const active = loaded.find((p) => p.id === activeId) || loaded[0] || createNewProject();
    setCurrentProject(active);
  }, []);

  const handleCreateNewProject = () => {
    const newProj = createNewProject('New Technical Diagram');
    saveProject(newProj);
    const updated = loadProjects();
    setProjects(updated);
    setCurrentProject(newProj);
    setView('editor');
  };

  const handleOpenProject = (id: string) => {
    const target = getProject(id);
    if (target) {
      setCurrentProject(target);
      setView('editor');
    }
  };

  const handleDuplicateProject = (id: string) => {
    const copy = duplicateProject(id);
    if (copy) {
      const updated = loadProjects();
      setProjects(updated);
    }
  };

  const handleDeleteProject = (id: string) => {
    deleteProject(id);
    const updated = loadProjects();
    setProjects(updated);
    if (currentProject?.id === id) {
      setCurrentProject(updated[0] || null);
    }
  };

  const handleRenameProject = (id: string, newName: string) => {
    const target = getProject(id);
    if (target) {
      const updatedProj = { ...target, name: newName, updatedAt: new Date().toISOString() };
      saveProject(updatedProj);
      const updatedList = loadProjects();
      setProjects(updatedList);
      if (currentProject?.id === id) {
        setCurrentProject(updatedProj);
      }
    }
  };

  const handleImportProject = (imported: DiagramProject) => {
    saveProject(imported);
    const updated = loadProjects();
    setProjects(updated);
    setCurrentProject(imported);
    setView('editor');
  };

  const handleSelectTemplateFromLanding = (templateId: string) => {
    const tpl = TEMPLATE_CATALOG.find((t) => t.id === templateId) || TEMPLATE_CATALOG[0];
    const newProj = createNewProject(
      tpl.name,
      JSON.parse(JSON.stringify(tpl.page))
    );
    saveProject(newProj);
    const updated = loadProjects();
    setProjects(updated);
    setCurrentProject(newProj);
    setView('editor');
  };

  if (!currentProject) {
    return (
      <div className="w-screen h-screen flex items-center justify-center bg-slate-50 text-slate-600 text-xs">
        Loading DiagramLab workspace...
      </div>
    );
  }

  return (
    <div className="w-screen h-screen overflow-hidden flex flex-col font-sans">
      {view === 'landing' ? (
        <LandingView
          onOpenEditor={() => setView('editor')}
          onOpenDashboard={() => setView('dashboard')}
          onSelectTemplate={handleSelectTemplateFromLanding}
        />
      ) : view === 'dashboard' ? (
        <div className="flex flex-col h-full">
          {/* Dashboard Mini Top Bar */}
          <header className="h-13 bg-white border-b border-slate-200 px-4 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setView('landing')}
                className="w-8 h-8 rounded bg-slate-900 flex items-center justify-center text-white font-mono font-bold text-sm"
              >
                DL
              </button>
              <span className="font-bold text-slate-900 text-sm">DiagramLab</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setView('editor')}
                className="text-xs px-3 py-1.5 rounded-md border border-slate-200 text-slate-700 hover:bg-slate-50 font-medium"
              >
                Return to Canvas
              </button>
              <button
                onClick={handleCreateNewProject}
                className="text-xs px-3.5 py-1.5 rounded-md bg-slate-900 text-white font-semibold hover:bg-slate-800"
              >
                + New Diagram
              </button>
            </div>
          </header>

          <DashboardView
            projects={projects}
            onOpenProject={handleOpenProject}
            onCreateProject={handleCreateNewProject}
            onDuplicateProject={handleDuplicateProject}
            onDeleteProject={handleDeleteProject}
            onRenameProject={handleRenameProject}
            onImportProject={handleImportProject}
            onOpenTemplates={() => setGlobalTemplatesOpen(true)}
          />
        </div>
      ) : (
        <EditorView
          project={currentProject}
          onUpdateProject={(updated) => {
            setCurrentProject(updated);
            setProjects((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
          }}
          onNavigateView={setView}
        />
      )}

      {/* Global Templates Modal when called from Dashboard */}
      <TemplatesModal
        isOpen={globalTemplatesOpen}
        onClose={() => setGlobalTemplatesOpen(false)}
        onApplyTemplate={(template) => {
          handleSelectTemplateFromLanding(template.id);
          setGlobalTemplatesOpen(false);
        }}
      />
    </div>
  );
}
