import { DiagramPage, DiagramNode, DiagramEdge } from '../types/diagram';
import { computeEdgePath } from './geometry';

export interface ExportOptions {
  format: 'svg' | 'png' | 'pdf' | 'json';
  scale?: 1 | 2 | 3;
  background?: 'white' | 'transparent';
  includeAcademicCaption?: boolean;
}

export function buildStandaloneSvgString(
  page: DiagramPage,
  options: { background?: 'white' | 'transparent'; includeAcademicCaption?: boolean }
): string {
  const { width, height, nodes, edges, figureNumber, figureCaption, captionPosition } = page;
  const isTransparent = options.background === 'transparent';
  const includeCaption = options.includeAcademicCaption && figureCaption;

  const captionHeight = includeCaption ? 48 : 0;
  const totalHeight = height + captionHeight;
  const captionY = captionPosition === 'above' ? 32 : height + 32;
  const diagramOffsetY = captionPosition === 'above' && includeCaption ? captionHeight : 0;

  // Arrow markers definition
  const defs = `
    <defs>
      <marker id="dl-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
        <path d="M 0 1.5 L 10 5 L 0 8.5 z" fill="#334155" />
      </marker>
      <marker id="dl-arrow-active" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
        <path d="M 0 1.5 L 10 5 L 0 8.5 z" fill="#0284c7" />
      </marker>
      <marker id="dl-circle" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6">
        <circle cx="5" cy="5" r="3.5" fill="#334155" />
      </marker>
      <style>
        .dl-text { font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; }
        .dl-caption { font-family: ui-serif, Georgia, Cambria, "Times New Roman", Times, serif; }
      </style>
    </defs>
  `;

  // Background rect
  const bg = isTransparent
    ? ''
    : `<rect width="${width}" height="${totalHeight}" fill="${page.background || '#ffffff'}" />`;

  // Render Edges
  const nodeMap = new Map<string, DiagramNode>(nodes.map((n) => [n.id, n]));
  const edgesSvg = edges
    .map((edge: DiagramEdge) => {
      const sNode = nodeMap.get(edge.source);
      const tNode = nodeMap.get(edge.target);
      if (!sNode || !tNode) return '';

      const { pathString, labelPoint } = computeEdgePath(edge, sNode, tNode);
      const dash =
        edge.strokeStyle === 'dashed'
          ? 'stroke-dasharray="6,4"'
          : edge.strokeStyle === 'dotted'
            ? 'stroke-dasharray="2,3"'
            : '';
      const markerEnd = edge.arrowType !== 'none' ? 'marker-end="url(#dl-arrow)"' : '';
      const markerStart =
        edge.arrowType === 'double-arrow' ? 'marker-start="url(#dl-arrow)"' : '';

      let labelSvg = '';
      if (edge.label) {
        const textW = Math.max(40, edge.label.length * 7.5 + 16);
        labelSvg = `
          <g transform="translate(${labelPoint.x}, ${labelPoint.y + diagramOffsetY})">
            <rect x="${-textW / 2}" y="-10" width="${textW}" height="20" rx="4" fill="#ffffff" stroke="#cbd5e1" stroke-width="1" />
            <text class="dl-text" x="0" y="4" text-anchor="middle" font-size="11" fill="#475569" font-weight="500">${escapeXml(edge.label)}</text>
          </g>
        `;
      }

      return `
        <g class="dl-edge">
          <path d="${pathString}" fill="none" stroke="${edge.stroke || '#334155'}" stroke-width="${edge.strokeWidth || 1.5}" ${dash} ${markerEnd} ${markerStart} transform="translate(0, ${diagramOffsetY})" />
          ${labelSvg}
        </g>
      `;
    })
    .join('\n');

  // Render Nodes
  const nodesSvg = nodes
    .filter((n) => !n.hidden)
    .sort((a, b) => a.zIndex - b.zIndex)
    .map((node: DiagramNode) => {
      const nodeX = node.x;
      const nodeY = node.y + diagramOffsetY;
      const w = node.width;
      const h = node.height;
      const fill = node.fill || '#ffffff';
      const stroke = node.stroke || '#334155';
      const sw = node.strokeWidth || 2;
      const r = node.cornerRadius || 4;
      const dash =
        node.strokeStyle === 'dashed'
          ? 'stroke-dasharray="6,4"'
          : node.strokeStyle === 'dotted'
            ? 'stroke-dasharray="2,3"'
            : '';

      let shapeGeometry = '';
      if (node.type === 'circle') {
        const rad = Math.min(w, h) / 2 - sw;
        shapeGeometry = `<circle cx="${w / 2}" cy="${h / 2}" r="${rad}" fill="${fill}" stroke="${stroke}" stroke-width="${sw}" ${dash} />`;
      } else if (node.type === 'ellipse' || node.type === 'uml-use-case') {
        shapeGeometry = `<ellipse cx="${w / 2}" cy="${h / 2}" rx="${w / 2 - sw}" ry="${h / 2 - sw}" fill="${fill}" stroke="${stroke}" stroke-width="${sw}" ${dash} />`;
      } else if (node.type === 'diamond' || node.type === 'flow-decision') {
        shapeGeometry = `<polygon points="${w / 2},${sw} ${w - sw},${h / 2} ${w / 2},${h - sw} ${sw},${h / 2}" fill="${fill}" stroke="${stroke}" stroke-width="${sw}" ${dash} />`;
      } else if (node.type === 'cylinder' || node.type === 'soft-database' || node.type === 'flow-database') {
        const ry = 14;
        shapeGeometry = `
          <path d="M ${sw},${ry} L ${sw},${h - ry} A ${w / 2 - sw} ${ry} 0 0 0 ${w - sw},${h - ry} L ${w - sw},${ry} Z" fill="${fill}" stroke="${stroke}" stroke-width="${sw}" />
          <ellipse cx="${w / 2}" cy="${ry}" rx="${w / 2 - sw}" ry="${ry}" fill="#f1f5f9" stroke="${stroke}" stroke-width="${sw}" />
        `;
      } else {
        // Standard rounded rectangle / technical box
        shapeGeometry = `<rect x="${sw / 2}" y="${sw / 2}" width="${w - sw}" height="${h - sw}" rx="${r}" fill="${fill}" stroke="${stroke}" stroke-width="${sw}" ${dash} />`;
      }

      // Node labels
      const hasSub = Boolean(node.subLabel);
      const mainY = hasSub ? h / 2 - 4 : h / 2 + 4;
      const subY = h / 2 + 14;

      return `
        <g class="dl-node" transform="translate(${nodeX}, ${nodeY})">
          ${shapeGeometry}
          <text class="dl-text" x="${w / 2}" y="${mainY}" text-anchor="middle" font-size="${node.fontSize || 13}" font-weight="${node.fontWeight || '600'}" fill="${node.textColor || '#0f172a'}">${escapeXml(node.label)}</text>
          ${hasSub ? `<text class="dl-text" x="${w / 2}" y="${subY}" text-anchor="middle" font-size="10" font-weight="400" fill="#64748b">${escapeXml(node.subLabel || '')}</text>` : ''}
        </g>
      `;
    })
    .join('\n');

  // Academic Caption
  let captionSvg = '';
  if (includeCaption) {
    captionSvg = `
      <g class="dl-academic-caption" transform="translate(${width / 2}, ${captionY})">
        <text class="dl-caption" text-anchor="middle" font-size="14" fill="#0f172a" font-style="italic">
          <tspan font-weight="bold" font-style="normal">${escapeXml(figureNumber || 'Figure 1')} — </tspan>
          ${escapeXml(figureCaption || '')}
        </text>
      </g>
    `;
  }

  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${totalHeight}" viewBox="0 0 ${width} ${totalHeight}">
  ${defs}
  ${bg}
  ${edgesSvg}
  ${nodesSvg}
  ${captionSvg}
</svg>`;
}

export function downloadSvg(page: DiagramPage, filename?: string) {
  const svgStr = buildStandaloneSvgString(page, {
    background: 'white',
    includeAcademicCaption: true,
  });
  const blob = new Blob([svgStr], { type: 'image/svg+xml;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${filename || page.name || 'diagram'}.svg`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export async function downloadPng(
  page: DiagramPage,
  options: { scale: 1 | 2 | 3; background: 'white' | 'transparent'; filename?: string }
): Promise<void> {
  const { scale = 2, background = 'white', filename } = options;
  const svgStr = buildStandaloneSvgString(page, {
    background,
    includeAcademicCaption: true,
  });

  return new Promise((resolve, reject) => {
    const img = new Image();
    const svgBlob = new Blob([svgStr], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(svgBlob);

    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = img.width * scale;
        canvas.height = img.height * scale;
        const ctx = canvas.getContext('2d');
        if (!ctx) throw new Error('Could not obtain canvas 2D context');

        if (background === 'white') {
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
        }

        ctx.scale(scale, scale);
        ctx.drawImage(img, 0, 0);

        URL.revokeObjectURL(url);

        canvas.toBlob((blob) => {
          if (!blob) {
            reject(new Error('Failed to create PNG blob'));
            return;
          }
          const pngUrl = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = pngUrl;
          a.download = `${filename || page.name || 'diagram'}-${scale}x.png`;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          URL.revokeObjectURL(pngUrl);
          resolve();
        }, 'image/png');
      } catch (err) {
        URL.revokeObjectURL(url);
        reject(err);
      }
    };

    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('Failed to render SVG image to Canvas for PNG export'));
    };

    img.src = url;
  });
}

export function printAcademicPdf(page: DiagramPage) {
  // Opens a clean print window with accurate @page CSS for PDF generation
  const svgStr = buildStandaloneSvgString(page, {
    background: 'white',
    includeAcademicCaption: true,
  });

  const printWindow = window.open('', '_blank');
  if (!printWindow) {
    alert('Please allow popups to open the academic report print dialog.');
    return;
  }

  const orientation = page.orientation || 'landscape';
  const size = page.preset === 'Infinite' || page.preset === 'Custom' ? 'A4' : page.preset;

  printWindow.document.write(`
    <!DOCTYPE html>
    <html>
      <head>
        <title>${escapeXml(page.figureNumber || 'Figure')} - ${escapeXml(page.figureCaption || page.name)}</title>
        <style>
          @page {
            size: ${size} ${orientation};
            margin: 15mm;
          }
          body {
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            background: #ffffff;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
          }
          .svg-container {
            width: 100%;
            max-width: 100%;
            height: auto;
            text-align: center;
          }
          svg {
            max-width: 100%;
            height: auto;
          }
        </style>
      </head>
      <body>
        <div class="svg-container">
          ${svgStr}
        </div>
        <script>
          window.onload = function() {
            setTimeout(function() {
              window.print();
            }, 300);
          };
        </script>
      </body>
    </html>
  `);
  printWindow.document.close();
}

function escapeXml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}
