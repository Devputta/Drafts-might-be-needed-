import React, { useState } from 'react';
import { DiagramLabLogo } from '../common/DiagramLabLogo';
import {
  Undo2,
  Redo2,
  MousePointer2,
  Hand,
  GitCommitHorizontal,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Download,
  FolderOpen,
  Sparkles,
  LayoutGrid,
  Check,
  FileCode2,
  Github,
} from 'lucide-react';
import { CanvasTool, ViewportTransform } from '../../types/diagram';

interface TopNavbarProps {
  projectName: string;
  onRenameProject: (name: string) => void;
  currentView: 'editor' | 'dashboard' | 'landing';
  onChangeView: (view: 'editor' | 'dashboard' | 'landing') => void;
  tool: CanvasTool;
  onToolChange: (tool: CanvasTool) => void;
  canUndo: boolean;
  canRedo: boolean;
  onUndo: () => void;
  onRedo: () => void;
  transform: ViewportTransform;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onZoomReset: () => void;
  onZoomFit: () => void;
  onOpenTemplates: () => void;
  onOpenAiAssistant: () => void;
  onOpenExport: () => void;
  isDarkMode?: boolean;
}

export const TopNavbar: React.FC<TopNavbarProps> = ({
  projectName,
  onRenameProject,
  currentView,
  onChangeView,
  tool,
  onToolChange,
  canUndo,
  canRedo,
  onUndo,
  onRedo,
  transform,
  onZoomIn,
  onZoomOut,
  onZoomReset,
  onZoomFit,
  onOpenTemplates,
  onOpenAiAssistant,
  onOpenExport,
  isDarkMode = false,
}) => {
  const [isEditingName, setIsEditingName] = useState(false);
  const [nameInput, setNameInput] = useState(projectName);

  const handleNameSubmit = () => {
    setIsEditingName(false);
    if (nameInput.trim()) {
      onRenameProject(nameInput.trim());
    }
  };

  const zoomPercent = Math.round(transform.zoom * 100);

  return (
    <header
      className={`h-13 border-b px-3 flex items-center justify-between gap-2 z-40 shrink-0 transition-colors ${
        isDarkMode
          ? 'bg-slate-900 border-slate-800 text-slate-100'
          : 'bg-white border-slate-200 text-slate-900'
      }`}
    >
      {/* Brand & View Navigation */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => onChangeView('landing')}
          className="group hover:opacity-85 transition-opacity"
          title="DiagramLab Home"
        >
          <DiagramLabLogo size="sm" />
        </button>

        <div className={`h-5 w-px mx-1 ${isDarkMode ? 'bg-slate-800' : 'bg-slate-200'}`} />

        {/* View Switcher Tabs */}
        <div
          className={`flex items-center gap-1 p-0.5 rounded-md text-xs font-medium ${
            isDarkMode ? 'bg-slate-800 text-slate-400' : 'bg-slate-100 text-slate-600'
          }`}
        >
          <button
            onClick={() => onChangeView('editor')}
            className={`px-2.5 py-1 rounded transition-colors ${
              currentView === 'editor'
                ? isDarkMode
                  ? 'bg-slate-700 text-white shadow-xs'
                  : 'bg-white text-slate-900 shadow-xs'
                : isDarkMode
                ? 'hover:text-slate-200'
                : 'hover:text-slate-900'
            }`}
          >
            Editor
          </button>
          <button
            onClick={() => onChangeView('dashboard')}
            className={`px-2.5 py-1 rounded transition-colors ${
              currentView === 'dashboard'
                ? isDarkMode
                  ? 'bg-slate-700 text-white shadow-xs'
                  : 'bg-white text-slate-900 shadow-xs'
                : isDarkMode
                ? 'hover:text-slate-200'
                : 'hover:text-slate-900'
            }`}
          >
            Projects
          </button>
        </div>

        {/* Editable Project Name */}
        {currentView === 'editor' && (
          <div className="ml-2 flex items-center gap-1">
            {isEditingName ? (
              <input
                type="text"
                autoFocus
                value={nameInput}
                onChange={(e) => setNameInput(e.target.value)}
                onBlur={handleNameSubmit}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleNameSubmit();
                  if (e.key === 'Escape') setIsEditingName(false);
                }}
                className={`text-xs font-semibold px-2 py-1 border border-sky-500 rounded outline-none w-48 ${
                  isDarkMode ? 'bg-slate-800 text-white' : 'bg-white text-slate-900'
                }`}
              />
            ) : (
              <button
                onClick={() => {
                  setNameInput(projectName);
                  setIsEditingName(true);
                }}
                className={`text-xs font-semibold px-2 py-1 rounded transition-colors truncate max-w-[200px] ${
                  isDarkMode
                    ? 'text-slate-200 hover:text-sky-400 hover:bg-slate-800'
                    : 'text-slate-800 hover:text-sky-700 hover:bg-slate-50'
                }`}
                title="Click to rename diagram"
              >
                {projectName}
              </button>
            )}
            <span className="flex items-center gap-1 text-[11px] text-slate-400 font-normal ml-1">
              <Check className="w-3 h-3 text-emerald-500" />
              Saved
            </span>
          </div>
        )}
      </div>

      {/* Center Tools (Only in Editor Mode) */}
      {currentView === 'editor' && (
        <div className="flex items-center gap-1">
          {/* History Undo / Redo */}
          <div
            className={`flex items-center border rounded-md p-0.5 ${
              isDarkMode
                ? 'bg-slate-800/80 border-slate-700 text-slate-200'
                : 'bg-slate-50 border-slate-200 text-slate-700'
            }`}
          >
            <button
              onClick={onUndo}
              disabled={!canUndo}
              className={`p-1.5 rounded transition-colors ${
                canUndo
                  ? isDarkMode
                    ? 'text-slate-200 hover:bg-slate-700 hover:text-white'
                    : 'text-slate-700 hover:bg-white hover:shadow-xs'
                  : isDarkMode
                  ? 'text-slate-600 cursor-not-allowed'
                  : 'text-slate-300 cursor-not-allowed'
              }`}
              title="Undo (Ctrl+Z)"
            >
              <Undo2 className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={onRedo}
              disabled={!canRedo}
              className={`p-1.5 rounded transition-colors ${
                canRedo
                  ? isDarkMode
                    ? 'text-slate-200 hover:bg-slate-700 hover:text-white'
                    : 'text-slate-700 hover:bg-white hover:shadow-xs'
                  : isDarkMode
                  ? 'text-slate-600 cursor-not-allowed'
                  : 'text-slate-300 cursor-not-allowed'
              }`}
              title="Redo (Ctrl+Y)"
            >
              <Redo2 className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className={`h-4 w-px mx-1 ${isDarkMode ? 'bg-slate-800' : 'bg-slate-200'}`} />

          {/* Interactive Tools */}
          <div
            className={`flex items-center border rounded-md p-0.5 ${
              isDarkMode
                ? 'bg-slate-800/80 border-slate-700'
                : 'bg-slate-50 border-slate-200'
            }`}
          >
            <button
              onClick={() => onToolChange('select')}
              className={`p-1.5 rounded transition-colors ${
                tool === 'select'
                  ? isDarkMode
                    ? 'bg-slate-700 text-sky-400 font-semibold shadow-xs'
                    : 'bg-white text-sky-700 shadow-xs font-semibold'
                  : isDarkMode
                  ? 'text-slate-400 hover:bg-slate-700 hover:text-slate-200'
                  : 'text-slate-700 hover:bg-white hover:text-slate-900'
              }`}
              title="Select & Move (V)"
            >
              <MousePointer2 className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onToolChange('pan')}
              className={`p-1.5 rounded transition-colors ${
                tool === 'pan'
                  ? isDarkMode
                    ? 'bg-slate-700 text-sky-400 font-semibold shadow-xs'
                    : 'bg-white text-sky-700 shadow-xs font-semibold'
                  : isDarkMode
                  ? 'text-slate-400 hover:bg-slate-700 hover:text-slate-200'
                  : 'text-slate-700 hover:bg-white hover:text-slate-900'
              }`}
              title="Pan Tool (H or Space+Drag)"
            >
              <Hand className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className={`h-4 w-px mx-1 ${isDarkMode ? 'bg-slate-800' : 'bg-slate-200'}`} />

          {/* Zoom Controls */}
          <div
            className={`flex items-center border rounded-md p-0.5 ${
              isDarkMode
                ? 'bg-slate-800/80 border-slate-700'
                : 'bg-slate-50 border-slate-200'
            }`}
          >
            <button
              onClick={onZoomOut}
              className={`p-1.5 rounded transition-colors ${
                isDarkMode ? 'text-slate-300 hover:bg-slate-700' : 'text-slate-700 hover:bg-white'
              }`}
              title="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={onZoomReset}
              className={`px-2 text-xs font-mono font-medium py-1 rounded transition-colors ${
                isDarkMode ? 'text-slate-200 hover:bg-slate-700' : 'text-slate-700 hover:bg-white'
              }`}
              title="Reset Zoom to 100%"
            >
              {zoomPercent}%
            </button>
            <button
              onClick={onZoomIn}
              className={`p-1.5 rounded transition-colors ${
                isDarkMode ? 'text-slate-300 hover:bg-slate-700' : 'text-slate-700 hover:bg-white'
              }`}
              title="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={onZoomFit}
              className={`p-1.5 rounded transition-colors ${
                isDarkMode ? 'text-slate-300 hover:bg-slate-700' : 'text-slate-700 hover:bg-white'
              }`}
              title="Fit to Screen"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Right Action Buttons */}
      <div className="flex items-center gap-2">
        {/* Official GitHub Repository Link */}
        <a
          href="https://github.com/Devputta/DiagramLab.git"
          target="_blank"
          rel="noopener noreferrer"
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-md border text-xs font-semibold transition-colors shadow-2xs group ${
            isDarkMode
              ? 'border-slate-750 bg-slate-800 text-slate-200 hover:bg-slate-750 hover:text-white'
              : 'border-slate-200 text-slate-700 hover:bg-slate-50 hover:text-slate-900'
          }`}
          title="DiagramLab Repository on GitHub (https://github.com/Devputta/DiagramLab.git)"
        >
          <Github className={`w-3.5 h-3.5 group-hover:scale-110 transition-transform ${isDarkMode ? 'text-slate-200' : 'text-slate-800'}`} />
          <span className="hidden sm:inline">GitHub</span>
        </a>

        <button
          onClick={onOpenTemplates}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md border text-xs font-medium transition-colors ${
            isDarkMode
              ? 'border-slate-750 bg-slate-800 text-slate-200 hover:bg-slate-750 hover:text-white'
              : 'border-slate-200 text-slate-700 hover:bg-slate-50 hover:text-slate-900'
          }`}
          title="Browse Technical Architecture Templates"
        >
          <LayoutGrid className="w-3.5 h-3.5 text-slate-400" />
          <span>Templates</span>
        </button>

        <button
          onClick={onOpenAiAssistant}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md border text-xs font-semibold transition-colors ${
            isDarkMode
              ? 'border-sky-800/80 bg-sky-950/60 text-sky-300 hover:bg-sky-900/60'
              : 'border-sky-200 bg-sky-50/60 text-sky-800 hover:bg-sky-100'
          }`}
          title="Generate editable technical diagram from workflow description"
        >
          <Sparkles className="w-3.5 h-3.5 text-sky-400" />
          <span>AI Synthesis</span>
        </button>

        <button
          onClick={onOpenExport}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition-colors shadow-xs ${
            isDarkMode
              ? 'bg-sky-600 hover:bg-sky-500 text-white'
              : 'bg-slate-900 text-white hover:bg-slate-800'
          }`}
          title="Export as Vector SVG, PNG, Academic PDF, or JSON"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export</span>
        </button>
      </div>
    </header>
  );
};
