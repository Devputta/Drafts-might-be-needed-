import React, { useState, useRef } from 'react';
import { DiagramNode, HandlePosition } from '../../types/diagram';
import { RenderShapeSvg } from '../../shapes/renderers';
import { Lock, Plus } from 'lucide-react';

interface NodeRendererProps {
  node: DiagramNode;
  isSelected: boolean;
  zoom: number;
  onSelect: (nodeId: string, e: React.MouseEvent) => void;
  onDragStart: (nodeId: string, e: React.MouseEvent) => void;
  onResizeStart: (nodeId: string, handle: string, e: React.MouseEvent) => void;
  onConnectStart: (nodeId: string, handle: HandlePosition, e: React.MouseEvent) => void;
  onConnectEnd: (nodeId: string, handle: HandlePosition) => void;
  onUpdateText: (nodeId: string, newLabel: string, newSubLabel?: string) => void;
  onQuickSprout?: (nodeId: string, direction: 'right' | 'bottom') => void;
  isDarkMode?: boolean;
}

export const NodeRenderer: React.FC<NodeRendererProps> = ({
  node,
  isSelected,
  zoom,
  onSelect,
  onDragStart,
  onResizeStart,
  onConnectStart,
  onConnectEnd,
  onUpdateText,
  onQuickSprout,
  isDarkMode = false,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [labelText, setLabelText] = useState(node.label);
  const [subLabelText, setSubLabelText] = useState(node.subLabel || '');
  const [isHovered, setIsHovered] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const displayNode = isDarkMode
    ? {
        ...node,
        fill:
          node.fill === '#ffffff' || !node.fill || node.fill === '#fff'
            ? '#1e293b'
            : node.fill === '#f0f9ff'
            ? '#0c4a6e'
            : node.fill === '#f0fdf4'
            ? '#064e3b'
            : node.fill === '#fef2f2'
            ? '#450a0a'
            : node.fill,
        stroke:
          node.stroke === '#334155' || !node.stroke
            ? '#94a3b8'
            : node.stroke,
        textColor:
          node.textColor === '#0f172a' || !node.textColor || node.textColor === '#334155'
            ? '#f8fafc'
            : node.textColor,
      }
    : node;

  const handleFinishEditing = () => {
    setIsEditing(false);
    onUpdateText(node.id, labelText, subLabelText);
  };

  const handles: HandlePosition[] = ['top', 'right', 'bottom', 'left'];

  // Handle anchor coordinate classes
  const getHandlePositionStyles = (pos: HandlePosition) => {
    switch (pos) {
      case 'top':
        return { top: -6, left: '50%', transform: 'translateX(-50%)' };
      case 'right':
        return { top: '50%', right: -6, transform: 'translateY(-50%)' };
      case 'bottom':
        return { bottom: -6, left: '50%', transform: 'translateX(-50%)' };
      case 'left':
        return { top: '50%', left: -6, transform: 'translateY(-50%)' };
    }
  };

  return (
    <div
      ref={containerRef}
      id={`node-${node.id}`}
      style={{
        position: 'absolute',
        left: `${node.x}px`,
        top: `${node.y}px`,
        width: `${node.width}px`,
        height: `${node.height}px`,
        transform: node.rotation ? `rotate(${node.rotation}deg)` : undefined,
        zIndex: node.zIndex || 1,
        cursor: node.locked ? 'default' : isEditing ? 'text' : 'grab',
        touchAction: 'none',
      }}
      className={`group select-none active:cursor-grabbing ${node.hidden ? 'hidden' : ''}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onMouseDown={(e) => {
        if (e.button !== 0) return;
        e.stopPropagation();
        onSelect(node.id, e);
        if (!node.locked && !isEditing) {
          onDragStart(node.id, e);
        }
      }}
      onDoubleClick={(e) => {
        e.stopPropagation();
        if (!node.locked) {
          setIsEditing(true);
        }
      }}
    >
      {/* Selection Bounding Box */}
      {isSelected && (
        <div
          className="absolute inset-0 border-2 border-sky-500 pointer-events-none rounded-xs"
          style={{ margin: -3 }}
        />
      )}

      {/* SVG Shape Geometry */}
      <div className="absolute inset-0 pointer-events-none">
        <RenderShapeSvg node={displayNode} />
      </div>

      {/* Text Container (Cleanly separated from geometry) */}
      {(() => {
        const isExternalLabelShape = [
          'soft-user',
          'uml-actor',
          'actor',
          'user',
          'net-router',
          'net-firewall',
        ].includes(node.type);

        return (
          <div
            className={
              isExternalLabelShape
                ? 'absolute top-[102%] left-1/2 -translate-x-1/2 flex flex-col items-center justify-center text-center pointer-events-none w-max max-w-[200px] z-20'
                : 'absolute inset-0 flex flex-col items-center justify-center px-2 py-1 text-center pointer-events-none z-20'
            }
            style={{
              color: displayNode.textColor || (isDarkMode ? '#f8fafc' : '#0f172a'),
              fontSize: `${node.fontSize || (node.label.length > 20 ? 11 : 12)}px`,
              fontWeight:
                node.fontWeight === 'bold' ? 700 : node.fontWeight === 'medium' ? 600 : 500,
              fontFamily:
                node.fontFamily === 'mono'
                  ? 'ui-monospace, monospace'
                  : node.fontFamily === 'serif'
                    ? 'Georgia, serif'
                    : 'inherit',
              textAlign: node.textAlign || 'center',
            }}
          >
            {isEditing ? (
              <div
                className={`pointer-events-auto flex flex-col gap-1 w-44 bg-white dark:bg-slate-900 p-1.5 rounded-lg shadow-xl border-2 border-sky-500 z-40 ${
                  isExternalLabelShape ? 'mt-1' : ''
                }`}
              >
                <input
                  type="text"
                  autoFocus
                  value={labelText}
                  onChange={(e) => setLabelText(e.target.value)}
                  className="text-xs font-semibold text-center border-b border-slate-200 dark:border-slate-700 outline-none px-1 py-0.5 bg-transparent text-slate-900 dark:text-white"
                  placeholder="Label"
                />
                <input
                  type="text"
                  value={subLabelText}
                  onChange={(e) => setSubLabelText(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleFinishEditing();
                    if (e.key === 'Escape') setIsEditing(false);
                  }}
                  onBlur={handleFinishEditing}
                  className="text-[11px] text-slate-500 dark:text-slate-400 text-center outline-none px-1 py-0.5 bg-transparent"
                  placeholder="Details / Sub-label (optional)"
                />
              </div>
            ) : isExternalLabelShape ? (
              <div className="px-2 py-0.5 mt-1 text-center">
                <span className="leading-tight font-semibold text-slate-800 dark:text-slate-100 block whitespace-nowrap text-xs">
                  {node.label}
                </span>
                {node.subLabel && (
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 leading-tight mt-0.5 truncate max-w-full block">
                    {node.subLabel}
                  </span>
                )}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center max-w-full px-1.5 py-0.5 leading-snug">
                <span className="font-semibold line-clamp-2 select-none">{node.label}</span>
                {node.subLabel && (
                  <span className="text-[10px] opacity-80 leading-tight mt-0.5 truncate max-w-full font-normal select-none">
                    {node.subLabel}
                  </span>
                )}
              </div>
            )}
          </div>
        );
      })()}

      {/* Lock Status Badge */}
      {node.locked && (
        <div className="absolute top-1 right-1 p-0.5 bg-slate-100/90 rounded text-slate-500 pointer-events-none">
          <Lock className="w-3 h-3" />
        </div>
      )}

      {/* Connection Points (Handles) */}
      {(isHovered || isSelected) && !node.locked && (
        <>
          {handles.map((h) => (
            <button
              key={h}
              style={getHandlePositionStyles(h)}
              className="absolute w-3.5 h-3.5 rounded-full bg-white border-2 border-sky-600 hover:scale-125 hover:bg-sky-500 hover:border-sky-700 transition-all shadow-md z-30 cursor-crosshair flex items-center justify-center group/h"
              title={`Drag link from ${h}`}
              onMouseDown={(e) => {
                e.stopPropagation();
                onConnectStart(node.id, h, e);
              }}
              onMouseUp={(e) => {
                e.stopPropagation();
                onConnectEnd(node.id, h);
              }}
            >
              <span className="w-1 h-1 rounded-full bg-sky-600 group-hover/h:bg-white" />
            </button>
          ))}

          {/* Quick Flow Sprout Buttons: Instant Link to Next Step */}
          {isSelected && onQuickSprout && (
            <>
              {/* Right Sprout Button */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onQuickSprout(node.id, 'right');
                }}
                className="absolute -right-8 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-sky-600 hover:bg-sky-500 text-white flex items-center justify-center shadow-lg transition-transform hover:scale-115 z-30 group/btn"
                title="Add connected step to right"
              >
                <Plus className="w-3.5 h-3.5 stroke-[3]" />
              </button>

              {/* Bottom Sprout Button */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onQuickSprout(node.id, 'bottom');
                }}
                style={{
                  bottom: [
                    'soft-user',
                    'uml-actor',
                    'actor',
                    'user',
                    'net-router',
                    'net-firewall',
                  ].includes(node.type)
                    ? -46
                    : -32,
                }}
                className="absolute left-1/2 -translate-x-1/2 w-6 h-6 rounded-full bg-sky-600 hover:bg-sky-500 text-white flex items-center justify-center shadow-lg transition-transform hover:scale-115 z-30 group/btn"
                title="Add connected step below"
              >
                <Plus className="w-3.5 h-3.5 stroke-[3]" />
              </button>
            </>
          )}
        </>
      )}

      {/* Resize Handles (When Selected & Not Locked) */}
      {isSelected && !node.locked && (
        <>
          {['nw', 'n', 'ne', 'e', 'se', 's', 'sw', 'w'].map((handle) => {
            let cursor = 'default';
            let style: React.CSSProperties = {};

            switch (handle) {
              case 'nw':
                cursor = 'nwse-resize';
                style = { top: -4, left: -4 };
                break;
              case 'n':
                cursor = 'ns-resize';
                style = { top: -4, left: '50%', transform: 'translateX(-50%)' };
                break;
              case 'ne':
                cursor = 'nesw-resize';
                style = { top: -4, right: -4 };
                break;
              case 'e':
                cursor = 'ew-resize';
                style = { top: '50%', right: -4, transform: 'translateY(-50%)' };
                break;
              case 'se':
                cursor = 'nwse-resize';
                style = { bottom: -4, right: -4 };
                break;
              case 's':
                cursor = 'ns-resize';
                style = { bottom: -4, left: '50%', transform: 'translateX(-50%)' };
                break;
              case 'sw':
                cursor = 'nesw-resize';
                style = { bottom: -4, left: -4 };
                break;
              case 'w':
                cursor = 'ew-resize';
                style = { top: '50%', left: -4, transform: 'translateY(-50%)' };
                break;
            }

            return (
              <div
                key={handle}
                style={{ ...style, cursor }}
                className="absolute w-2 h-2 bg-white border border-sky-600 z-30"
                onMouseDown={(e) => {
                  e.stopPropagation();
                  onResizeStart(node.id, handle, e);
                }}
              />
            );
          })}
        </>
      )}
    </div>
  );
};
