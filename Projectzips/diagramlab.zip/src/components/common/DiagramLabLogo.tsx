import React from 'react';

interface DiagramLabLogoProps {
  size?: 'sm' | 'md' | 'lg';
  showSubtitle?: boolean;
  className?: string;
}

export const DiagramLabLogo: React.FC<DiagramLabLogoProps> = ({
  size = 'md',
  showSubtitle = false,
  className = '',
}) => {
  const iconSize = size === 'sm' ? 24 : size === 'lg' ? 40 : 32;
  const textSize = size === 'sm' ? 'text-xs' : size === 'lg' ? 'text-xl' : 'text-sm';
  const subtitleSize = size === 'sm' ? 'text-[9px]' : size === 'lg' ? 'text-xs' : 'text-[10px]';

  return (
    <div className={`flex items-center gap-2.5 select-none ${className}`}>
      {/* Precision Geometric Technical Icon */}
      <div
        style={{ width: iconSize, height: iconSize }}
        className="relative bg-slate-900 rounded-lg flex items-center justify-center shadow-xs shrink-0 overflow-hidden group"
      >
        {/* Subtle technical circuit/diagram vector glyph */}
        <svg
          width={iconSize}
          height={iconSize}
          viewBox="0 0 32 32"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="p-1"
        >
          {/* Connecting technical orthogonal bus line */}
          <path
            d="M 9 9 L 23 9 L 23 23 L 9 23 Z"
            stroke="#38bdf8"
            strokeWidth="1.5"
            strokeDasharray="2 2"
            strokeOpacity="0.4"
          />
          {/* Main diagonal/orthogonal path */}
          <path
            d="M 9 10 L 9 16 L 23 16 L 23 22"
            stroke="#38bdf8"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          {/* Node 1: Top-Left Primary Component */}
          <rect
            x="6"
            y="6"
            width="6"
            height="6"
            rx="1.5"
            fill="#ffffff"
            stroke="#0284c7"
            strokeWidth="1.5"
          />
          {/* Node 2: Center Gateway Point */}
          <circle cx="16" cy="16" r="2.5" fill="#38bdf8" />
          {/* Node 3: Bottom-Right Database/Service Component */}
          <rect
            x="20"
            y="20"
            width="6"
            height="6"
            rx="1.5"
            fill="#38bdf8"
            stroke="#ffffff"
            strokeWidth="1.5"
          />
        </svg>
      </div>

      {/* Brand Wordmark */}
      <div className="flex flex-col">
        <div className="flex items-center gap-1.5 leading-none">
          <span className={`font-bold tracking-tight text-slate-900 ${textSize}`}>
            Diagram<span className="text-sky-600">Lab</span>
          </span>
          <span className="text-[9px] font-mono uppercase tracking-wider px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 font-semibold">
            PRO
          </span>
        </div>
        {showSubtitle && (
          <span className={`text-slate-400 font-mono tracking-tight mt-0.5 ${subtitleSize}`}>
            Technical Diagram Workspace
          </span>
        )}
      </div>
    </div>
  );
};
