import React from 'react';
import {
  Layers,
  FileText,
  Box,
  Share2,
  Download,
  ArrowRight,
  GitBranch,
  ShieldCheck,
  CheckCircle2,
  Sparkles,
  LayoutGrid,
  Github,
} from 'lucide-react';
import { TEMPLATE_CATALOG } from '../../templates/catalog';
import { DiagramLabLogo } from '../common/DiagramLabLogo';

interface LandingViewProps {
  onOpenEditor: () => void;
  onOpenDashboard: () => void;
  onSelectTemplate: (templateId: string) => void;
}

export const LandingView: React.FC<LandingViewProps> = ({
  onOpenEditor,
  onOpenDashboard,
  onSelectTemplate,
}) => {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans flex flex-col">
      {/* Top Header */}
      <header className="h-14 border-b border-slate-200 bg-white px-6 flex items-center justify-between shrink-0 sticky top-0 z-30">
        <DiagramLabLogo size="md" showSubtitle />

        <div className="flex items-center gap-3">
          <a
            href="https://github.com/Devputta/DiagramLab.git"
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs font-semibold text-slate-700 hover:text-slate-900 px-3 py-1.5 rounded-md border border-slate-200 bg-white hover:bg-slate-50 transition-colors shadow-2xs flex items-center gap-1.5"
            title="DiagramLab Repository on GitHub"
          >
            <Github className="w-3.5 h-3.5 text-slate-800" />
            <span>GitHub</span>
          </a>
          <button
            onClick={onOpenDashboard}
            className="text-xs font-medium text-slate-600 hover:text-slate-900 px-3 py-1.5 rounded transition-colors"
          >
            My Projects
          </button>
          <button
            onClick={onOpenEditor}
            className="text-xs font-semibold px-4 py-2 rounded bg-slate-900 text-white hover:bg-slate-800 transition-colors shadow-xs flex items-center gap-1.5"
          >
            <span>Launch Editor</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-6xl mx-auto w-full px-6 py-12 space-y-16">
        {/* Hero Section */}
        <section className="text-center max-w-3xl mx-auto space-y-5">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-slate-200 bg-white text-xs font-medium text-slate-600 shadow-2xs">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            Human-first visual diagrams for technical reports & architectures
          </div>

          <h1 className="text-4xl sm:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight">
            Real objects. Real connectors. <br />
            <span className="text-slate-700">Ready for academic reports.</span>
          </h1>

          <p className="text-base text-slate-600 leading-relaxed">
            DiagramLab is a serious diagram editor built for software developers, university students, and researchers. Create flowcharts, system architectures, UML classes, and ER schemas that export cleanly to A4 and Letter PDF figures without artificial AI styling.
          </p>

          <div className="flex items-center justify-center gap-3 pt-3">
            <button
              onClick={onOpenEditor}
              className="px-6 py-3 rounded-lg bg-slate-900 text-white font-medium text-sm hover:bg-slate-800 transition-all shadow-sm flex items-center gap-2"
            >
              <span>Start Blank Diagram</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={onOpenDashboard}
              className="px-6 py-3 rounded-lg bg-white border border-slate-300 text-slate-700 font-medium text-sm hover:bg-slate-100 transition-colors"
            >
              Browse Templates & Projects
            </button>
          </div>
        </section>

        {/* Feature Grid */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-xl border border-slate-200 bg-white shadow-2xs space-y-3">
            <div className="w-10 h-10 rounded-lg bg-sky-50 text-sky-700 flex items-center justify-center">
              <FileText className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-base text-slate-900">Academic Report Mode</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Format diagrams directly for standard A4 or Letter documents with IEEE/ACM-compliant figure numbering, captions, and printable margins.
            </p>
          </div>

          <div className="p-6 rounded-xl border border-slate-200 bg-white shadow-2xs space-y-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <GitBranch className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-base text-slate-900">Real Vector Graph Edges</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Move components anywhere on the canvas while orthogonal elbow and curved connectors stay strictly connected and re-route dynamically.
            </p>
          </div>

          <div className="p-6 rounded-xl border border-slate-200 bg-white shadow-2xs space-y-3">
            <div className="w-10 h-10 rounded-lg bg-indigo-50 text-indigo-700 flex items-center justify-center">
              <Box className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-base text-slate-900">Restrained 3D Technical Extrusion</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Optional isometric server blocks and database cylinders assembled from editable vector SVG geometry — no cartoon effects or glossy plastic.
            </p>
          </div>
        </section>

        {/* Shape Registry Categories Overview */}
        <section className="bg-white rounded-xl border border-slate-200 p-8 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-xl font-bold text-slate-900">Comprehensive Technical Registry</h2>
              <p className="text-xs text-slate-500 mt-1">
                Over 50 standardized shapes with precise connection points
              </p>
            </div>
            <button
              onClick={onOpenEditor}
              className="text-xs font-semibold text-sky-700 hover:text-sky-800 flex items-center gap-1"
            >
              Open Shape Drawer <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 text-xs">
            <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
              <span className="font-bold text-slate-900 block mb-1">Software Architecture</span>
              <span className="text-[11px] text-slate-500 leading-relaxed">
                Browser SPA, API Gateway, Redis Cache, Kafka Queue, Microservice
              </span>
            </div>
            <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
              <span className="font-bold text-slate-900 block mb-1">Flowcharts</span>
              <span className="text-[11px] text-slate-500 leading-relaxed">
                Terminal Start/End, Process, Decision Diamond, I/O Parallelogram
              </span>
            </div>
            <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
              <span className="font-bold text-slate-900 block mb-1">Database & ER</span>
              <span className="text-[11px] text-slate-500 leading-relaxed">
                Relational Tables, Primary Keys, Foreign Keys, Diamond Relationships
              </span>
            </div>
            <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
              <span className="font-bold text-slate-900 block mb-1">UML Modeling</span>
              <span className="text-[11px] text-slate-500 leading-relaxed">
                Actors, Use Cases, Classes with attributes & methods, Interfaces
              </span>
            </div>
            <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
              <span className="font-bold text-slate-900 block mb-1">Network Topology</span>
              <span className="text-[11px] text-slate-500 leading-relaxed">
                Routers, Switches, Firewalls, Server Racks, Workstations
              </span>
            </div>
            <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
              <span className="font-bold text-slate-900 block mb-1">3D Technical</span>
              <span className="text-[11px] text-slate-500 leading-relaxed">
                Isometric Server Boxes, Extruded Cylinders, Base Platforms
              </span>
            </div>
          </div>
        </section>

        {/* Featured Templates Showcase */}
        <section className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-slate-900">Report-Ready Templates</h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Start from vetted computer science project baselines
              </p>
            </div>
            <button
              onClick={onOpenDashboard}
              className="text-xs font-semibold text-sky-700 hover:text-sky-800 flex items-center gap-1"
            >
              View All Templates <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {TEMPLATE_CATALOG.slice(0, 3).map((tpl) => (
              <div
                key={tpl.id}
                onClick={() => onSelectTemplate(tpl.id)}
                className="group p-5 rounded-xl border border-slate-200 bg-white hover:border-sky-500 hover:shadow-xs transition-all cursor-pointer flex flex-col justify-between"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                      {tpl.category}
                    </span>
                    <span className="text-[11px] font-mono text-slate-400">
                      {tpl.preset} {tpl.orientation}
                    </span>
                  </div>
                  <h3 className="font-bold text-sm text-slate-900 group-hover:text-sky-700 transition-colors">
                    {tpl.name}
                  </h3>
                  <p className="text-xs text-slate-500 leading-relaxed line-clamp-2">
                    {tpl.description}
                  </p>
                </div>

                <div className="pt-4 border-t border-slate-100 mt-4 flex items-center justify-between text-xs text-slate-500">
                  <span className="font-serif italic text-[11px] truncate max-w-[200px]">
                    {tpl.figureNumber}
                  </span>
                  <span className="font-medium text-sky-700 group-hover:translate-x-0.5 transition-transform flex items-center gap-1">
                    Use <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* AI Synthesis Notice (Responsible, structured, no hype) */}
        <section className="p-6 rounded-xl border border-slate-200 bg-slate-100/70 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-sky-600" />
              <h3 className="font-bold text-sm text-slate-900">
                Optional AI-to-Editable-Diagram Feature
              </h3>
            </div>
            <p className="text-xs text-slate-600 max-w-2xl leading-relaxed">
              Describe your system architecture in plain English. The AI engine synthesizes real editable vector nodes and connected edges into your canvas — never static raster images or flattened diagrams.
            </p>
          </div>
          <button
            onClick={onOpenEditor}
            className="px-4 py-2 bg-white border border-slate-300 text-slate-800 text-xs font-semibold rounded-lg hover:bg-slate-50 transition-colors shrink-0 shadow-2xs"
          >
            Try in Editor
          </button>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-6 px-6 text-center text-xs text-slate-500">
        <p>DiagramLab — Professional Visual Diagram Editor for Academic & Software Documentation</p>
      </footer>
    </div>
  );
};
