import React, { useState } from 'react';
import {
  DiagramPage,
  DiagramNode,
  DiagramEdge,
  PagePreset,
  PageOrientation,
  ConnectorType,
  ArrowType,
  StrokeStyle,
} from '../../types/diagram';
import { LayersPanel } from './LayersPanel';
import {
  Sliders,
  Layers,
  Lock,
  Unlock,
  Copy,
  Trash2,
  Box,
  FileText,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Grid,
  Magnet,
  Maximize2,
  Layout,
  Type,
  Palette,
  X,
} from 'lucide-react';

interface PropertiesPanelProps {
  page: DiagramPage;
  selectedNodeIds: string[];
  selectedEdgeId: string | null;
  onUpdateNodes: (nodes: DiagramNode[]) => void;
  onUpdateEdges: (edges: DiagramEdge[]) => void;
  onUpdatePage: (page: DiagramPage) => void;
  onDuplicateNodes: (nodeIds: string[]) => void;
  onDeleteSelected: () => void;
  onSelectNode: (id: string, multiSelect: boolean) => void;
  onSelectEdge: (id: string) => void;
  isOpen: boolean;
  onToggleOpen: () => void;
}

export const PropertiesPanel: React.FC<PropertiesPanelProps> = ({
  page,
  selectedNodeIds,
  selectedEdgeId,
  onUpdateNodes,
  onUpdateEdges,
  onUpdatePage,
  onDuplicateNodes,
  onDeleteSelected,
  onSelectNode,
  onSelectEdge,
  isOpen,
  onToggleOpen,
}) => {
  const [activeTab, setActiveTab] = useState<'properties' | 'layers'>('properties');

  if (!isOpen) {
    return (
      <div className="w-10 bg-white border-l border-slate-200 flex flex-col items-center py-3 shrink-0">
        <button
          onClick={onToggleOpen}
          className="p-2 rounded-lg hover:bg-slate-100 text-slate-600 transition-colors"
          title="Open Properties Panel"
        >
          <Sliders className="w-4 h-4" />
        </button>
      </div>
    );
  }

  const primaryNode = page.nodes.find((n) => n.id === selectedNodeIds[0]);
  const primaryEdge = page.edges.find((e) => e.id === selectedEdgeId);

  const updatePrimaryNode = (updates: Partial<DiagramNode>) => {
    if (!primaryNode) return;
    const updated = page.nodes.map((n) =>
      selectedNodeIds.includes(n.id) ? { ...n, ...updates } : n
    );
    onUpdateNodes(updated);
  };

  const updatePrimaryEdge = (updates: Partial<DiagramEdge>) => {
    if (!primaryEdge) return;
    const updated = page.edges.map((e) => (e.id === primaryEdge.id ? { ...e, ...updates } : e));
    onUpdateEdges(updated);
  };

  // Curated restrained technical palette
  const COLOR_PALETTE = [
    '#ffffff',
    '#f8fafc',
    '#f0f9ff',
    '#f0fdf4',
    '#fffbeb',
    '#fef2f2',
    '#faf5ff',
    '#0f172a',
    '#334155',
    '#0284c7',
    '#16a34a',
    '#d97706',
    '#dc2626',
    '#7c3aed',
  ];

  return (
    <aside className="w-80 bg-white border-l border-slate-200 flex flex-col h-full shrink-0 z-20 shadow-xs">
      {/* Top Header: Clean Segmented Tab Switcher */}
      <div className="h-12 border-b border-slate-200 flex items-center justify-between px-4 shrink-0 bg-white">
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg text-xs font-semibold text-slate-600">
          <button
            onClick={() => setActiveTab('properties')}
            className={`px-3 py-1 rounded-md transition-all ${
              activeTab === 'properties'
                ? 'bg-white text-slate-900 shadow-2xs font-bold'
                : 'hover:text-slate-900'
            }`}
          >
            Properties
          </button>
          <button
            onClick={() => setActiveTab('layers')}
            className={`px-3 py-1 rounded-md transition-all ${
              activeTab === 'layers'
                ? 'bg-white text-slate-900 shadow-2xs font-bold'
                : 'hover:text-slate-900'
            }`}
          >
            Layers
          </button>
        </div>

        <button
          onClick={onToggleOpen}
          className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
          title="Collapse Panel"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Panel Scroll Body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-5 text-xs">
        {activeTab === 'layers' ? (
          <LayersPanel
            nodes={page.nodes}
            edges={page.edges}
            selectedNodeIds={selectedNodeIds}
            selectedEdgeId={selectedEdgeId}
            onSelectNode={onSelectNode}
            onSelectEdge={onSelectEdge}
            onToggleLockNode={(id) => {
              const node = page.nodes.find((n) => n.id === id);
              if (node) {
                onUpdateNodes(
                  page.nodes.map((n) => (n.id === id ? { ...n, locked: !n.locked } : n))
                );
              }
            }}
            onToggleHideNode={(id) => {
              const node = page.nodes.find((n) => n.id === id);
              if (node) {
                onUpdateNodes(
                  page.nodes.map((n) => (n.id === id ? { ...n, hidden: !n.hidden } : n))
                );
              }
            }}
            onReorderNode={(id, direction) => {
              const idx = page.nodes.findIndex((n) => n.id === id);
              if (idx === -1) return;
              const newNodes = [...page.nodes];
              if (direction === 'up' && idx < newNodes.length - 1) {
                const temp = newNodes[idx];
                newNodes[idx] = newNodes[idx + 1];
                newNodes[idx + 1] = temp;
              } else if (direction === 'down' && idx > 0) {
                const temp = newNodes[idx];
                newNodes[idx] = newNodes[idx - 1];
                newNodes[idx - 1] = temp;
              }
              newNodes.forEach((n, i) => {
                n.zIndex = i + 1;
              });
              onUpdateNodes(newNodes);
            }}
            onDeleteNode={(id) => {
              onUpdateNodes(page.nodes.filter((n) => n.id !== id));
              onUpdateEdges(page.edges.filter((e) => e.source !== id && e.target !== id));
            }}
            onDeleteEdge={(id) => {
              onUpdateEdges(page.edges.filter((e) => e.id !== id));
            }}
          />
        ) : primaryNode ? (
          // ==========================================
          // 1. SHAPE PROPERTIES (CLEAN & SPACIOUS)
          // ==========================================
          <div className="space-y-5">
            {/* Header row with quick actions */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <span className="font-bold text-sm text-slate-900 truncate">
                {selectedNodeIds.length > 1
                  ? `${selectedNodeIds.length} Shapes Selected`
                  : primaryNode.label || 'Shape Properties'}
              </span>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => onDuplicateNodes(selectedNodeIds)}
                  className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
                  title="Duplicate (Ctrl+D)"
                >
                  <Copy className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => updatePrimaryNode({ locked: !primaryNode.locked })}
                  className={`p-1.5 rounded-lg transition-colors ${
                    primaryNode.locked
                      ? 'text-amber-600 bg-amber-50'
                      : 'text-slate-500 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                  title={primaryNode.locked ? 'Unlock Position' : 'Lock Position'}
                >
                  {primaryNode.locked ? (
                    <Lock className="w-3.5 h-3.5" />
                  ) : (
                    <Unlock className="w-3.5 h-3.5" />
                  )}
                </button>
                <button
                  onClick={onDeleteSelected}
                  className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                  title="Delete"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Labels Card */}
            <div className="space-y-2.5">
              <div className="flex items-center gap-1.5 text-slate-700 font-semibold text-xs">
                <Type className="w-3.5 h-3.5 text-slate-500" />
                <span>Text Content</span>
              </div>
              <input
                type="text"
                value={primaryNode.label}
                onChange={(e) => updatePrimaryNode({ label: e.target.value })}
                placeholder="Component Name"
                className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:bg-white focus:border-sky-500"
              />
              <input
                type="text"
                value={primaryNode.subLabel || ''}
                onChange={(e) => updatePrimaryNode({ subLabel: e.target.value })}
                placeholder="Sub-label (e.g. PostgreSQL v16)"
                className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:bg-white focus:border-sky-500"
              />
            </div>

            {/* Dimensions */}
            <div className="space-y-2.5">
              <span className="text-slate-700 font-semibold text-xs block">Size & Position</span>
              <div className="grid grid-cols-2 gap-2">
                <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5">
                  <span className="text-[11px] text-slate-400 font-mono">W</span>
                  <input
                    type="number"
                    value={Math.round(primaryNode.width)}
                    onChange={(e) =>
                      updatePrimaryNode({ width: Math.max(40, Number(e.target.value)) })
                    }
                    className="w-full text-xs bg-transparent outline-none font-medium"
                  />
                </div>
                <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5">
                  <span className="text-[11px] text-slate-400 font-mono">H</span>
                  <input
                    type="number"
                    value={Math.round(primaryNode.height)}
                    onChange={(e) =>
                      updatePrimaryNode({ height: Math.max(30, Number(e.target.value)) })
                    }
                    className="w-full text-xs bg-transparent outline-none font-medium"
                  />
                </div>
              </div>
            </div>

            {/* Appearance (Fill & Stroke) */}
            <div className="space-y-3 pt-2 border-t border-slate-100">
              <div className="flex items-center gap-1.5 text-slate-700 font-semibold text-xs">
                <Palette className="w-3.5 h-3.5 text-slate-500" />
                <span>Fill & Border</span>
              </div>

              {/* Fill swatches */}
              <div className="space-y-1.5">
                <span className="text-[11px] text-slate-500 block">Fill Color</span>
                <div className="flex items-center gap-1.5 flex-wrap">
                  {COLOR_PALETTE.slice(0, 7).map((c) => (
                    <button
                      key={c}
                      onClick={() => updatePrimaryNode({ fill: c })}
                      style={{ backgroundColor: c }}
                      className={`w-6 h-6 rounded-md border transition-transform ${
                        primaryNode.fill === c
                          ? 'border-sky-500 scale-110 shadow-xs'
                          : 'border-slate-300 hover:scale-105'
                      }`}
                    />
                  ))}
                  <input
                    type="color"
                    value={primaryNode.fill.startsWith('#') ? primaryNode.fill : '#ffffff'}
                    onChange={(e) => updatePrimaryNode({ fill: e.target.value })}
                    className="w-6 h-6 p-0 border border-slate-300 rounded-md cursor-pointer"
                  />
                </div>
              </div>

              {/* Stroke swatches */}
              <div className="space-y-1.5">
                <span className="text-[11px] text-slate-500 block">Border Color</span>
                <div className="flex items-center gap-1.5 flex-wrap">
                  {COLOR_PALETTE.slice(7).map((c) => (
                    <button
                      key={`st-${c}`}
                      onClick={() => updatePrimaryNode({ stroke: c })}
                      style={{ backgroundColor: c }}
                      className={`w-6 h-6 rounded-md border transition-transform ${
                        primaryNode.stroke === c
                          ? 'border-sky-500 scale-110 shadow-xs'
                          : 'border-slate-300 hover:scale-105'
                      }`}
                    />
                  ))}
                  <input
                    type="color"
                    value={primaryNode.stroke.startsWith('#') ? primaryNode.stroke : '#334155'}
                    onChange={(e) => updatePrimaryNode({ stroke: e.target.value })}
                    className="w-6 h-6 p-0 border border-slate-300 rounded-md cursor-pointer"
                  />
                </div>
              </div>

              {/* Stroke Width & Style */}
              <div className="grid grid-cols-2 gap-2 pt-1">
                <select
                  value={primaryNode.strokeWidth}
                  onChange={(e) => updatePrimaryNode({ strokeWidth: Number(e.target.value) })}
                  className="w-full text-xs px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg outline-none"
                >
                  <option value={1}>1px Line</option>
                  <option value={1.5}>1.5px Standard</option>
                  <option value={2}>2px Bold</option>
                  <option value={3}>3px Heavy</option>
                </select>

                <select
                  value={primaryNode.strokeStyle}
                  onChange={(e) =>
                    updatePrimaryNode({ strokeStyle: e.target.value as StrokeStyle })
                  }
                  className="w-full text-xs px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg outline-none"
                >
                  <option value="solid">Solid</option>
                  <option value="dashed">Dashed</option>
                  <option value="dotted">Dotted</option>
                </select>
              </div>
            </div>

            {/* 3D Extrusion */}
            <div className="pt-2 border-t border-slate-100 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 font-semibold text-xs text-slate-700">
                  <Box className="w-3.5 h-3.5 text-slate-500" />
                  <span>3D Technical Depth</span>
                </div>
                <input
                  type="checkbox"
                  checked={Boolean(primaryNode.is3D || primaryNode.type.startsWith('3d-'))}
                  onChange={(e) => updatePrimaryNode({ is3D: e.target.checked })}
                  className="w-4 h-4 rounded text-sky-600 focus:ring-0 cursor-pointer"
                />
              </div>

              {(primaryNode.is3D || primaryNode.type.startsWith('3d-')) && (
                <div className="space-y-1 pt-1">
                  <div className="flex items-center justify-between text-[11px] text-slate-500">
                    <span>Extrusion</span>
                    <span className="font-mono">{primaryNode.depth3D || 12}px</span>
                  </div>
                  <input
                    type="range"
                    min={4}
                    max={28}
                    step={2}
                    value={primaryNode.depth3D || 12}
                    onChange={(e) => updatePrimaryNode({ depth3D: Number(e.target.value) })}
                    className="w-full accent-sky-600"
                  />
                </div>
              )}
            </div>
          </div>
        ) : primaryEdge ? (
          // ==========================================
          // 2. CONNECTOR PROPERTIES (CLEAN & SPACIOUS)
          // ==========================================
          <div className="space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <span className="font-bold text-sm text-slate-900">Connector Settings</span>
              <button
                onClick={onDeleteSelected}
                className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                title="Delete Connector"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>

            <div>
              <span className="text-slate-700 font-semibold text-xs block mb-1.5">
                Label Text
              </span>
              <input
                type="text"
                value={primaryEdge.label || ''}
                onChange={(e) => updatePrimaryEdge({ label: e.target.value })}
                placeholder="e.g. HTTPS / REST API / SQL"
                className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:bg-white focus:border-sky-500"
              />
            </div>

            {/* Routing & Arrowheads */}
            <div className="space-y-2">
              <span className="text-slate-700 font-semibold text-xs block">Style & Route</span>
              <select
                value={primaryEdge.lineType}
                onChange={(e) =>
                  updatePrimaryEdge({ lineType: e.target.value as ConnectorType })
                }
                className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg outline-none"
              >
                <option value="orthogonal">Orthogonal / Elbow</option>
                <option value="straight">Straight Line</option>
                <option value="curved">Curved Bézier</option>
              </select>

              <select
                value={primaryEdge.arrowType}
                onChange={(e) => updatePrimaryEdge({ arrowType: e.target.value as ArrowType })}
                className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg outline-none"
              >
                <option value="arrow">Single Arrow (→)</option>
                <option value="double-arrow">Bidirectional Arrow (⇄)</option>
                <option value="none">Plain Line (—)</option>
              </select>
            </div>
          </div>
        ) : (
          // ==========================================
          // 3. PAGE & REPORT PROPERTIES (REDESIGNED: CLEAN, SPACIOUS, EASY)
          // ==========================================
          <div className="space-y-5">
            {/* Header */}
            <div className="pb-1">
              <h3 className="font-bold text-sm text-slate-900">Page & Document</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Layout presets, alignment grid, and report metadata
              </p>
            </div>

            {/* Document Size Presets (Clean Segmented Grid) */}
            <div className="space-y-2">
              <span className="text-slate-700 font-semibold text-xs block">Page Preset</span>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'A4', label: 'A4 Report', desc: 'Standard Paper' },
                  { id: 'Letter', label: 'Letter', desc: 'US Document' },
                  { id: 'A3', label: 'A3 Poster', desc: 'Wide Architecture' },
                  { id: 'Infinite', label: 'Infinite', desc: 'Free Canvas' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      const preset = item.id as PagePreset;
                      let w = 1123;
                      let h = 794;
                      if (preset === 'A4') {
                        w = page.orientation === 'portrait' ? 794 : 1123;
                        h = page.orientation === 'portrait' ? 1123 : 794;
                      } else if (preset === 'A3') {
                        w = page.orientation === 'portrait' ? 1123 : 1587;
                        h = page.orientation === 'portrait' ? 1587 : 1123;
                      } else if (preset === 'Letter') {
                        w = page.orientation === 'portrait' ? 816 : 1056;
                        h = page.orientation === 'portrait' ? 1056 : 816;
                      } else if (preset === 'Infinite') {
                        w = 4000;
                        h = 4000;
                      }
                      onUpdatePage({ ...page, preset, width: w, height: h });
                    }}
                    className={`p-2.5 rounded-lg border text-left transition-all ${
                      page.preset === item.id
                        ? 'border-sky-500 bg-sky-50/60 shadow-2xs'
                        : 'border-slate-200 bg-slate-50/70 hover:bg-slate-100/70 text-slate-600'
                    }`}
                  >
                    <span className="font-semibold text-xs text-slate-900 block">
                      {item.label}
                    </span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">
                      {item.desc}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Orientation (Only if not infinite) */}
            {page.preset !== 'Infinite' && (
              <div className="space-y-1.5">
                <span className="text-slate-700 font-semibold text-xs block">Orientation</span>
                <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1 rounded-lg">
                  <button
                    onClick={() => {
                      if (page.orientation !== 'landscape') {
                        onUpdatePage({
                          ...page,
                          orientation: 'landscape',
                          width: page.height,
                          height: page.width,
                        });
                      }
                    }}
                    className={`py-1.5 rounded-md text-xs font-semibold transition-all ${
                      page.orientation === 'landscape'
                        ? 'bg-white text-slate-900 shadow-2xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Landscape
                  </button>
                  <button
                    onClick={() => {
                      if (page.orientation !== 'portrait') {
                        onUpdatePage({
                          ...page,
                          orientation: 'portrait',
                          width: page.height,
                          height: page.width,
                        });
                      }
                    }}
                    className={`py-1.5 rounded-md text-xs font-semibold transition-all ${
                      page.orientation === 'portrait'
                        ? 'bg-white text-slate-900 shadow-2xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Portrait
                  </button>
                </div>
              </div>
            )}

            {/* Grid & Alignment Card */}
            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
              <span className="font-semibold text-xs text-slate-800 block">
                Alignment & Snapping
              </span>

              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-600">Show Grid Dots</span>
                <input
                  type="checkbox"
                  checked={page.gridEnabled}
                  onChange={(e) => onUpdatePage({ ...page, gridEnabled: e.target.checked })}
                  className="w-4 h-4 rounded text-sky-600 focus:ring-0 cursor-pointer"
                />
              </div>

              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-600">Snap to Grid</span>
                <input
                  type="checkbox"
                  checked={page.snapToGrid}
                  onChange={(e) => onUpdatePage({ ...page, snapToGrid: e.target.checked })}
                  className="w-4 h-4 rounded text-sky-600 focus:ring-0 cursor-pointer"
                />
              </div>

              <div className="flex items-center justify-between pt-1">
                <span className="text-xs text-slate-600">Grid Size</span>
                <select
                  value={page.gridSize}
                  onChange={(e) => onUpdatePage({ ...page, gridSize: Number(e.target.value) })}
                  className="text-xs font-mono px-2 py-1 bg-white border border-slate-200 rounded-md outline-none"
                >
                  <option value={10}>10px Fine</option>
                  <option value={20}>20px Standard</option>
                  <option value={40}>40px Broad</option>
                </select>
              </div>
            </div>

            {/* Academic Report Figure Metadata (Clean & Uncluttered) */}
            <div className="p-3.5 bg-sky-50/50 rounded-xl border border-sky-100 space-y-3">
              <div className="flex items-center gap-1.5 text-sky-900 font-semibold text-xs">
                <FileText className="w-3.5 h-3.5 text-sky-700" />
                <span>Academic Figure Caption</span>
              </div>

              <div>
                <span className="text-[11px] text-slate-500 mb-1 block">Figure Number</span>
                <input
                  type="text"
                  value={page.figureNumber || ''}
                  onChange={(e) => onUpdatePage({ ...page, figureNumber: e.target.value })}
                  placeholder="e.g. Figure 3.1"
                  className="w-full text-xs px-3 py-1.5 bg-white border border-slate-200 rounded-lg outline-none focus:border-sky-500 font-semibold text-slate-900"
                />
              </div>

              <div>
                <span className="text-[11px] text-slate-500 mb-1 block">Figure Title Caption</span>
                <input
                  type="text"
                  value={page.figureCaption || ''}
                  onChange={(e) => onUpdatePage({ ...page, figureCaption: e.target.value })}
                  placeholder="System Architecture Overview"
                  className="w-full text-xs px-3 py-1.5 bg-white border border-slate-200 rounded-lg outline-none focus:border-sky-500 text-slate-800"
                />
              </div>

              <div className="flex items-center justify-between pt-1">
                <span className="text-[11px] text-slate-500">Caption Placement</span>
                <select
                  value={page.captionPosition || 'below'}
                  onChange={(e) =>
                    onUpdatePage({
                      ...page,
                      captionPosition: e.target.value as 'below' | 'above',
                    })
                  }
                  className="text-xs px-2 py-1 bg-white border border-slate-200 rounded-md outline-none"
                >
                  <option value="below">Below Diagram (Standard)</option>
                  <option value="above">Above Diagram</option>
                </select>
              </div>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
};
