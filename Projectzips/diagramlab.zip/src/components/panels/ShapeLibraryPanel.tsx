import React, { useState } from 'react';
import { Search, ChevronDown, ChevronRight, Plus, Box, Layers } from 'lucide-react';
import { SHAPE_CATEGORIES, SHAPE_REGISTRY } from '../../shapes/registry';
import { ShapeCategory, ShapeType } from '../../types/diagram';
import { RenderShapeSvg } from '../../shapes/renderers';

interface ShapeLibraryPanelProps {
  onAddShape: (shapeType: ShapeType) => void;
  isOpen: boolean;
  onToggleOpen: () => void;
}

export const ShapeLibraryPanel: React.FC<ShapeLibraryPanelProps> = ({
  onAddShape,
  isOpen,
  onToggleOpen,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<ShapeCategory | 'all'>('all');
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({
    software: true,
    flowchart: true,
    'technical-3d': true,
    database: true,
    uml: false,
    network: false,
    basic: false,
  });

  const allShapes = Object.values(SHAPE_REGISTRY);

  const filteredShapes = allShapes.filter((shape) => {
    const matchesCategory = selectedCategory === 'all' || shape.category === selectedCategory;
    const matchesSearch =
      !searchQuery ||
      shape.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      shape.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const toggleCategoryExpand = (catId: string) => {
    setExpandedCategories((prev) => ({ ...prev, [catId]: !prev[catId] }));
  };

  if (!isOpen) {
    return (
      <div className="w-10 bg-white border-r border-slate-200 flex flex-col items-center py-3 shrink-0">
        <button
          onClick={onToggleOpen}
          className="p-1.5 rounded hover:bg-slate-100 text-slate-600 transition-colors"
          title="Open Shape Library"
        >
          <Box className="w-5 h-5" />
        </button>
      </div>
    );
  }

  return (
    <aside className="w-68 bg-white border-r border-slate-200 flex flex-col h-full shrink-0 z-20">
      {/* Header */}
      <div className="p-3 border-b border-slate-200 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-slate-700" />
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-800">
            Shape Library
          </h2>
        </div>
        <button
          onClick={onToggleOpen}
          className="text-xs text-slate-400 hover:text-slate-700 p-1"
          title="Collapse Panel"
        >
          ✕
        </button>
      </div>

      {/* Search Input */}
      <div className="p-2.5 border-b border-slate-100">
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search 50+ technical shapes..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full text-xs pl-8 pr-2 py-1.5 bg-slate-50 border border-slate-200 rounded-md outline-none focus:border-sky-500 focus:bg-white transition-colors"
          />
        </div>
      </div>

      {/* Category Pills Filter */}
      <div className="px-2.5 py-1.5 border-b border-slate-100 flex items-center gap-1 overflow-x-auto text-[11px] scrollbar-none">
        <button
          onClick={() => setSelectedCategory('all')}
          className={`px-2 py-0.5 rounded whitespace-nowrap transition-colors ${
            selectedCategory === 'all'
              ? 'bg-slate-900 text-white font-medium'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          All
        </button>
        {SHAPE_CATEGORIES.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-2 py-0.5 rounded whitespace-nowrap transition-colors ${
              selectedCategory === cat.id
                ? 'bg-slate-900 text-white font-medium'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            {cat.name.replace(' Shapes', '').replace(' Diagrams', '')}
          </button>
        ))}
      </div>

      {/* Shape Grid List */}
      <div className="flex-1 overflow-y-auto p-2.5 space-y-4">
        {selectedCategory === 'all' && !searchQuery ? (
          // Grouped by Category View
          SHAPE_CATEGORIES.map((cat) => {
            const catShapes = allShapes.filter((s) => s.category === cat.id);
            const isExpanded = expandedCategories[cat.id] ?? true;

            return (
              <div key={cat.id} className="space-y-1.5">
                <button
                  onClick={() => toggleCategoryExpand(cat.id)}
                  className="w-full flex items-center justify-between text-left text-xs font-semibold text-slate-700 py-1 px-1 rounded hover:bg-slate-50 transition-colors"
                >
                  <span className="flex items-center gap-1.5">
                    {isExpanded ? (
                      <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                    ) : (
                      <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                    )}
                    {cat.name}
                  </span>
                  <span className="text-[10px] text-slate-400 font-normal">
                    {catShapes.length}
                  </span>
                </button>

                {isExpanded && (
                  <div className="grid grid-cols-2 gap-1.5 pt-1">
                    {catShapes.map((shape) => (
                      <button
                        key={shape.id}
                        onClick={() => onAddShape(shape.id)}
                        className="group flex flex-col items-center justify-between p-2 rounded border border-slate-200 bg-white hover:border-sky-500 hover:shadow-xs transition-all text-left"
                        title={`${shape.name} — ${shape.description}`}
                      >
                        <div className="w-full h-12 flex items-center justify-center pointer-events-none p-1">
                          <RenderShapeSvg
                            node={{
                              id: 'preview',
                              type: shape.id,
                              category: shape.category,
                              label: '',
                              x: 0,
                              y: 0,
                              width: 60,
                              height: 38,
                              fill: shape.defaultFill,
                              stroke: shape.defaultStroke,
                              strokeWidth: 1.5,
                              strokeStyle: 'solid',
                              zIndex: 1,
                              depth3D: 8,
                            }}
                          />
                        </div>
                        <span className="w-full text-center text-[10px] font-medium text-slate-700 truncate group-hover:text-sky-700 mt-1">
                          {shape.name}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            );
          })
        ) : (
          // Filtered list
          <div className="grid grid-cols-2 gap-1.5">
            {filteredShapes.map((shape) => (
              <button
                key={shape.id}
                onClick={() => onAddShape(shape.id)}
                className="group flex flex-col items-center justify-between p-2 rounded border border-slate-200 bg-white hover:border-sky-500 hover:shadow-xs transition-all text-left"
                title={`${shape.name} — ${shape.description}`}
              >
                <div className="w-full h-12 flex items-center justify-center pointer-events-none p-1">
                  <RenderShapeSvg
                    node={{
                      id: 'preview',
                      type: shape.id,
                      category: shape.category,
                      label: '',
                      x: 0,
                      y: 0,
                      width: 60,
                      height: 38,
                      fill: shape.defaultFill,
                      stroke: shape.defaultStroke,
                      strokeWidth: 1.5,
                      strokeStyle: 'solid',
                      zIndex: 1,
                      depth3D: 8,
                    }}
                  />
                </div>
                <span className="w-full text-center text-[10px] font-medium text-slate-700 truncate group-hover:text-sky-700 mt-1">
                  {shape.name}
                </span>
              </button>
            ))}
            {filteredShapes.length === 0 && (
              <div className="col-span-2 text-center py-6 text-xs text-slate-400">
                No shapes found matching &quot;{searchQuery}&quot;
              </div>
            )}
          </div>
        )}
      </div>

      {/* Quick Tips Footer */}
      <div className="p-2.5 bg-slate-50 border-t border-slate-200 text-[11px] text-slate-500">
        <p className="leading-relaxed">
          <strong className="text-slate-700">Tip:</strong> Click any shape to place it on the canvas, or drag from connection handles to link nodes.
        </p>
      </div>
    </aside>
  );
};
