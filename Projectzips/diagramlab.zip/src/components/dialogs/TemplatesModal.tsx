import React, { useState } from 'react';
import { TEMPLATE_CATALOG, TemplateDefinition } from '../../templates/catalog';
import {
  LayoutGrid,
  Plus,
  ArrowRight,
  X,
  Search,
  Check,
  FileText,
  Sparkles,
  Layers,
} from 'lucide-react';
import { DiagramLabLogo } from '../common/DiagramLabLogo';

interface TemplatesModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyTemplate: (template: TemplateDefinition, mode: 'new-page' | 'replace') => void;
}

export const TemplatesModal: React.FC<TemplatesModalProps> = ({
  isOpen,
  onClose,
  onApplyTemplate,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  if (!isOpen) return null;

  const categories = [
    { id: 'all', name: 'All Templates' },
    { id: 'software', name: 'Software Architecture' },
    { id: 'flowchart', name: 'Flowcharts' },
    { id: 'database', name: 'Database & ER' },
  ];

  const filteredTemplates = TEMPLATE_CATALOG.filter((t) => {
    const matchesCat = selectedCategory === 'all' || t.category === selectedCategory;
    const matchesSearch =
      !searchQuery ||
      t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xl w-full max-w-4xl overflow-hidden text-slate-800 animate-in fade-in zoom-in-95 duration-100 flex flex-col max-h-[85vh]">
        {/* Clean Header */}
        <div className="px-6 py-4 border-b border-slate-200 bg-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <DiagramLabLogo size="sm" />
            <div className="h-4 w-px bg-slate-200" />
            <div>
              <h3 className="text-sm font-bold text-slate-900">Technical Templates</h3>
              <p className="text-xs text-slate-500">
                Choose a peer-reviewed architectural or flowchart template to start editing
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter & Search Toolbar */}
        <div className="px-6 py-3 border-b border-slate-100 bg-slate-50 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          {/* Segmented Category Buttons */}
          <div className="flex items-center gap-1 bg-white p-1 rounded-lg border border-slate-200 w-full sm:w-auto">
            {categories.map((c) => (
              <button
                key={c.id}
                onClick={() => setSelectedCategory(c.id)}
                className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                  selectedCategory === c.id
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`}
              >
                {c.name}
              </button>
            ))}
          </div>

          {/* Search Box */}
          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search templates..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-xs pl-8 pr-3 py-1.5 bg-white border border-slate-200 rounded-lg outline-none focus:border-sky-500"
            />
          </div>
        </div>

        {/* Clean Spacious Cards Grid */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredTemplates.map((template) => {
              const nodeCount = template.page.nodes.length;
              const edgeCount = template.page.edges.length;

              return (
                <div
                  key={template.id}
                  className="group bg-white rounded-xl border border-slate-200 hover:border-sky-500 hover:shadow-md transition-all p-5 flex flex-col justify-between"
                >
                  <div className="space-y-2.5">
                    {/* Unboxed Metadata line */}
                    <div className="flex items-center justify-between text-xs text-slate-500">
                      <div className="flex items-center gap-1.5">
                        <span className="font-semibold text-sky-700 capitalize">
                          {template.category}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>{template.preset} {template.orientation}</span>
                      </div>
                      <span className="font-mono text-[11px] text-slate-400">
                        {nodeCount} shapes · {edgeCount} links
                      </span>
                    </div>

                    {/* Title */}
                    <h4 className="font-bold text-base text-slate-900 group-hover:text-sky-700 transition-colors">
                      {template.name}
                    </h4>

                    {/* Description */}
                    <p className="text-xs text-slate-600 leading-relaxed line-clamp-2">
                      {template.description}
                    </p>

                    {/* Academic Caption preview line */}
                    <div className="pt-2 text-[11px] text-slate-500 flex items-center gap-1">
                      <FileText className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="italic truncate font-serif">
                        {template.figureNumber} — {template.figureCaption}
                      </span>
                    </div>
                  </div>

                  {/* Clean Action Buttons */}
                  <div className="pt-4 border-t border-slate-100 mt-4 flex items-center justify-between gap-2">
                    <button
                      onClick={() => {
                        onApplyTemplate(template, 'new-page');
                        onClose();
                      }}
                      className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium text-slate-700 hover:bg-slate-100 transition-colors flex items-center gap-1"
                    >
                      <Plus className="w-3.5 h-3.5 text-slate-500" />
                      <span>Insert as New Page</span>
                    </button>

                    <button
                      onClick={() => {
                        onApplyTemplate(template, 'replace');
                        onClose();
                      }}
                      className="px-4 py-1.5 rounded-lg bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800 transition-colors shadow-xs flex items-center gap-1.5"
                    >
                      <span>Use Template</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {filteredTemplates.length === 0 && (
            <div className="text-center py-12 text-slate-400 text-xs">
              No templates found matching &ldquo;{searchQuery}&rdquo;.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
