import React, { useState } from 'react';
import { DiagramPage, DiagramProject } from '../../types/diagram';
import {
  downloadSvg,
  downloadPng,
  printAcademicPdf,
} from '../../lib/export';
import { exportProjectToJsonFile } from '../../lib/storage';
import { Download, FileCode2, Image, Printer, FileJson, X, Check } from 'lucide-react';

interface ExportModalProps {
  page: DiagramPage;
  project: DiagramProject;
  isOpen: boolean;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  page,
  project,
  isOpen,
  onClose,
}) => {
  const [format, setFormat] = useState<'svg' | 'png' | 'pdf' | 'json'>('svg');
  const [pngScale, setPngScale] = useState<1 | 2 | 3>(2);
  const [background, setBackground] = useState<'white' | 'transparent'>('white');
  const [includeCaption, setIncludeCaption] = useState(true);
  const [isExporting, setIsExporting] = useState(false);
  const [exportSuccess, setExportSuccess] = useState(false);

  if (!isOpen) return null;

  const handleExecuteExport = async () => {
    setIsExporting(true);
    setExportSuccess(false);

    try {
      if (format === 'svg') {
        downloadSvg(page, `${project.name}-${page.name}`);
      } else if (format === 'png') {
        await downloadPng(page, {
          scale: pngScale,
          background,
          filename: `${project.name}-${page.name}`,
        });
      } else if (format === 'pdf') {
        printAcademicPdf(page);
      } else if (format === 'json') {
        exportProjectToJsonFile(project);
      }

      setExportSuccess(true);
      setTimeout(() => {
        setExportSuccess(false);
      }, 2500);
    } catch (err) {
      console.error('Export error:', err);
      alert('Export failed. Please check diagram contents and try again.');
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-lg border border-slate-200 shadow-xl w-full max-w-md overflow-hidden text-slate-800 animate-in fade-in zoom-in-95 duration-100">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-2">
            <Download className="w-4 h-4 text-slate-700" />
            <h3 className="text-sm font-semibold text-slate-900">Export Diagram</h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1 rounded"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 space-y-4 text-xs">
          {/* Format Selection Cards */}
          <div>
            <label className="text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-2 block">
              Export Format
            </label>
            <div className="grid grid-cols-2 gap-2">
              {/* SVG */}
              <button
                onClick={() => setFormat('svg')}
                className={`p-3 rounded-lg border text-left flex flex-col gap-1 transition-all ${
                  format === 'svg'
                    ? 'border-sky-500 bg-sky-50/50 shadow-xs'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="flex items-center justify-between">
                  <FileCode2 className={`w-4 h-4 ${format === 'svg' ? 'text-sky-600' : 'text-slate-500'}`} />
                  <span className="text-[10px] font-mono uppercase px-1 py-0.2 bg-slate-100 rounded text-slate-600">
                    Vector
                  </span>
                </div>
                <span className="font-semibold text-slate-900 mt-1">SVG Document</span>
                <span className="text-[11px] text-slate-500">
                  Crisp scalable vector for web and publications
                </span>
              </button>

              {/* PNG */}
              <button
                onClick={() => setFormat('png')}
                className={`p-3 rounded-lg border text-left flex flex-col gap-1 transition-all ${
                  format === 'png'
                    ? 'border-sky-500 bg-sky-50/50 shadow-xs'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="flex items-center justify-between">
                  <Image className={`w-4 h-4 ${format === 'png' ? 'text-sky-600' : 'text-slate-500'}`} />
                  <span className="text-[10px] font-mono uppercase px-1 py-0.2 bg-slate-100 rounded text-slate-600">
                    Raster
                  </span>
                </div>
                <span className="font-semibold text-slate-900 mt-1">PNG Image</span>
                <span className="text-[11px] text-slate-500">
                  High-DPI rasterization (1x, 2x, 3x print)
                </span>
              </button>

              {/* PDF */}
              <button
                onClick={() => setFormat('pdf')}
                className={`p-3 rounded-lg border text-left flex flex-col gap-1 transition-all ${
                  format === 'pdf'
                    ? 'border-sky-500 bg-sky-50/50 shadow-xs'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="flex items-center justify-between">
                  <Printer className={`w-4 h-4 ${format === 'pdf' ? 'text-sky-600' : 'text-slate-500'}`} />
                  <span className="text-[10px] font-mono uppercase px-1 py-0.2 bg-emerald-50 text-emerald-700 rounded">
                    Report
                  </span>
                </div>
                <span className="font-semibold text-slate-900 mt-1">Academic PDF</span>
                <span className="text-[11px] text-slate-500">
                  Ready for project thesis and papers with captions
                </span>
              </button>

              {/* JSON */}
              <button
                onClick={() => setFormat('json')}
                className={`p-3 rounded-lg border text-left flex flex-col gap-1 transition-all ${
                  format === 'json'
                    ? 'border-sky-500 bg-sky-50/50 shadow-xs'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="flex items-center justify-between">
                  <FileJson className={`w-4 h-4 ${format === 'json' ? 'text-sky-600' : 'text-slate-500'}`} />
                  <span className="text-[10px] font-mono uppercase px-1 py-0.2 bg-slate-100 rounded text-slate-600">
                    Source
                  </span>
                </div>
                <span className="font-semibold text-slate-900 mt-1">Project JSON</span>
                <span className="text-[11px] text-slate-500">
                  Full editable .diagramlab document backup
                </span>
              </button>
            </div>
          </div>

          {/* Conditional Options */}
          {format === 'png' && (
            <div className="space-y-3 p-3 bg-slate-50 rounded-lg border border-slate-200">
              <div>
                <span className="text-[11px] text-slate-600 font-medium block mb-1.5">
                  Resolution / DPI Scale
                </span>
                <div className="grid grid-cols-3 gap-2">
                  {[1, 2, 3].map((s) => (
                    <button
                      key={s}
                      onClick={() => setPngScale(s as 1 | 2 | 3)}
                      className={`py-1.5 rounded border text-xs font-mono transition-colors ${
                        pngScale === s
                          ? 'border-sky-500 bg-white text-sky-800 font-bold shadow-2xs'
                          : 'border-slate-200 bg-slate-100 text-slate-600 hover:bg-white'
                      }`}
                    >
                      {s}x {s === 2 ? '(Retina)' : s === 3 ? '(300 DPI)' : '(Standard)'}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <span className="text-[11px] text-slate-600 font-medium block mb-1.5">
                  Background Color
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setBackground('white')}
                    className={`py-1 rounded border text-xs transition-colors ${
                      background === 'white'
                        ? 'border-sky-500 bg-white text-sky-800 font-medium'
                        : 'border-slate-200 bg-slate-100 text-slate-600'
                    }`}
                  >
                    Solid White
                  </button>
                  <button
                    onClick={() => setBackground('transparent')}
                    className={`py-1 rounded border text-xs transition-colors ${
                      background === 'transparent'
                        ? 'border-sky-500 bg-white text-sky-800 font-medium'
                        : 'border-slate-200 bg-slate-100 text-slate-600'
                    }`}
                  >
                    Transparent
                  </button>
                </div>
              </div>
            </div>
          )}

          {format === 'pdf' && (
            <div className="p-3 bg-sky-50/60 rounded-lg border border-sky-100 text-sky-900 space-y-1.5">
              <p className="font-semibold text-xs">Academic Report Preparation</p>
              <p className="text-[11px] text-sky-800 leading-relaxed">
                Will format diagram as <span className="font-semibold">{page.preset} {page.orientation}</span> with standard 15mm margins and embed caption:
                <br />
                <span className="italic font-serif font-medium mt-1 block">
                  &ldquo;{page.figureNumber || 'Figure 1'} — {page.figureCaption || page.name}&rdquo;
                </span>
              </p>
            </div>
          )}

          {/* Academic Caption Toggle for SVG / PNG */}
          {(format === 'svg' || format === 'png') && page.figureCaption && (
            <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-lg border border-slate-200">
              <div>
                <span className="text-xs font-medium text-slate-800 block">
                  Include Academic Figure Caption
                </span>
                <span className="text-[10px] text-slate-500 italic font-serif">
                  {page.figureNumber} — {page.figureCaption}
                </span>
              </div>
              <input
                type="checkbox"
                checked={includeCaption}
                onChange={(e) => setIncludeCaption(e.target.checked)}
                className="rounded text-sky-600 focus:ring-0"
              />
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-4 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <span className="text-[11px] text-slate-500">
            {exportSuccess ? (
              <span className="flex items-center gap-1 text-emerald-600 font-medium">
                <Check className="w-3.5 h-3.5" /> Downloaded successfully!
              </span>
            ) : (
              'Ready for immediate download'
            )}
          </span>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3 py-1.5 rounded border border-slate-200 text-xs font-medium text-slate-600 hover:bg-slate-100 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleExecuteExport}
              disabled={isExporting}
              className="px-4 py-1.5 rounded bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800 transition-colors shadow-xs flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{format === 'pdf' ? 'Print / Save PDF' : 'Download File'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
