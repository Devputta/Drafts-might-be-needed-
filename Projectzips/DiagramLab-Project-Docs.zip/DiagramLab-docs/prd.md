# DiagramLab — Product Requirements Document

## 1. Product summary

DiagramLab is a browser-based diagram editor designed around project documentation. It combines a large editable shape library, smart connectors, templates, page/layout controls, realistic styling, optional 3D depth, and report-ready export.

It is not primarily an AI image generator.

## 2. Problem

Students and project teams currently move between many tools to:
- find appropriate technical shapes
- create flowcharts
- make architecture diagrams
- create UML/ER diagrams
- format diagrams for reports
- export high-quality figures
- revise diagrams after feedback

Many generated diagrams also look visually artificial, generic, or inconsistent.

DiagramLab solves this with a single structured editor.

## 3. Goals

1. Make diagram creation approachable for beginners.
2. Give advanced users precise control.
3. Keep every diagram object editable.
4. Produce realistic human-designed visuals.
5. Support academic/report workflows.
6. Provide reusable templates and project files.
7. Make export reliable for print and digital reports.
8. Make optional AI assistance produce editable structure rather than raster images.

## 4. Non-goals

- Do not make AI-generated images the primary diagram format.
- Do not automatically redesign a user's work without permission.
- Do not force gradients, neon effects, excessive shadows, or decorative 3D.
- Do not hide diagram structure behind an image.
- Do not require AI for normal editing.

## 5. Main user journeys

### Journey A — Create from scratch
Dashboard → New Diagram → choose page → drag shapes → edit labels → connect → align → export.

### Journey B — Start from template
Dashboard → Templates → choose category → duplicate template → edit → export.

### Journey C — Text to editable diagram
User enters process description → optional AI parses it → editor creates nodes/edges → user reviews and edits → export.

### Journey D — Project report
Project workspace → create multiple diagram pages → set A4/A3/Letter → add figure captions → export selected pages or complete diagram PDF.

## 6. Functional requirements

### Canvas
- Pan
- Zoom
- Fit to screen
- Selection
- Multi-selection
- Drag
- Resize
- Rotate where supported
- Snap to grid
- Smart guides
- Undo/redo
- Copy/paste
- Duplicate
- Group/ungroup
- Lock/unlock
- Hide/show
- Delete
- Keyboard shortcuts

### Shape library

Basic:
- Rectangle
- Rounded rectangle
- Circle
- Ellipse
- Triangle
- Diamond
- Hexagon
- Pentagon
- Parallelogram
- Cylinder
- Document
- Folder
- Cloud

Flowchart:
- Start/End
- Process
- Decision
- Input/Output
- Predefined process
- Manual input
- Data
- Database
- Delay
- Connector

Software architecture:
- User
- Browser
- Mobile
- Frontend
- Backend
- API
- Server
- Database
- Cache
- Queue
- Storage
- Authentication
- Cloud
- Load balancer
- Service

UML:
- Actor
- Use case
- Class
- Interface
- Object
- Component
- Package
- State
- Activity

Network:
- Router
- Switch
- Firewall
- Server
- Desktop
- Laptop
- Mobile
- Internet
- Cloud

ER:
- Entity
- Attribute
- Relationship
- Primary key
- Foreign key

### Connectors
- Straight
- Orthogonal/elbow
- Curved
- Dashed
- Dotted
- Arrow
- Double arrow
- Labelled relationship
- Connection points
- Automatic rerouting

### Styling
- Border width
- Border type
- Fill
- Text
- Font
- Font size
- Alignment
- Corner radius
- Opacity
- Shadow
- Line style
- Arrow style
- 3D depth
- Perspective/depth options where supported

### Templates
Categories:
- Final year project
- Web application
- Mobile application
- AI/ML
- IoT
- Data science
- Cloud
- Software architecture
- Research methodology
- Business workflow
- Network
- UML
- ER
- Database
- Deployment

### Pages
- Multiple diagram pages per project
- Page names
- Page duplication
- Reordering
- Page size
- Portrait/landscape
- Margins
- Background
- Grid settings

### Export
- SVG
- PNG
- JPG/WebP
- PDF
- Transparent background where appropriate
- A4/A3/Letter presets
- High-resolution export
- Figure caption
- Figure number
- Print-safe margins

## 7. Accounts

Optional account creation for MVP, but project persistence should support:
- Local temporary work
- Signed-in projects
- Autosave
- Project rename
- Duplicate
- Delete
- Restore where feasible

Authentication:
- Email/password
- Google sign-in
- Password reset

## 8. Accessibility

- Keyboard navigation
- Visible focus
- Accessible labels
- Color-independent meaning
- Sufficient contrast
- Reduced motion option
- Screen-reader friendly controls
- Keyboard shortcuts documented

## 9. Performance

Target:
- Editor should remain responsive with ordinary project diagrams.
- Avoid rerendering the entire canvas when one object changes.
- Use virtualization/lazy loading for large libraries.
- Debounce autosave.
- Do not store unnecessary raster copies of every object.

## 10. Acceptance criteria

A release is not complete unless:
- Shapes can be placed and edited.
- Connectors remain attached when objects move.
- Undo/redo works reliably.
- Save/load reproduces the diagram accurately.
- Export matches the canvas.
- Text remains readable.
- No accidental AI-generated decorative content appears.
- 3D styling is optional and editable.
- User can create a professional diagram without AI.
