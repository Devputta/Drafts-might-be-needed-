# DiagramLab — Shape Library Specification

## Shape categories

1. Basic
2. Flowchart
3. Software
4. UML
5. Database/ER
6. Network
7. Cloud
8. Research
9. Custom

## Every shape must define

- Unique type ID
- Human-readable name
- Category
- Default width
- Default height
- Renderer
- Connection points
- Editable text support
- Editable style support
- Export behavior
- Accessibility label

## Connection points

At minimum:
- top
- right
- bottom
- left

Where meaningful, shapes can expose additional points.

## Shape naming

Use conventional names.

Good:
- Database
- Process
- Decision
- API
- Server

Bad:
- Data Magic Box
- Smart AI Cylinder
- Super Process

## Custom shapes

Allow users to duplicate an existing shape and customize:
- label
- fill
- border
- icon where supported
- dimensions

Do not allow arbitrary unsafe HTML injection.

## 3D shape specification

A 3D object is composed of:
1. front face
2. side/top face(s)
3. optional shadow
4. text layer

All layers remain derived from the editable geometry.

Changing depth should recalculate the faces.

## Shape realism rule

A 3D object must still look like a technical diagram object.

It should not resemble:
- game assets
- toy graphics
- cartoon stickers
- marketing illustrations
