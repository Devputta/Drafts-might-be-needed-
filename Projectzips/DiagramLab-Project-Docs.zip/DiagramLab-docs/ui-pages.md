# DiagramLab — Page Specification

## Landing page

Sections:
- concise value proposition
- editor preview
- shape categories
- templates
- report export
- optional AI assistance
- CTA

Do not use fake product statistics.

## Dashboard

- New Diagram
- Recent Projects
- Templates
- Search
- Sort
- Project cards/list
- Empty state

## Editor

Layout:
- top toolbar
- left shape library
- center canvas
- right properties/layers panel
- bottom status bar

## Templates

Filters:
- Flowchart
- Architecture
- UML
- ER
- Network
- Research
- Project Report

## Project settings

- name
- description
- sharing
- members
- export defaults

## Settings

- account
- appearance
- keyboard shortcuts
- accessibility
- AI preferences

## AI assistant

Should appear as a useful panel, not a giant marketing feature.

Suggested flow:
Describe → Preview → Insert → Edit.

## Empty project

Show three actions:
- Start Blank
- Use Template
- Describe a Diagram

## Error states

Must be actionable and human-readable.
