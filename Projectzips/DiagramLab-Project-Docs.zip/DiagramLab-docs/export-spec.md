# DiagramLab — Export Specification

## Supported formats

### SVG
Primary vector export.

Requirements:
- preserve text
- preserve shapes
- preserve connectors
- preserve 3D vector geometry where supported

### PNG
Requirements:
- configurable scale
- transparent or solid background
- no clipping

### JPG/WebP
Useful for lightweight sharing.

### PDF
Primary academic report format.

## Page presets

- A4
- A3
- Letter
- Custom

## Orientation

- Portrait
- Landscape

## Report figure mode

Options:
- figure number
- caption
- caption position
- margins

Example:

Figure 4.1 — System Architecture of the Event Management Platform

## Export correctness

Before export:
- resolve fonts
- verify bounding boxes
- include all visible objects
- preserve connector endpoints
- prevent text clipping
- respect locked/hidden state

## Print quality

Provide a high-resolution mode.

Do not enlarge raster assets unnecessarily.

## Background

Allow:
- white
- transparent
- custom color

Academic templates should default to simple backgrounds.
