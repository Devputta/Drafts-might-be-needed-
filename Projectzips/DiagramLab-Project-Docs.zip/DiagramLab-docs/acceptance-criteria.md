# DiagramLab — Release Acceptance Criteria

## Editor

- [ ] User can create a blank diagram.
- [ ] User can add shapes.
- [ ] User can edit shape text.
- [ ] User can move shapes.
- [ ] User can resize shapes.
- [ ] User can delete shapes.
- [ ] User can connect shapes.
- [ ] Connections remain correct after movement.
- [ ] Undo/redo works.

## Design

- [ ] Interface does not look like a generic AI dashboard.
- [ ] No unnecessary gradients.
- [ ] No random decorative graphics.
- [ ] Technical shapes are recognizable.
- [ ] 3D is optional and restrained.
- [ ] Typography is consistent.
- [ ] Spacing is consistent.

## Persistence

- [ ] Projects save.
- [ ] Projects load.
- [ ] Diagram is unchanged after reload.
- [ ] Schema version is stored.

## Export

- [ ] SVG works.
- [ ] PNG works.
- [ ] PDF works.
- [ ] A4 works.
- [ ] Landscape works.
- [ ] Text is not clipped.
- [ ] Connectors are not misplaced.

## AI

- [ ] AI can produce structured nodes and edges.
- [ ] AI output is validated.
- [ ] Invalid output is rejected safely.
- [ ] AI never overwrites manual work silently.
- [ ] User can edit every generated object.

## Security

- [ ] Project authorization works.
- [ ] Users cannot access unauthorized projects.
- [ ] Imported SVG is sanitized.
- [ ] Secrets are not exposed client-side.

## Accessibility

- [ ] Keyboard focus works.
- [ ] Buttons have accessible names.
- [ ] Color is not the only source of meaning.
- [ ] Reduced motion is respected.

## Final realism test

A person should be able to create a diagram that looks appropriate for:
- a college project report
- a technical document
- a software architecture review
- a research presentation

without the result looking automatically generated.
