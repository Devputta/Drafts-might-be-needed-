# DiagramLab — Security Rules

## Authentication

Use secure managed authentication.

## Authorization

Every project operation must verify:
- authenticated user
- project membership
- role
- allowed operation

## Database

Use row-level security.

## Imports

Imported:
- SVG
- JSON
- images
- templates

must be validated.

## SVG safety

Never execute scripts embedded in imported SVG.

Sanitize unsafe attributes and external references.

## AI security

- Validate AI output.
- Limit request size.
- Rate limit.
- Keep provider secrets server-side.
- Never allow AI output to become executable code.

## File uploads

Validate:
- MIME type
- file extension
- file size

Do not trust client-provided MIME values alone.

## Sharing

Public share links must expose only intentionally shared content.

## Logging

Log security events without storing unnecessary sensitive information.
