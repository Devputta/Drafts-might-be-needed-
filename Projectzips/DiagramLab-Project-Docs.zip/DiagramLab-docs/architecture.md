# DiagramLab — Architecture

## 1. Recommended architecture

Browser
  ↓
Next.js application
  ├── Editor UI
  ├── Canvas/graph engine
  ├── Shape registry
  ├── Command/undo system
  ├── Export pipeline
  └── Optional AI assistant
          ↓
       API layer
          ↓
      Supabase
       ├── Auth
       ├── PostgreSQL
       └── Storage

## 2. Frontend modules

Suggested structure:

src/
  app/
  components/
    editor/
    canvas/
    toolbar/
    panels/
    dialogs/
    templates/
  features/
    shapes/
    connectors/
    projects/
    export/
    templates/
    ai/
  lib/
    editor/
    persistence/
    validation/
    permissions/
  types/

## 3. Diagram document model

A project contains pages.

A page contains:
- nodes
- edges
- groups
- guides
- metadata
- page settings

Conceptual node:

{
  id,
  type,
  position,
  size,
  rotation,
  text,
  style,
  data,
  zIndex,
  locked
}

Conceptual edge:

{
  id,
  source,
  target,
  sourceHandle,
  targetHandle,
  type,
  style,
  label,
  markers
}

## 4. Shape registry

Every shape should be registered through one consistent interface.

Example conceptual definition:

ShapeDefinition:
- id
- category
- displayName
- icon
- renderer
- defaultSize
- connectionPoints
- editableProperties
- exportBehavior

This avoids creating one-off shape implementations.

## 5. Rendering

Prefer SVG or vector primitives for technical shapes.

HTML can be used for complex interactive controls.

3D-looking shapes should be assembled from editable vector surfaces rather than exported images.

## 6. State management

Separate:
- document state
- UI state
- persistence state
- selection state
- transient interaction state

Do not mix autosave status with canvas rendering state.

## 7. Undo/redo

Use a command or immutable-history approach.

Commands should include:
- create node
- delete node
- move node
- resize node
- change style
- create edge
- delete edge
- group
- ungroup
- change page

## 8. Persistence

Store a validated diagram document.

Use schema versioning:

{
  "schemaVersion": 1,
  "project": {},
  "pages": []
}

Future migrations must transform older versions safely.

## 9. Security

- Validate all persisted document data.
- Never trust client permissions.
- Enforce authorization on the server/database.
- Sanitize user-provided SVG or imported content.
- Do not execute arbitrary HTML from imported diagrams.
- Rate-limit AI endpoints.
- Never expose secret API keys in browser code.

## 10. AI boundary

AI may return structured diagram instructions.

Example:
{
  "nodes": [...],
  "edges": [...]
}

The editor validates this structure before creating objects.

AI must never directly inject executable UI code.

## 11. Export architecture

Preferred:
Canvas document → deterministic renderer → SVG → raster/PDF as needed.

The export engine should use the same geometry and styles as the editor to minimize differences.

## 12. Deployment

Recommended:
- Vercel for application
- Supabase for database/auth/storage
- GitHub for source control

Keep environment variables server-side where required.
