# DiagramLab — AI Builder Rules

These rules are specifically for AI coding agents building DiagramLab.

## 1. AI is the implementation assistant, not the product designer

Do not invent a visual style on every task.

Follow the established design system.

## 2. Never generate fake screenshots

Do not create placeholder screenshots and pretend they represent the application.

Build the actual interface.

## 3. Do not generate raster diagram assets for editable objects

If asked to create a database, server, flowchart node, or 3D box:
- implement it as a real component
- keep text editable
- keep geometry editable
- keep connectors editable

## 4. Avoid "AI aesthetic"

Do not automatically use:
- purple/blue gradients
- glassmorphism everywhere
- glowing borders
- oversized rounded cards
- floating blobs
- excessive blur
- decorative stars
- random 3D illustrations
- meaningless dashboard statistics

## 5. Realistic product language

Use normal software terminology:
- New Diagram
- Open
- Save
- Export
- Duplicate
- Group
- Lock
- Align
- Arrange
- Properties
- Layers
- Templates

Avoid:
- Magic Canvas
- Neural Diagram Engine
- Quantum Workspace
unless explicitly part of a feature.

## 6. AI-to-diagram behavior

If the user asks AI to create a diagram:
1. Parse the description.
2. Produce structured nodes and edges.
3. Validate semantic types.
4. Show the result in the editor.
5. Let the user edit everything.
6. Never treat the AI result as authoritative.

## 7. AI must not invent project facts

If a user says:
"Create my college project architecture"

and no architecture details are supplied, ask for missing information or create a clearly labeled generic template.

Do not invent their actual technologies.

## 8. AI suggestions need traceability

Where practical, show:
"Generated from your description"

Do not imply that the diagram came from a verified technical specification.

## 9. AI must respect user's manual edits

After generation, manual edits are authoritative.

Never regenerate the entire diagram because one label changed.

## 10. AI must not overwrite silently

Before a destructive AI operation:
- preserve undo
- show preview or clear confirmation where appropriate

## 11. Code safety

AI coding agents must:
- validate external data
- use parameterized queries
- sanitize imported SVG
- avoid dangerously setting HTML
- protect server secrets
- enforce authorization
- validate file uploads

## 12. Do not over-engineer

AI must not add dependencies simply because they are popular.

Use existing project libraries where possible.

## 13. Test generated code

Important tests:
- node creation
- edge creation
- edge persistence
- undo/redo
- serialization
- deserialization
- export
- permission checks
- malformed AI response handling

## 14. AI output schema

AI should return a constrained JSON structure, not arbitrary code.

The application must validate:
- allowed node types
- allowed edge types
- numeric bounds
- string lengths
- supported style properties
- referenced node IDs

Reject invalid structures safely.
