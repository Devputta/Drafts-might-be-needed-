# DiagramLab

DiagramLab is a realistic, human-first web workspace for creating professional project diagrams.

## Product vision

Create flowcharts, system architecture diagrams, UML diagrams, ER diagrams, network diagrams, process maps, data-flow diagrams, and report-ready technical figures from editable shapes.

DiagramLab must feel like a serious visual design tool, not an AI image generator.

## Core principle

**Real objects, real connectors, real editing.**

Every box, line, arrow, label, group, and 3D-style object must remain editable.

## Primary users

- Students preparing academic project reports
- Software developers documenting systems
- Researchers creating methodology diagrams
- Teachers and trainers
- Startup teams
- Technical writers
- Anyone who needs a clean project diagram

## Core stack

Recommended:
- Next.js
- React
- TypeScript
- Tailwind CSS
- React Flow or a comparable graph/canvas engine
- SVG for scalable diagram objects
- Supabase Auth/Postgres/Storage
- Client-side export where practical
- Server-side export for complex PDF workflows

See `architecture.md`, `prd.md`, and `rules.md`.
