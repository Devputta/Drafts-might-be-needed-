# DiagramLab — Data Model

## User

- id
- email
- display_name
- avatar_url
- created_at
- updated_at

## Project

- id
- owner_id
- name
- description
- created_at
- updated_at
- deleted_at

## ProjectMember

- project_id
- user_id
- role

Roles:
- owner
- editor
- viewer

## DiagramPage

- id
- project_id
- name
- order_index
- page_width
- page_height
- orientation
- background
- grid_enabled
- grid_size
- created_at
- updated_at

## DiagramDocument

Can be stored as structured JSON associated with a page.

Required:
- schema_version
- nodes
- edges
- groups
- metadata

## Template

- id
- name
- category
- description
- preview_asset
- document_json
- visibility
- created_at

## ExportJob

- id
- project_id
- page_id
- format
- status
- requested_at
- completed_at
- error_message

## AIRequest

- id
- user_id
- project_id
- request_type
- input_summary
- output_json
- status
- created_at

Never store secrets in this table.

## Security

Use row-level security for user-owned projects and project membership.

Users must not be able to access another user's project by changing an ID in a request.
