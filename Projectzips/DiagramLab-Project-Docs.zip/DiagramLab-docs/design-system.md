# DiagramLab — Design System

## Design philosophy

DiagramLab should resemble a mature technical tool: calm, precise, practical, and intentionally designed.

## Visual hierarchy

Primary:
- canvas

Secondary:
- shape library
- properties panel
- toolbar

Tertiary:
- menus
- dialogs
- status information

The canvas must always receive the most visual attention.

## Typography

Use a clean UI font.

Recommended:
- Inter
- Geist
- system UI fallback

Do not use decorative fonts for the editor.

## Color

Use a restrained neutral foundation.

Suggested roles:
- background
- surface
- border
- primary text
- secondary text
- accent
- danger
- success
- warning

Do not assign a different bright color to every shape.

## Borders

Prefer subtle borders.

Selection should be visually distinct without becoming a neon outline.

## Shadows

Use shadows primarily to communicate elevation:
- dialogs
- floating menus
- selected 3D depth
- important surfaces

Do not put large shadows on every object.

## Shapes

Default technical shape:
- readable fill
- clear border
- comfortable text padding
- consistent corner treatment

## Connectors

Connectors should be visually quieter than nodes.

They must not overpower the diagram.

## 3D objects

3D depth:
- 6–18px typical extrusion
- restrained shadow
- simple side faces
- no glossy reflections by default

## Grid

Grid should be subtle.

It should assist alignment without becoming the main visual element.

## Selection

Selection should clearly show:
- bounding box
- resize handles
- rotation control if supported
- connection handles where appropriate

## Toolbar

Keep common actions visible:
- Select
- Hand/Pan
- Undo
- Redo
- Zoom
- Shapes
- Connector
- Text
- Arrange
- Export

Advanced actions belong in contextual menus.

## Responsive behavior

Desktop:
full editor.

Tablet:
collapsible side panels.

Mobile:
canvas-focused compact editor with bottom sheets for properties.

## Motion

Use short, functional transitions.

No continuous decorative animation.

Respect reduced-motion settings.
