# DiagramLab — Master Development Rules

These rules apply to every implementation task.

## Rule 1 — Human-designed appearance

The website must look like a real professional software product.

Do not make it look like:
- an AI-generated website
- a generic AI dashboard
- a futuristic sci-fi interface
- a template full of gradients
- a random collection of colorful cards

Prefer:
- restrained colors
- clear hierarchy
- practical controls
- consistent spacing
- believable editor interactions
- subtle borders
- restrained shadows

## Rule 2 — Every object must be real

Every box must be a real editable object.

Every connector must be a real editable edge.

Every label must remain editable text.

Never flatten a diagram into an image during normal editing.

## Rule 3 — No decorative AI artifacts

Do not add:
- random floating shapes
- meaningless icons
- fake data
- fake diagrams
- decorative arrows
- unexplained symbols
- unnecessary 3D objects
- random gradients

If an object has no functional or communicative purpose, do not add it.

## Rule 4 — Consistency

Use the same:
- corner radius system
- border system
- typography scale
- connector behavior
- spacing rules
- icon family
- selection behavior

Do not let each component invent its own visual language.

## Rule 5 — 3D is a tool, not a theme

3D depth must be optional.

Use subtle perspective, extrusion, shadow, and side faces.

Avoid:
- cartoon 3D
- excessive bevels
- glossy plastic
- neon glow
- floating holograms

## Rule 6 — Technical accuracy

Shape meanings must match conventional diagram practices.

Do not use a database cylinder to represent a random process.

Do not use a decision diamond for ordinary text.

Templates must use semantically appropriate symbols.

## Rule 7 — User control

Never automatically change user work without:
- an explicit command
- preview where appropriate
- undo support

AI suggestions must be reviewable.

## Rule 8 — Realistic text

Do not fill templates with nonsense such as:
"AI Process Engine"
"Smart Data Intelligence"
"Next Generation Cloud"

Use realistic labels such as:
"User Authentication"
"PostgreSQL Database"
"Payment API"
"Attendance Service"

## Rule 9 — No fake functionality

Do not display buttons that do nothing.

Do not show fake export progress.

Do not claim a file was saved when it was not saved.

Do not create fake collaboration indicators.

## Rule 10 — Empty states

Empty states must explain what the user can actually do.

Example:
"Start with a shape, choose a template, or describe a workflow to create an editable diagram."

## Rule 11 — Error handling

Errors must explain:
- what happened
- why it happened where known
- how to fix it

Avoid generic "Something went wrong" where a useful explanation is possible.

## Rule 12 — Accessibility

Do not communicate meaning using color alone.

Keyboard interaction must be considered from the beginning.

## Rule 13 — Export fidelity

What users see on the canvas should closely match exported output.

No missing fonts, clipped text, misplaced arrows, or unexpected backgrounds.

## Rule 14 — Performance

Do not optimize by breaking correctness.

But also do not rerender the complete editor for every mouse movement.

## Rule 15 — Mobile

The editor should support tablet/mobile use sensibly, but desktop is the primary full-editor environment.

Mobile should provide:
- viewing
- basic editing
- selection
- text editing
- simple shape insertion
- export

## Rule 16 — AI-generated code quality

AI coding agents must:
- inspect existing architecture before changing it
- reuse components
- avoid duplicate implementations
- preserve working features
- type all public data structures
- validate inputs
- add tests for important editor logic
- avoid unnecessary dependencies
- avoid rewriting the project without reason

## Rule 17 — Never silently remove features

Before changing an existing feature:
- understand its current behavior
- preserve compatible behavior
- document intentional breaking changes

## Rule 18 — No unnecessary complexity

Build the simplest reliable version first.

Do not introduce:
- microservices
- complex event buses
- unnecessary state libraries
- unnecessary animation frameworks

unless a real requirement justifies them.

## Rule 19 — Design review checkpoint

Before calling a page complete, inspect:
- spacing
- alignment
- typography
- icon consistency
- empty states
- hover/focus states
- error states
- loading states
- responsive behavior

## Rule 20 — Final quality test

Ask:
"Would a student confidently put this diagram in a final-year project report?"

If the answer is no, improve the visual clarity rather than adding more effects.
