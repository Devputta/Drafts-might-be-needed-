import { useEffect, useState } from 'react';
import { 
  UserProfile, 
  Department, 
  CampusEvent, 
  EventRegistration, 
  Ticket, 
  Notice,
  SubjectAttendanceSummary
} from './types/index.js';
import { api } from './lib/api.js';
import { Header } from './components/Header.js';
import { Sidebar } from './components/Sidebar.js';
import { LoginView } from './components/LoginView.js';
import { DashboardView } from './components/DashboardView.js';
import { ERPAttendanceView } from './components/ERPAttendanceView.js';
import { ERPLeaveView } from './components/ERPLeaveView.js';
import { ERPMarksView } from './components/ERPMarksView.js';
import { ScheduleView } from './components/ScheduleView.js';
import { ResourcesView } from './components/ResourcesView.js';
import { EventsView } from './components/EventsView.js';
import { TicketsView } from './components/TicketsView.js';
import { NoticesView } from './components/NoticesView.js';
import { ServicesView } from './components/ServicesView.js';
import { AttendeesView } from './components/AttendeesView.js';
import { AdminAuditView } from './components/AdminAuditView.js';
import { TicketPassModal } from './components/TicketPassModal.js';
import { ScannerModal } from './components/ScannerModal.js';
import { ChangePasswordModal } from './components/ChangePasswordModal.js';
import { Building2 } from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [events, setEvents] = useState<CampusEvent[]>([]);
  const [notices, setNotices] = useState<Notice[]>([]);
  const [myRegistrations, setMyRegistrations] = useState<EventRegistration[]>([]);
  const [myTickets, setMyTickets] = useState<Ticket[]>([]);
  const [attendanceSummary, setAttendanceSummary] = useState<SubjectAttendanceSummary[]>([]);
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);

  // Modals
  const [activeTicketForModal, setActiveTicketForModal] = useState<Ticket | null>(null);
  const [scannerEvent, setScannerEvent] = useState<CampusEvent | null>(null);
  const [showChangePasswordModal, setShowChangePasswordModal] = useState<boolean>(false);

  const loadUserData = async (userId: string) => {
    try {
      const [regsRes, tktsRes, attRes] = await Promise.all([
        api.getMyRegistrations(),
        api.getMyTickets(),
        api.getStudentAttendance(userId)
      ]);
      setMyRegistrations(regsRes.registrations);
      setMyTickets(tktsRes.tickets);
      setAttendanceSummary(attRes.attendance);
    } catch (err) {
      console.error('Failed to load user specific data:', err);
    }
  };

  // Initial load
  const loadInitialData = async () => {
    setIsLoading(true);
    try {
      const [allUsersRes, deptRes, evRes, ntcRes] = await Promise.all([
        api.getAllUsers(),
        api.getDepartments(),
        api.getEvents(),
        api.getNotices()
      ]);

      setAllUsers(allUsersRes.users);
      setDepartments(deptRes.departments);
      setEvents(evRes.events);
      setNotices(ntcRes.notices);

      const meRes = await api.getMe();
      if (meRes.user) {
        setCurrentUser(meRes.user);
        await loadUserData(meRes.user.id);
      } else {
        setCurrentUser(null);
      }
    } catch (err) {
      console.error('Failed to load CampusOS state:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadInitialData();
  }, []);

  const handleLoginSuccess = async (user: UserProfile) => {
    setCurrentUser(user);
    setActiveTab('dashboard');
    await loadUserData(user.id);
  };

  const handleLogout = async () => {
    await api.logout();
    setCurrentUser(null);
    setMyRegistrations([]);
    setMyTickets([]);
    setAttendanceSummary([]);
    setActiveTab('dashboard');
  };

  const handleRefreshEvents = async () => {
    try {
      const [evRes, regsRes, tktsRes, ntcRes] = await Promise.all([
        api.getEvents(),
        api.getMyRegistrations(),
        api.getMyTickets(),
        api.getNotices()
      ]);
      setEvents(evRes.events);
      setMyRegistrations(regsRes.registrations);
      setMyTickets(tktsRes.tickets);
      setNotices(ntcRes.notices);

      if (currentUser) {
        const attRes = await api.getStudentAttendance(currentUser.id);
        setAttendanceSummary(attRes.attendance);
      }
    } catch (err) {
      console.error('Refresh error:', err);
    }
  };

  const handleSwitchUser = async (userId: string) => {
    setIsLoading(true);
    try {
      const res = await api.switchUser(userId);
      setCurrentUser(res.user);
      await loadUserData(res.user.id);

      // If switched to student while on staff-only tabs, redirect to dashboard
      if (res.user.role === 'STUDENT' && (activeTab === 'desk' || activeTab === 'admin' || activeTab === 'register')) {
        setActiveTab('dashboard');
      }
    } catch (err) {
      console.error('Switch user error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Initial loader
  if (isLoading && allUsers.length === 0) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-100 text-slate-800 font-sans">
        <div className="flex flex-col items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-blue-900 text-white shadow-xs">
            <Building2 className="h-6 w-6" />
          </div>
          <span className="text-sm font-semibold tracking-tight text-slate-900">Loading CampusOS Portal...</span>
          <span className="text-xs text-slate-500">Connecting to Academic & Student Information System</span>
        </div>
      </div>
    );
  }

  // Not logged in: Show Institutional Sign-In Screen
  if (!currentUser) {
    return (
      <LoginView
        onLoginSuccess={handleLoginSuccess}
        departments={departments}
      />
    );
  }

  const activePassCount = myTickets.filter(t => t.status === 'ISSUED').length;

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 flex flex-col font-sans antialiased selection:bg-blue-100 selection:text-blue-900">
      {/* Top Academic Header */}
      <Header
        currentUser={currentUser}
        allUsers={allUsers}
        onSwitchUser={handleSwitchUser}
        onLogout={handleLogout}
        onChangePassword={() => setShowChangePasswordModal(true)}
        myTickets={myTickets}
        myRegistrations={myRegistrations}
        events={events}
        onViewTicket={(tkt) => setActiveTicketForModal(tkt)}
        onOpenQuickScan={() => {
          if (events.length > 0) {
            setScannerEvent(events[0]);
          }
        }}
        onToggleMobileMenu={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
      />

      {/* Main ERP Work Area: Sidebar + Active Module */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Institutional Navigation */}
        <Sidebar
          activeTab={activeTab}
          onTabChange={setActiveTab}
          currentUser={currentUser}
          isOpenMobile={isMobileMenuOpen}
          onCloseMobile={() => setIsMobileMenuOpen(false)}
          ticketCount={activePassCount}
        />

        {/* Content Area */}
        <main className="flex-1 overflow-y-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="max-w-7xl mx-auto space-y-6">
            {activeTab === 'dashboard' && (
              <DashboardView
                currentUser={currentUser}
                events={events}
                notices={notices}
                myTickets={myTickets}
                attendance={attendanceSummary}
                onNavigateTab={setActiveTab}
                onViewTicket={(tkt) => setActiveTicketForModal(tkt)}
              />
            )}

            {activeTab === 'attendance' && (
              <ERPAttendanceView
                currentUser={currentUser}
              />
            )}

            {activeTab === 'register' && (
              <ERPAttendanceView
                currentUser={currentUser}
              />
            )}

            {activeTab === 'schedule' && (
              <ScheduleView
                departments={departments}
                currentUser={currentUser}
              />
            )}

            {activeTab === 'marks' && (
              <ERPMarksView
                currentUser={currentUser}
              />
            )}

            {activeTab === 'resources' && (
              <ResourcesView
                departments={departments}
                currentUser={currentUser}
              />
            )}

            {activeTab === 'events' && (
              <EventsView
                events={events}
                myRegistrations={myRegistrations}
                myTickets={myTickets}
                currentUser={currentUser}
                onRefresh={handleRefreshEvents}
                onViewTicket={(tkt) => setActiveTicketForModal(tkt)}
                onOpenScannerForEvent={(ev) => setScannerEvent(ev)}
              />
            )}

            {activeTab === 'tickets' && (
              <TicketsView
                tickets={myTickets}
                registrations={myRegistrations}
                onViewTicket={(tkt) => setActiveTicketForModal(tkt)}
                onRefresh={handleRefreshEvents}
              />
            )}

            {activeTab === 'leave' && (
              <ERPLeaveView
                currentUser={currentUser}
              />
            )}

            {activeTab === 'services' && (
              <ServicesView
                currentUser={currentUser}
              />
            )}

            {activeTab === 'notices' && (
              <NoticesView
                notices={notices}
                currentUser={currentUser}
                departments={departments}
                onRefresh={handleRefreshEvents}
              />
            )}

            {activeTab === 'desk' && (
              <AttendeesView
                events={events}
                currentUser={currentUser}
                onOpenScanner={(ev) => setScannerEvent(ev)}
              />
            )}

            {activeTab === 'admin' && (
              <AdminAuditView
                currentUser={currentUser}
                events={events}
                onRefreshEvents={handleRefreshEvents}
              />
            )}
          </div>
        </main>
      </div>

      {/* Ticket QR Modal */}
      {activeTicketForModal && (
        <TicketPassModal
          ticket={activeTicketForModal}
          onClose={() => setActiveTicketForModal(null)}
        />
      )}

      {/* Gate QR Scanner Modal */}
      {scannerEvent && (
        <ScannerModal
          event={scannerEvent}
          onClose={() => {
            setScannerEvent(null);
            handleRefreshEvents();
          }}
          onCheckInSuccess={() => {
            handleRefreshEvents();
          }}
        />
      )}

      {/* Change Password Modal */}
      {showChangePasswordModal && currentUser && (
        <ChangePasswordModal
          currentUser={currentUser}
          onClose={() => setShowChangePasswordModal(false)}
        />
      )}
    </div>
  );
}
