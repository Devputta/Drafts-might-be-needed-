import { useState } from 'react';
import { Notice, NoticePriority, Department, UserProfile } from '../types/index.js';
import { api } from '../lib/api.js';
import { Bell, Pin, AlertCircle, Plus, Calendar, User, CheckCircle2 } from 'lucide-react';

interface NoticesViewProps {
  notices: Notice[];
  departments: Department[];
  currentUser: UserProfile;
  onRefresh: () => void;
}

export function NoticesView({ notices, departments, currentUser, onRefresh }: NoticesViewProps) {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [filterPriority, setFilterPriority] = useState<string>('ALL');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // New Notice state
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [audience, setAudience] = useState<Notice['audience']>('ALL');
  const [priority, setPriority] = useState<NoticePriority>('NORMAL');
  const [pinned, setPinned] = useState(false);

  const canCreate = ['FACULTY', 'DEPARTMENT_ADMIN', 'COLLEGE_ADMIN', 'SUPER_ADMIN', 'ORGANIZER'].includes(currentUser.role);

  const handleCreateNotice = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await api.createNotice({
        title,
        body,
        audience,
        priority,
        pinned,
        department_id: audience === 'DEPARTMENT' ? currentUser.department_id : undefined
      });
      setShowCreateModal(false);
      setTitle('');
      setBody('');
      setSuccessMessage('Notice successfully broadcast to targeted audience.');
      setTimeout(() => setSuccessMessage(null), 4000);
      onRefresh();
    } catch (err) {
      console.error('Failed to create notice:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredNotices = notices.filter(n => {
    if (filterPriority !== 'ALL' && n.priority !== filterPriority) return false;
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">Official Notices & Circulars</h1>
          <p className="mt-1 text-xs text-slate-400">
            Institutional bulletins, exam schedules, and department announcements targeted to your enrollment.
          </p>
        </div>

        {canCreate && (
          <button
            onClick={() => setShowCreateModal(true)}
            className="inline-flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3.5 py-2 text-xs font-semibold text-white shadow-xs hover:bg-indigo-500 transition-colors"
          >
            <Plus className="h-4 w-4" />
            Publish Circular
          </button>
        )}
      </div>

      {successMessage && (
        <div className="flex items-center gap-2 rounded-lg border border-emerald-500/30 bg-emerald-950/40 px-4 py-3 text-xs text-emerald-200">
          <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Priority Filters */}
      <div className="flex items-center gap-1 overflow-x-auto p-1 bg-slate-900 border border-slate-800 rounded-lg no-scrollbar">
        {[
          { label: 'All Circulars', value: 'ALL' },
          { label: 'Urgent Notices', value: 'URGENT' },
          { label: 'Academic & Exams', value: 'ACADEMIC' },
          { label: 'General Bulletins', value: 'NORMAL' }
        ].map(p => (
          <button
            key={p.value}
            onClick={() => setFilterPriority(p.value)}
            className={`whitespace-nowrap px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              filterPriority === p.value
                ? 'bg-slate-800 text-white shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {p.label}
          </button>
        ))}
      </div>

      {/* Notices Stream */}
      <div className="space-y-4">
        {filteredNotices.map(notice => {
          const isUrgent = notice.priority === 'URGENT';
          const isAcademic = notice.priority === 'ACADEMIC';

          return (
            <div
              key={notice.id}
              className={`rounded-xl border p-5 shadow-xs transition-colors ${
                notice.pinned
                  ? 'border-indigo-500/40 bg-slate-900/90'
                  : isUrgent
                  ? 'border-red-900/50 bg-red-950/20'
                  : 'border-slate-800 bg-slate-900/60'
              }`}
            >
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-2 flex-1">
                  {/* Meta tag row (Zero-pill text separators) */}
                  <div className="flex items-center gap-2 text-xs">
                    {notice.pinned && (
                      <span className="flex items-center gap-1 text-[11px] font-semibold text-indigo-400">
                        <Pin className="h-3 w-3" /> Pinned Announcement
                        <span aria-hidden="true" className="text-slate-600">·</span>
                      </span>
                    )}

                    <span
                      className={`text-[11px] font-semibold uppercase tracking-wider ${
                        isUrgent ? 'text-red-400' : isAcademic ? 'text-amber-400' : 'text-slate-400'
                      }`}
                    >
                      {notice.priority}
                    </span>

                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span className="text-slate-400">Audience: {notice.audience}</span>
                    {notice.department_name && (
                      <>
                        <span aria-hidden="true" className="text-slate-600">·</span>
                        <span className="text-slate-400">{notice.department_name}</span>
                      </>
                    )}
                  </div>

                  <h3 className="text-base font-bold text-white tracking-tight">
                    {notice.title}
                  </h3>

                  <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-line">
                    {notice.body}
                  </p>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500">
                <div className="flex items-center gap-2">
                  <User className="h-3 w-3 text-slate-500" />
                  <span>Issued by: {notice.author_name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="h-3 w-3 text-slate-500" />
                  <span>{new Date(notice.published_at).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}</span>
                </div>
              </div>
            </div>
          );
        })}

        {filteredNotices.length === 0 && (
          <div className="rounded-xl border border-dashed border-slate-800 p-12 text-center">
            <Bell className="mx-auto h-8 w-8 text-slate-600" />
            <h3 className="mt-2 text-sm font-semibold text-slate-300">No circulars in this view</h3>
            <p className="mt-1 text-xs text-slate-500">All student circulars are up to date.</p>
          </div>
        )}
      </div>

      {/* Create Notice Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 p-4 backdrop-blur-xs">
          <div className="flex max-h-[92vh] w-full max-w-lg flex-col rounded-xl border border-slate-800 bg-slate-900 text-slate-100 shadow-2xl overflow-hidden">
            <div className="border-b border-slate-800 px-6 py-4 flex items-center justify-between">
              <h2 className="text-base font-bold text-white">Broadcast Campus Notice</h2>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-slate-400 hover:text-white text-xs"
              >
                Cancel
              </button>
            </div>

            <form onSubmit={handleCreateNotice} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Circular Title *</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Schedule for Special Makeup Laboratories"
                  className="w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-xs text-slate-100 focus:border-indigo-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Circular Content *</label>
                <textarea
                  rows={4}
                  required
                  value={body}
                  onChange={(e) => setBody(e.target.value)}
                  placeholder="Provide complete instructions, eligibility, and reporting timings."
                  className="w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-xs text-slate-100 focus:border-indigo-500 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Target Audience</label>
                  <select
                    value={audience}
                    onChange={(e) => setAudience(e.target.value as any)}
                    className="w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-xs text-slate-100 focus:border-indigo-500 focus:outline-hidden"
                  >
                    <option value="ALL">All Campus (Everyone)</option>
                    <option value="STUDENTS">Students Only</option>
                    <option value="FACULTY">Faculty Only</option>
                    <option value="DEPARTMENT">My Department Only</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Priority</label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as any)}
                    className="w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-xs text-slate-100 focus:border-indigo-500 focus:outline-hidden"
                  >
                    <option value="NORMAL">Normal</option>
                    <option value="ACADEMIC">Academic / Exam</option>
                    <option value="URGENT">Urgent Action</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="pinNotice"
                  checked={pinned}
                  onChange={(e) => setPinned(e.target.checked)}
                  className="rounded border-slate-700 bg-slate-800 text-indigo-600 focus:ring-0"
                />
                <label htmlFor="pinNotice" className="text-xs text-slate-300">
                  Pin to top of notice feed
                </label>
              </div>

              <div className="pt-4 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="rounded-lg px-3 py-2 text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="rounded-lg bg-indigo-600 px-4 py-2 text-xs font-semibold text-white hover:bg-indigo-500 disabled:opacity-50"
                >
                  {isSubmitting ? 'Publishing...' : 'Publish Notice'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
