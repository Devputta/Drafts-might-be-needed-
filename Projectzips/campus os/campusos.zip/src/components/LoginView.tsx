import { useState } from 'react';
import { UserProfile, Department } from '../types/index.js';
import { api } from '../lib/api.js';
import { 
  Building2, 
  Lock, 
  Mail, 
  AlertCircle, 
  CheckCircle2, 
  GraduationCap, 
  BookOpen, 
  ShieldCheck, 
  HelpCircle, 
  X, 
  Send,
  Sparkles
} from 'lucide-react';

interface LoginViewProps {
  onLoginSuccess: (user: UserProfile) => void;
  departments?: Department[];
}

type LoginPortalRole = 'STUDENT' | 'FACULTY' | 'ADMIN';

export function LoginView({ onLoginSuccess }: LoginViewProps) {
  const [selectedRole, setSelectedRole] = useState<LoginPortalRole>('STUDENT');
  const [identifier, setIdentifier] = useState('1CS22CS089');
  const [password, setPassword] = useState('password123');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Forgot password modal state
  const [showForgotModal, setShowForgotModal] = useState(false);
  const [forgotFullName, setForgotFullName] = useState('');
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotId, setForgotId] = useState('');
  const [forgotDept, setForgotDept] = useState('Computer Science & Engineering');
  const [forgotSemester, setForgotSemester] = useState('6');
  const [forgotRole, setForgotRole] = useState<'STUDENT' | 'FACULTY' | 'ADMIN'>('STUDENT');
  const [forgotReason, setForgotReason] = useState('Lost login key / need password reset for semester registration');
  const [forgotLoading, setForgotLoading] = useState(false);
  const [forgotSuccessMessage, setForgotSuccessMessage] = useState<string | null>(null);
  const [forgotErrorMessage, setForgotErrorMessage] = useState<string | null>(null);

  const handleRoleSelect = (role: LoginPortalRole) => {
    setSelectedRole(role);
    setError(null);
    if (role === 'STUDENT') {
      setIdentifier('1CS22CS089');
      setPassword('password123');
    } else if (role === 'FACULTY') {
      setIdentifier('arvind.venkat@campus.edu');
      setPassword('password123');
    } else {
      setIdentifier('dean.academics@campus.edu');
      setPassword('password123');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await api.login({ email: identifier, password });
      if (res.success && res.user) {
        onLoginSuccess(res.user);
      }
    } catch (err: any) {
      setError(err.message || 'Login failed. Please verify your credentials or request password assistance.');
    } finally {
      setLoading(false);
    }
  };

  const handleForgotSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotErrorMessage(null);
    setForgotSuccessMessage(null);
    setForgotLoading(true);

    try {
      const res = await api.forgotPassword({
        full_name: forgotFullName,
        email: forgotEmail,
        student_id_or_staff_id: forgotId,
        department_name: forgotDept,
        semester: Number(forgotSemester),
        role: forgotRole,
        reason: forgotReason
      });
      if (res.success) {
        setForgotSuccessMessage(
          `Request logged. IT Administration has received your registration details for Semester ${forgotSemester}, Department: ${forgotDept}. A randomized temporary password will be dispatched directly to ${forgotEmail}.`
        );
      }
    } catch (err: any) {
      setForgotErrorMessage(err.message || 'Failed to submit recovery request.');
    } finally {
      setForgotLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col justify-center py-10 sm:px-6 lg:px-8 text-slate-800 font-sans">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        {/* Institutional Crest / Logo */}
        <div className="inline-flex h-12 w-12 items-center justify-center rounded-lg bg-blue-900 text-white shadow-xs mb-2.5">
          <Building2 className="h-6 w-6" />
        </div>
        <h1 className="text-xl font-bold tracking-tight text-slate-900">
          CampusOS University Portal
        </h1>
        <p className="mt-0.5 text-xs text-slate-500">
          Academic Information & Student Administration System · AY 2026–27
        </p>
      </div>

      <div className="mt-6 sm:mx-auto sm:w-full sm:max-w-md px-4 sm:px-0">
        <div className="bg-white py-6 px-5 sm:px-8 shadow-xs border border-slate-200 rounded-lg">
          {/* Institutional Role Portals Tab Switcher */}
          <div className="mb-5">
            <span className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-2">
              Select Portal Gate
            </span>
            <div className="grid grid-cols-3 gap-1 bg-slate-100 p-1 rounded-md border border-slate-200 text-xs">
              <button
                type="button"
                onClick={() => handleRoleSelect('STUDENT')}
                className={`py-1.5 px-2 rounded font-medium flex items-center justify-center gap-1.5 transition-colors ${
                  selectedRole === 'STUDENT'
                    ? 'bg-blue-900 text-white font-semibold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                <GraduationCap className="h-3.5 w-3.5" />
                <span>Student</span>
              </button>

              <button
                type="button"
                onClick={() => handleRoleSelect('FACULTY')}
                className={`py-1.5 px-2 rounded font-medium flex items-center justify-center gap-1.5 transition-colors ${
                  selectedRole === 'FACULTY'
                    ? 'bg-blue-900 text-white font-semibold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                <BookOpen className="h-3.5 w-3.5" />
                <span>Professor</span>
              </button>

              <button
                type="button"
                onClick={() => handleRoleSelect('ADMIN')}
                className={`py-1.5 px-2 rounded font-medium flex items-center justify-center gap-1.5 transition-colors ${
                  selectedRole === 'ADMIN'
                    ? 'bg-blue-900 text-white font-semibold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                <ShieldCheck className="h-3.5 w-3.5" />
                <span>Dean / Admin</span>
              </button>
            </div>
          </div>

          {/* Section banner */}
          <div className="mb-4 pb-3 border-b border-slate-200">
            <h2 className="text-sm font-semibold text-slate-900">
              {selectedRole === 'STUDENT' && 'Student Academic Sign-In'}
              {selectedRole === 'FACULTY' && 'Faculty & Professor Sign-In'}
              {selectedRole === 'ADMIN' && 'Office of the Dean & Administration'}
            </h2>
            <p className="text-[11px] text-slate-500 mt-0.5">
              {selectedRole === 'STUDENT' && 'Enter your University Seat Number (USN) or student college email.'}
              {selectedRole === 'FACULTY' && 'Enter your faculty email or staff employee ID.'}
              {selectedRole === 'ADMIN' && 'Enter your institutional administrator or Dean office credentials.'}
            </p>
          </div>

          {error && (
            <div className="mb-4 flex items-start gap-2 rounded bg-red-50 border border-red-200 p-2.5 text-xs text-red-800">
              <AlertCircle className="h-4 w-4 text-red-600 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-3.5">
            <div>
              <label htmlFor="identifier" className="block text-xs font-medium text-slate-700">
                {selectedRole === 'STUDENT' ? 'USN / Student Email' : selectedRole === 'FACULTY' ? 'Faculty Email / Staff ID' : 'Administrative / Dean Email'}
              </label>
              <div className="mt-1 relative rounded shadow-xs">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Mail className="h-4 w-4" />
                </div>
                <input
                  id="identifier"
                  type="text"
                  required
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder={
                    selectedRole === 'STUDENT'
                      ? 'e.g. 1CS22CS089 or rahul.cs22@campus.edu'
                      : selectedRole === 'FACULTY'
                      ? 'e.g. arvind.venkat@campus.edu'
                      : 'e.g. dean.academics@campus.edu'
                  }
                  className="block w-full pl-9 pr-3 py-2 border border-slate-300 rounded text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-blue-800 focus:border-blue-800"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between">
                <label htmlFor="password" className="block text-xs font-medium text-slate-700">
                  Portal Password
                </label>
                <button
                  type="button"
                  onClick={() => {
                    setForgotRole(selectedRole);
                    setForgotErrorMessage(null);
                    setForgotSuccessMessage(null);
                    setShowForgotModal(true);
                  }}
                  className="text-[11px] font-medium text-blue-900 hover:underline"
                >
                  Forgot Password?
                </button>
              </div>
              <div className="mt-1 relative rounded shadow-xs">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Lock className="h-4 w-4" />
                </div>
                <input
                  id="password"
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="block w-full pl-9 pr-3 py-2 border border-slate-300 rounded text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-blue-800 focus:border-blue-800"
                />
              </div>
            </div>

            <div className="flex items-center justify-between text-xs pt-0.5">
              <label className="flex items-center gap-2 text-slate-600 cursor-pointer">
                <input
                  type="checkbox"
                  defaultChecked
                  className="h-3.5 w-3.5 rounded border-slate-300 text-blue-900 focus:ring-blue-900"
                />
                Keep session signed in
              </label>
              <span className="text-[11px] text-slate-400">Default: password123</span>
            </div>

            <div>
              <button
                type="submit"
                disabled={loading}
                className="w-full flex justify-center py-2 px-4 border border-transparent rounded shadow-xs text-xs font-semibold text-white bg-blue-900 hover:bg-blue-800 focus:outline-hidden focus:ring-2 focus:ring-offset-2 focus:ring-blue-900 disabled:opacity-50 transition-colors"
              >
                {loading ? 'Verifying Institutional Identity...' : `Sign In to ${selectedRole === 'STUDENT' ? 'Student Portal' : selectedRole === 'FACULTY' ? 'Professor Portal' : 'Admin & Dean Portal'}`}
              </button>
            </div>
          </form>

          {/* Institutional Password Reset Notice */}
          <div className="mt-5 pt-4 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500">
            <span>Lost access to college credentials?</span>
            <button
              type="button"
              onClick={() => {
                setForgotRole(selectedRole);
                setForgotErrorMessage(null);
                setForgotSuccessMessage(null);
                setShowForgotModal(true);
              }}
              className="font-medium text-blue-900 hover:underline inline-flex items-center gap-1"
            >
              <HelpCircle className="h-3 w-3" />
              Request Password Dispatch
            </button>
          </div>
        </div>

        <p className="mt-4 text-center text-[11px] text-slate-500">
          Authorized university network access only. System activity is logged under Academic IT Governance Regulations.
        </p>
      </div>

      {/* Forgot Password / Credential Recovery Modal */}
      {showForgotModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4">
          <div className="w-full max-w-lg bg-white rounded-lg shadow-xl border border-slate-300 overflow-hidden text-slate-800">
            {/* Modal Header */}
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200 bg-slate-50">
              <div className="flex items-center gap-2">
                <Building2 className="h-4 w-4 text-blue-900" />
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                  Institutional Credential & Password Dispatch Request
                </h3>
              </div>
              <button
                onClick={() => setShowForgotModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="p-5 space-y-4 max-h-[85vh] overflow-y-auto">
              <div className="text-xs text-slate-600 bg-blue-50 border border-blue-200 p-3 rounded leading-relaxed">
                <strong>University IT Procedure:</strong> Enter your registered Gmail, Semester, and Department. Once submitted, University Administration reviews your record and dispatches a randomized secure password directly to your Gmail address.
              </div>

              {forgotSuccessMessage ? (
                <div className="space-y-3 py-3">
                  <div className="flex items-start gap-2.5 p-3 rounded bg-emerald-50 border border-emerald-200 text-xs text-emerald-900">
                    <CheckCircle2 className="h-5 w-5 text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <div className="font-bold">Request Dispatched to Administration</div>
                      <p className="mt-1 leading-relaxed">{forgotSuccessMessage}</p>
                    </div>
                  </div>
                  <div className="text-[11px] text-slate-500">
                    You can close this window. Check your Gmail inbox or log in as Administration to view and dispatch the randomized password.
                  </div>
                  <div className="pt-2 flex justify-end">
                    <button
                      type="button"
                      onClick={() => setShowForgotModal(false)}
                      className="px-4 py-1.5 rounded bg-blue-900 text-white text-xs font-semibold hover:bg-blue-800"
                    >
                      Done
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleForgotSubmit} className="space-y-3.5 text-xs">
                  {forgotErrorMessage && (
                    <div className="flex items-start gap-2 p-2.5 rounded bg-red-50 border border-red-200 text-red-800">
                      <AlertCircle className="h-4 w-4 text-red-600 shrink-0 mt-0.5" />
                      <span>{forgotErrorMessage}</span>
                    </div>
                  )}

                  {/* Role Type */}
                  <div>
                    <label className="block font-medium text-slate-700 mb-1">
                      Academic Designation
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {(['STUDENT', 'FACULTY', 'ADMIN'] as const).map(r => (
                        <button
                          key={r}
                          type="button"
                          onClick={() => setForgotRole(r)}
                          className={`py-1.5 px-2 rounded border text-center font-medium ${
                            forgotRole === r
                              ? 'border-blue-900 bg-blue-50 text-blue-900 font-semibold'
                              : 'border-slate-200 bg-slate-50 text-slate-600'
                          }`}
                        >
                          {r === 'STUDENT' ? 'Student' : r === 'FACULTY' ? 'Professor' : 'Dean / Admin'}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Full Name */}
                  <div>
                    <label className="block font-medium text-slate-700 mb-1">
                      Full Legal Name (as per Admission Records) *
                    </label>
                    <input
                      type="text"
                      required
                      value={forgotFullName}
                      onChange={(e) => setForgotFullName(e.target.value)}
                      placeholder="e.g. Rahul Sharma"
                      className="w-full px-3 py-2 border border-slate-300 rounded text-xs text-slate-900 focus:ring-1 focus:ring-blue-800 focus:border-blue-800"
                    />
                  </div>

                  {/* Registered Gmail */}
                  <div>
                    <label className="block font-medium text-slate-700 mb-1">
                      Registered Student / Faculty Gmail Address *
                    </label>
                    <input
                      type="email"
                      required
                      value={forgotEmail}
                      onChange={(e) => setForgotEmail(e.target.value)}
                      placeholder="e.g. student.rahul@gmail.com or rahul.cs22@campus.edu"
                      className="w-full px-3 py-2 border border-slate-300 rounded text-xs text-slate-900 focus:ring-1 focus:ring-blue-800 focus:border-blue-800"
                    />
                    <span className="text-[10px] text-slate-500 mt-0.5 block">
                      The generated randomized password will be sent directly to this Gmail address.
                    </span>
                  </div>

                  {/* Student ID / USN */}
                  <div>
                    <label className="block font-medium text-slate-700 mb-1">
                      {forgotRole === 'STUDENT' ? 'Student USN / Roll Number' : 'Staff Employee ID'}
                    </label>
                    <input
                      type="text"
                      value={forgotId}
                      onChange={(e) => setForgotId(e.target.value)}
                      placeholder={forgotRole === 'STUDENT' ? 'e.g. 1CS22CS089' : 'e.g. FAC-CSE-012'}
                      className="w-full px-3 py-2 border border-slate-300 rounded text-xs text-slate-900 focus:ring-1 focus:ring-blue-800 focus:border-blue-800"
                    />
                  </div>

                  {/* Department & Semester */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-medium text-slate-700 mb-1">
                        Academic Department *
                      </label>
                      <select
                        value={forgotDept}
                        onChange={(e) => setForgotDept(e.target.value)}
                        className="w-full px-2.5 py-2 border border-slate-300 rounded text-xs text-slate-900 focus:ring-1 focus:ring-blue-800 focus:border-blue-800 bg-white"
                      >
                        <option value="Computer Science & Engineering">Computer Science & Engineering</option>
                        <option value="Electronics & Communication Engineering">Electronics & Communication Engineering</option>
                        <option value="Information Science & Engineering">Information Science & Engineering</option>
                        <option value="Mechanical Engineering">Mechanical Engineering</option>
                        <option value="Civil Engineering">Civil Engineering</option>
                        <option value="Dean Office / Central Administration">Dean Office / Central Administration</option>
                      </select>
                    </div>

                    <div>
                      <label className="block font-medium text-slate-700 mb-1">
                        Registered Semester
                      </label>
                      <select
                        value={forgotSemester}
                        onChange={(e) => setForgotSemester(e.target.value)}
                        className="w-full px-2.5 py-2 border border-slate-300 rounded text-xs text-slate-900 focus:ring-1 focus:ring-blue-800 focus:border-blue-800 bg-white"
                      >
                        <option value="1">Semester 1</option>
                        <option value="2">Semester 2</option>
                        <option value="3">Semester 3</option>
                        <option value="4">Semester 4</option>
                        <option value="5">Semester 5</option>
                        <option value="6">Semester 6</option>
                        <option value="7">Semester 7</option>
                        <option value="8">Semester 8</option>
                      </select>
                    </div>
                  </div>

                  {/* Reason */}
                  <div>
                    <label className="block font-medium text-slate-700 mb-1">
                      Reason for Reset Request
                    </label>
                    <textarea
                      rows={2}
                      value={forgotReason}
                      onChange={(e) => setForgotReason(e.target.value)}
                      placeholder="e.g. Lost credentials, device reset, semester registration assistance"
                      className="w-full px-3 py-1.5 border border-slate-300 rounded text-xs text-slate-900 focus:ring-1 focus:ring-blue-800 focus:border-blue-800"
                    />
                  </div>

                  <div className="pt-2 flex items-center justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setShowForgotModal(false)}
                      className="px-3 py-1.5 rounded border border-slate-300 text-slate-700 hover:bg-slate-50 text-xs font-medium"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={forgotLoading}
                      className="px-4 py-1.5 rounded bg-blue-900 text-white text-xs font-semibold hover:bg-blue-800 disabled:opacity-50 inline-flex items-center gap-1.5"
                    >
                      <Send className="h-3.5 w-3.5" />
                      {forgotLoading ? 'Submitting...' : 'Submit to Admin Registry'}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
