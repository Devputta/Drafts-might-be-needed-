import { CampusEvent, Notice, UserProfile, Ticket } from '../types/index.js';
import { 
  Building2, 
  GraduationCap, 
  Calendar, 
  QrCode, 
  BookOpen, 
  CheckCircle2, 
  ArrowRight, 
  Users, 
  Award, 
  Sparkles, 
  Clock, 
  MapPin, 
  Bell, 
  Compass, 
  FileText,
  LifeBuoy,
  ShieldCheck,
  TrendingUp,
  BarChart3
} from 'lucide-react';

interface CampusHomeViewProps {
  currentUser: UserProfile;
  events: CampusEvent[];
  notices: Notice[];
  myTickets: Ticket[];
  onNavigateTab: (tab: string) => void;
  onViewTicket: (ticket: Ticket) => void;
}

export function CampusHomeView({
  currentUser,
  events,
  notices,
  myTickets,
  onNavigateTab,
  onViewTicket
}: CampusHomeViewProps) {
  const activeTickets = myTickets.filter(t => t.status === 'ISSUED');
  const upcomingEvents = events.slice(0, 3);
  const pinnedNotices = notices.filter(n => n.pinned).slice(0, 2);

  return (
    <div className="space-y-10">
      {/* University Hero Section (Authentic College Website Hero) */}
      <section className="relative overflow-hidden rounded-2xl border border-slate-800 bg-linear-to-b from-slate-900 via-slate-900/90 to-slate-950 p-6 sm:p-10 shadow-2xl">
        {/* Subtle background glow */}
        <div className="absolute top-0 right-0 -mt-12 -mr-12 h-96 w-96 rounded-full bg-indigo-600/10 blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 rounded-full border border-indigo-500/30 bg-indigo-950/60 px-3 py-1 text-xs text-indigo-300">
            <Award className="h-3.5 w-3.5 text-indigo-400" />
            <span className="font-semibold">Autonomous Premier Engineering Campus · NAAC 'A++'</span>
          </div>

          <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white leading-tight">
            Centralized Academic & Campus Management System
          </h1>

          <p className="text-sm sm:text-base text-slate-300 leading-relaxed max-w-2xl">
            Welcome to the official university digital portal. Access your student ERP attendance, download certified course syllabi, manage digital QR event passes, and track exam schedules in one secure environment.
          </p>

          {/* Quick Action Tiles */}
          <div className="pt-3 flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigateTab('events')}
              className="inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-4 py-2.5 text-xs font-bold text-white shadow-lg hover:bg-indigo-500 transition-colors"
            >
              <Calendar className="h-4 w-4" />
              Events & QR Passes
              <ArrowRight className="h-3.5 w-3.5" />
            </button>

            <button
              onClick={() => onNavigateTab('attendance')}
              className="inline-flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-800/90 px-4 py-2.5 text-xs font-bold text-slate-200 hover:bg-slate-700 hover:text-white transition-colors"
            >
              <TrendingUp className="h-4 w-4 text-emerald-400" />
              ERP Attendance Tracker
            </button>

            <button
              onClick={() => onNavigateTab('schedule')}
              className="inline-flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-800/90 px-4 py-2.5 text-xs font-bold text-slate-200 hover:bg-slate-700 hover:text-white transition-colors"
            >
              <GraduationCap className="h-4 w-4 text-amber-400" />
              Class Timetable
            </button>
          </div>
        </div>

        {/* User Identity Banner Card */}
        <div className="mt-8 pt-6 border-t border-slate-800/80 grid grid-cols-1 sm:grid-cols-4 gap-4 text-xs">
          <div>
            <span className="text-slate-500 text-[11px] uppercase tracking-wider block">Logged In As</span>
            <span className="font-bold text-white text-sm mt-0.5 block">{currentUser.full_name}</span>
            <span className="text-indigo-400 font-mono text-[11px]">{currentUser.student_id || currentUser.role}</span>
          </div>

          <div>
            <span className="text-slate-500 text-[11px] uppercase tracking-wider block">Department & Term</span>
            <span className="font-semibold text-slate-200 mt-0.5 block">{currentUser.department_name}</span>
            <span className="text-slate-400 text-[11px]">Semester {currentUser.semester || 6} · Section A</span>
          </div>

          <div>
            <span className="text-slate-500 text-[11px] uppercase tracking-wider block">Active Event Passes</span>
            <span className="font-bold text-emerald-400 text-sm mt-0.5 block">{activeTickets.length} Issued</span>
            <span className="text-slate-400 text-[11px]">Cryptographic gate tickets</span>
          </div>

          <div className="sm:text-right">
            <span className="text-slate-500 text-[11px] uppercase tracking-wider block">Institutional Node</span>
            <span className="font-semibold text-slate-200 mt-0.5 block">CampusOS v2.4 ERP</span>
            <span className="text-emerald-400 text-[11px]">Verified Credentials</span>
          </div>
        </div>
      </section>

      {/* College Highlights & Statistics Strip */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-5">
          <div className="flex items-center gap-2 text-indigo-400 mb-1">
            <Users className="h-4 w-4" />
            <span className="text-xs font-semibold uppercase tracking-wider">Student Body</span>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-white">4,850+</div>
          <p className="text-xs text-slate-400 mt-1">Undergraduate & postgraduate engineers</p>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-5">
          <div className="flex items-center gap-2 text-emerald-400 mb-1">
            <Award className="h-4 w-4" />
            <span className="text-xs font-semibold uppercase tracking-wider">Accreditation</span>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-white">NAAC A++</div>
          <p className="text-xs text-slate-400 mt-1">Highest collegiate autonomous grade</p>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-5">
          <div className="flex items-center gap-2 text-amber-400 mb-1">
            <TrendingUp className="h-4 w-4" />
            <span className="text-xs font-semibold uppercase tracking-wider">Placements</span>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-white">98.4%</div>
          <p className="text-xs text-slate-400 mt-1">Tier-1 campus recruitment record</p>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-5">
          <div className="flex items-center gap-2 text-indigo-400 mb-1">
            <GraduationCap className="h-4 w-4" />
            <span className="text-xs font-semibold uppercase tracking-wider">Faculty</span>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-white">185+</div>
          <p className="text-xs text-slate-400 mt-1">Ph.D. research faculty and guides</p>
        </div>
      </section>

      {/* Primary ERP Navigation Cards Grid */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-white tracking-tight">Enterprise ERP Modules</h2>
            <p className="text-xs text-slate-400">Streamlining collegiate workflows for students, faculty, and administration.</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {/* Card 1: Attendance */}
          <div 
            onClick={() => onNavigateTab('attendance')}
            className="group cursor-pointer rounded-xl border border-slate-800 bg-slate-900/70 p-5 hover:border-indigo-500/50 hover:bg-slate-900 transition-all space-y-3"
          >
            <div className="flex items-center justify-between">
              <div className="h-10 w-10 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <TrendingUp className="h-5 w-5" />
              </div>
              <span className="text-xs font-semibold text-emerald-400 group-hover:translate-x-0.5 transition-transform flex items-center gap-1">
                Open <ArrowRight className="h-3 w-3" />
              </span>
            </div>
            <div>
              <h3 className="font-bold text-white text-base">ERP Attendance Tracker</h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Review subject-wise class attendance percentages, monitor the 75% exam threshold, and submit roll call registers.
              </p>
            </div>
          </div>

          {/* Card 2: Events & Passes */}
          <div 
            onClick={() => onNavigateTab('events')}
            className="group cursor-pointer rounded-xl border border-slate-800 bg-slate-900/70 p-5 hover:border-indigo-500/50 hover:bg-slate-900 transition-all space-y-3"
          >
            <div className="flex items-center justify-between">
              <div className="h-10 w-10 rounded-lg bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
                <Calendar className="h-5 w-5" />
              </div>
              <span className="text-xs font-semibold text-indigo-400 group-hover:translate-x-0.5 transition-transform flex items-center gap-1">
                Open <ArrowRight className="h-3 w-3" />
              </span>
            </div>
            <div>
              <h3 className="font-bold text-white text-base">Campus Events & Entry Passes</h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Discover workshops, symposiums, and national hackathons with single-entry cryptographic QR ticket credentials.
              </p>
            </div>
          </div>

          {/* Card 3: Internal Assessment Marks */}
          <div 
            onClick={() => onNavigateTab('marks')}
            className="group cursor-pointer rounded-xl border border-slate-800 bg-slate-900/70 p-5 hover:border-indigo-500/50 hover:bg-slate-900 transition-all space-y-3"
          >
            <div className="flex items-center justify-between">
              <div className="h-10 w-10 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                <BarChart3 className="h-5 w-5" />
              </div>
              <span className="text-xs font-semibold text-amber-400 group-hover:translate-x-0.5 transition-transform flex items-center gap-1">
                Open <ArrowRight className="h-3 w-3" />
              </span>
            </div>
            <div>
              <h3 className="font-bold text-white text-base">Continuous Evaluation (CIE) Marks</h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Check continuous internal evaluation test scores, assignment marks, and certified provisional semester grades.
              </p>
            </div>
          </div>

          {/* Card 4: Academic Schedule */}
          <div 
            onClick={() => onNavigateTab('schedule')}
            className="group cursor-pointer rounded-xl border border-slate-800 bg-slate-900/70 p-5 hover:border-indigo-500/50 hover:bg-slate-900 transition-all space-y-3"
          >
            <div className="flex items-center justify-between">
              <div className="h-10 w-10 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                <GraduationCap className="h-5 w-5" />
              </div>
              <span className="text-xs font-semibold text-cyan-400 group-hover:translate-x-0.5 transition-transform flex items-center gap-1">
                Open <ArrowRight className="h-3 w-3" />
              </span>
            </div>
            <div>
              <h3 className="font-bold text-white text-base">Weekly Class Timetable</h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Filter classroom lecture schedules, lab session allocations, and faculty periods by department and semester.
              </p>
            </div>
          </div>

          {/* Card 5: Leave Management */}
          <div 
            onClick={() => onNavigateTab('leave')}
            className="group cursor-pointer rounded-xl border border-slate-800 bg-slate-900/70 p-5 hover:border-indigo-500/50 hover:bg-slate-900 transition-all space-y-3"
          >
            <div className="flex items-center justify-between">
              <div className="h-10 w-10 rounded-lg bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
                <FileText className="h-5 w-5" />
              </div>
              <span className="text-xs font-semibold text-purple-400 group-hover:translate-x-0.5 transition-transform flex items-center gap-1">
                Open <ArrowRight className="h-3 w-3" />
              </span>
            </div>
            <div>
              <h3 className="font-bold text-white text-base">Student Leave System</h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Apply for medical or on-duty competition leaves and track official department head reviews and approvals.
              </p>
            </div>
          </div>

          {/* Card 6: Syllabus & Resources */}
          <div 
            onClick={() => onNavigateTab('resources')}
            className="group cursor-pointer rounded-xl border border-slate-800 bg-slate-900/70 p-5 hover:border-indigo-500/50 hover:bg-slate-900 transition-all space-y-3"
          >
            <div className="flex items-center justify-between">
              <div className="h-10 w-10 rounded-lg bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
                <BookOpen className="h-5 w-5" />
              </div>
              <span className="text-xs font-semibold text-blue-400 group-hover:translate-x-0.5 transition-transform flex items-center gap-1">
                Open <ArrowRight className="h-3 w-3" />
              </span>
            </div>
            <div>
              <h3 className="font-bold text-white text-base">Curriculum & Resources</h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Search and download certified unit-wise syllabus schemes, professor lecture notes, and lab experiment manuals.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Notices & Upcoming Events Two-Column Row */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pinned Circulars */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Bell className="h-4 w-4 text-amber-400" />
              <h3 className="text-sm font-bold text-white">Official Pinned Circulars</h3>
            </div>
            <button
              onClick={() => onNavigateTab('notices')}
              className="text-xs text-indigo-400 hover:text-indigo-300 font-medium"
            >
              View All Notices →
            </button>
          </div>

          <div className="space-y-3">
            {pinnedNotices.map(notice => (
              <div key={notice.id} className="rounded-lg bg-slate-950/80 p-3.5 border border-slate-800/80 space-y-1.5">
                <div className="flex items-center gap-2 text-[11px] text-slate-400">
                  <span className="font-bold uppercase tracking-wider text-amber-400">
                    {notice.priority}
                  </span>
                  <span>·</span>
                  <span>{notice.department_name || 'All Departments'}</span>
                </div>
                <h4 className="text-xs font-bold text-white leading-snug">{notice.title}</h4>
                <p className="text-xs text-slate-400 line-clamp-2">{notice.body}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Upcoming Featured Events */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 text-indigo-400" />
              <h3 className="text-sm font-bold text-white">Upcoming Campus Events</h3>
            </div>
            <button
              onClick={() => onNavigateTab('events')}
              className="text-xs text-indigo-400 hover:text-indigo-300 font-medium"
            >
              Catalog & Passes →
            </button>
          </div>

          <div className="space-y-3">
            {upcomingEvents.map(event => (
              <div key={event.id} className="rounded-lg bg-slate-950/80 p-3.5 border border-slate-800/80 flex items-center justify-between gap-3">
                <div className="space-y-1 flex-1">
                  <div className="flex items-center gap-2 text-[11px] text-slate-400">
                    <span className="font-bold text-indigo-400">{event.category}</span>
                    <span>·</span>
                    <span>{new Date(event.start_at).toLocaleDateString([], { month: 'short', day: 'numeric' })}</span>
                  </div>
                  <h4 className="text-xs font-bold text-white leading-snug truncate max-w-xs">{event.title}</h4>
                  <div className="text-[11px] text-slate-400 flex items-center gap-1">
                    <MapPin className="h-3 w-3 text-slate-500" />
                    <span className="truncate">{event.location}</span>
                  </div>
                </div>

                <button
                  onClick={() => onNavigateTab('events')}
                  className="rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-indigo-500 shrink-0"
                >
                  View Event
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
