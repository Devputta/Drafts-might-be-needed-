import { useState } from 'react';
import { UserProfile, UserRole, Ticket, EventRegistration, CampusEvent } from '../types/index.js';
import { NotificationCenter } from './NotificationCenter.js';
import { 
  Building2, 
  ChevronDown, 
  LogOut, 
  UserCheck, 
  Menu, 
  Camera, 
  User, 
  Clock,
  KeyRound
} from 'lucide-react';

interface HeaderProps {
  currentUser: UserProfile;
  allUsers: UserProfile[];
  onSwitchUser: (userId: string) => void;
  onLogout: () => void;
  onChangePassword?: () => void;
  myTickets: Ticket[];
  myRegistrations: EventRegistration[];
  events: CampusEvent[];
  onViewTicket: (ticket: Ticket) => void;
  onOpenQuickScan?: () => void;
  onToggleMobileMenu: () => void;
}

export function Header({
  currentUser,
  allUsers,
  onSwitchUser,
  onLogout,
  onChangePassword,
  myTickets,
  myRegistrations,
  events,
  onViewTicket,
  onOpenQuickScan,
  onToggleMobileMenu
}: HeaderProps) {
  const [showDropdown, setShowDropdown] = useState(false);

  const getRoleLabel = (role: UserRole) => {
    switch (role) {
      case 'STUDENT': return 'Student';
      case 'ORGANIZER': return 'Event Organizer';
      case 'FACULTY': return 'Faculty';
      case 'DEPARTMENT_ADMIN': return 'Dept Head';
      case 'COLLEGE_ADMIN': return 'Administrator';
      case 'SUPER_ADMIN': return 'System Admin';
      default: return role;
    }
  };

  const isOrganizerOrAdmin = ['ORGANIZER', 'DEPARTMENT_ADMIN', 'COLLEGE_ADMIN', 'SUPER_ADMIN'].includes(currentUser.role);

  return (
    <header className="h-14 bg-white border-b border-slate-200 px-4 sm:px-6 flex items-center justify-between sticky top-0 z-30">
      {/* Left side: Hamburger for mobile + Portal Title */}
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleMobileMenu}
          className="md:hidden p-1.5 rounded text-slate-500 hover:text-slate-800 hover:bg-slate-100"
          title="Open menu"
        >
          <Menu className="h-5 w-5" />
        </button>

        <div className="flex items-center gap-2">
          <div className="h-8 w-8 rounded bg-blue-900 flex items-center justify-center text-white font-bold text-sm md:hidden">
            <Building2 className="h-4 w-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-sm text-slate-900 leading-none">
                CampusOS
              </span>
              <span className="text-slate-300">|</span>
              <span className="text-xs text-slate-600 font-medium">
                {currentUser.role === 'STUDENT' ? 'Student Portal' : 'Faculty & Staff Portal'}
              </span>
            </div>
            <span className="text-[11px] text-slate-400 block mt-0.5">
              Academic Year 2026–27 · Semester {currentUser.semester || 6}
            </span>
          </div>
        </div>
      </div>

      {/* Right side: Notifications, Quick Scanner (if staff), Profile & Logout */}
      <div className="flex items-center gap-3">
        {/* Quick QR Scanner for entrance gates */}
        {isOrganizerOrAdmin && onOpenQuickScan && (
          <button
            onClick={onOpenQuickScan}
            className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded border border-slate-300 transition-colors"
            title="Open entrance gate scanner"
          >
            <Camera className="h-3.5 w-3.5" />
            <span>Gate Scanner</span>
          </button>
        )}

        {/* Real-time Notification Center */}
        <NotificationCenter
          tickets={myTickets}
          registrations={myRegistrations}
          events={events}
          onViewTicket={onViewTicket}
        />

        {/* User Account & Dropdown */}
        <div className="relative">
          <button
            onClick={() => setShowDropdown(!showDropdown)}
            className="flex items-center gap-2 pl-2 pr-1 py-1 rounded text-left hover:bg-slate-100 transition-colors text-xs text-slate-800"
          >
            <div className="h-7 w-7 rounded-full bg-blue-900 text-white flex items-center justify-center font-bold text-xs">
              {currentUser.full_name.charAt(0)}
            </div>
            <div className="hidden sm:block">
              <div className="font-semibold text-slate-900 leading-none truncate max-w-[130px]">
                {currentUser.full_name}
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">
                {currentUser.student_id ? currentUser.student_id : getRoleLabel(currentUser.role)}
              </div>
            </div>
            <ChevronDown className="h-3.5 w-3.5 text-slate-500" />
          </button>

          {showDropdown && (
            <>
              <div
                className="fixed inset-0 z-20"
                onClick={() => setShowDropdown(false)}
              />
              <div className="absolute right-0 mt-2 w-64 rounded-md border border-slate-200 bg-white py-1.5 shadow-lg z-30 text-xs">
                {/* User info snippet */}
                <div className="px-3 py-2 border-b border-slate-100 text-slate-800">
                  <div className="font-bold text-slate-900">{currentUser.full_name}</div>
                  <div className="text-[11px] text-slate-500 truncate">{currentUser.email}</div>
                  <div className="text-[11px] text-blue-900 font-semibold mt-1">
                    {currentUser.department_name}
                  </div>
                  {currentUser.student_id && (
                    <div className="text-[11px] font-mono text-slate-500">
                      Roll No: {currentUser.student_id}
                    </div>
                  )}
                </div>

                {/* Persona switcher (for demonstration & evaluation) */}
                <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400 bg-slate-50 border-b border-slate-100">
                  Switch User Persona
                </div>

                <div className="max-h-48 overflow-y-auto divide-y divide-slate-50">
                  {allUsers.map((u) => (
                    <button
                      key={u.id}
                      onClick={() => {
                        onSwitchUser(u.id);
                        setShowDropdown(false);
                      }}
                      className={`w-full px-3 py-2 text-left flex items-center justify-between hover:bg-slate-50 transition-colors ${
                        u.id === currentUser.id ? 'bg-blue-50/70 text-blue-950 font-semibold' : 'text-slate-700'
                      }`}
                    >
                      <div>
                        <div className="text-xs">{u.full_name}</div>
                        <div className="text-[10px] text-slate-500">{getRoleLabel(u.role)}</div>
                      </div>
                      {u.id === currentUser.id && (
                        <UserCheck className="h-3.5 w-3.5 text-blue-900" />
                      )}
                    </button>
                  ))}
                </div>

                {/* Actions */}
                <div className="border-t border-slate-100 pt-1">
                  {onChangePassword && (
                    <button
                      onClick={() => {
                        setShowDropdown(false);
                        onChangePassword();
                      }}
                      className="w-full px-3 py-2 text-left text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2 font-medium"
                    >
                      <KeyRound className="h-3.5 w-3.5 text-slate-500" />
                      <span>Change Password</span>
                    </button>
                  )}
                  <button
                    onClick={() => {
                      setShowDropdown(false);
                      onLogout();
                    }}
                    className="w-full px-3 py-2 text-left text-xs text-red-700 hover:bg-red-50 flex items-center gap-2 font-medium"
                  >
                    <LogOut className="h-3.5 w-3.5" />
                    <span>Sign Out of CampusOS</span>
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
