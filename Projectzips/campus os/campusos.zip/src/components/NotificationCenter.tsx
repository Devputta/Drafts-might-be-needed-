import { useState, useEffect } from 'react';
import { Ticket, CampusEvent, EventRegistration } from '../types/index.js';
import { Bell, Clock, MapPin, QrCode, X, Calendar } from 'lucide-react';

interface NotificationCenterProps {
  tickets: Ticket[];
  registrations: EventRegistration[];
  events: CampusEvent[];
  onViewTicket: (ticket: Ticket) => void;
}

export interface EventReminder {
  id: string;
  event: CampusEvent;
  ticket?: Ticket;
  registration: EventRegistration;
  daysRemaining: number;
  hoursRemaining: number;
  formattedDate: string;
}

export function NotificationCenter({
  tickets,
  registrations,
  events,
  onViewTicket
}: NotificationCenterProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [hasPermission, setHasPermission] = useState<NotificationPermission>('default');
  const [reminders, setReminders] = useState<EventReminder[]>([]);
  const [readIds, setReadIds] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('campus_notifications_read') || '[]');
    } catch {
      return [];
    }
  });

  useEffect(() => {
    const now = new Date().getTime();
    const activeRegs = registrations.filter(r => r.status === 'CONFIRMED' || r.status === 'CHECKED_IN');
    const calculated: EventReminder[] = [];

    activeRegs.forEach(reg => {
      const event = events.find(e => e.id === reg.event_id);
      if (!event) return;

      const eventTime = new Date(event.start_at).getTime();
      const diffMs = eventTime - now;
      const days = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
      const hours = Math.ceil(diffMs / (1000 * 60 * 60));
      const matchingTicket = tickets.find(t => t.event_id === event.id && t.status !== 'VOID');

      calculated.push({
        id: `rem-${reg.id}`,
        event,
        ticket: matchingTicket,
        registration: reg,
        daysRemaining: days,
        hoursRemaining: hours,
        formattedDate: new Date(event.start_at).toLocaleDateString([], {
          weekday: 'short',
          month: 'short',
          day: 'numeric'
        })
      });
    });

    calculated.sort((a, b) => new Date(a.event.start_at).getTime() - new Date(b.event.start_at).getTime());
    setReminders(calculated);

    if (typeof window !== 'undefined' && 'Notification' in window) {
      setHasPermission(Notification.permission);
    }
  }, [tickets, registrations, events]);

  const unreadCount = reminders.filter(r => !readIds.includes(r.id)).length;

  const markAllAsRead = () => {
    const allIds = reminders.map(r => r.id);
    setReadIds(allIds);
    localStorage.setItem('campus_notifications_read', JSON.stringify(allIds));
  };

  const requestNotificationPermission = async () => {
    if ('Notification' in window) {
      try {
        const perm = await Notification.requestPermission();
        setHasPermission(perm);
      } catch (err) {
        console.error(err);
      }
    }
  };

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative flex h-8 w-8 items-center justify-center rounded border border-slate-200 bg-white text-slate-600 hover:bg-slate-50 hover:text-slate-900 transition-colors"
        title="Event Reminders & Notifications"
      >
        <Bell className="h-4 w-4" />
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-blue-900 px-1 text-[10px] font-bold text-white shadow-xs">
            {unreadCount}
          </span>
        )}
      </button>

      {isOpen && (
        <>
          <div
            className="fixed inset-0 z-40"
            onClick={() => setIsOpen(false)}
          />
          <div className="absolute right-0 mt-2 w-80 sm:w-96 rounded-md border border-slate-200 bg-white text-slate-800 shadow-xl z-50 overflow-hidden text-xs">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-slate-200 px-3.5 py-2.5 bg-slate-50">
              <span className="font-semibold text-slate-900 text-xs">
                Upcoming Registered Events
              </span>
              <div className="flex items-center gap-2">
                {unreadCount > 0 && (
                  <button
                    onClick={markAllAsRead}
                    className="text-[11px] text-blue-900 hover:underline"
                  >
                    Mark read
                  </button>
                )}
                <button
                  onClick={() => setIsOpen(false)}
                  className="text-slate-400 hover:text-slate-600 p-0.5"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Browser notification notice */}
            {hasPermission !== 'granted' && (
              <div className="border-b border-slate-100 bg-blue-50/50 p-2.5 text-[11px] flex items-center justify-between gap-2 text-slate-700">
                <span>Enable desktop reminders for event gates</span>
                <button
                  onClick={requestNotificationPermission}
                  className="rounded bg-blue-900 px-2 py-0.5 text-[10px] font-semibold text-white hover:bg-blue-800 shrink-0"
                >
                  Enable
                </button>
              </div>
            )}

            {/* List */}
            <div className="max-h-72 overflow-y-auto divide-y divide-slate-100 p-1">
              {reminders.map(rem => {
                const isRead = readIds.includes(rem.id);
                return (
                  <div
                    key={rem.id}
                    className={`p-2.5 rounded transition-colors ${
                      isRead ? 'bg-white' : 'bg-slate-50/80 font-medium'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="space-y-0.5">
                        <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
                          {rem.daysRemaining > 0 ? (
                            <span className="font-semibold text-blue-900">
                              Starts in {rem.daysRemaining} {rem.daysRemaining === 1 ? 'day' : 'days'}
                            </span>
                          ) : rem.daysRemaining === 0 ? (
                            <span className="font-bold text-emerald-700">Happening Today</span>
                          ) : (
                            <span>In progress</span>
                          )}
                          <span>·</span>
                          <span>{rem.formattedDate}</span>
                        </div>
                        <div className="text-xs font-semibold text-slate-900">
                          {rem.event.title}
                        </div>
                      </div>

                      {rem.ticket && (
                        <span className="font-mono text-[10px] bg-slate-100 px-1.5 py-0.5 rounded text-slate-600 border border-slate-200 shrink-0">
                          {rem.ticket.public_ticket_id}
                        </span>
                      )}
                    </div>

                    <div className="mt-2 flex items-center justify-between text-[11px] text-slate-500">
                      <div className="flex items-center gap-1 truncate max-w-[200px]">
                        <MapPin className="h-3 w-3 text-slate-400 shrink-0" />
                        <span className="truncate">{rem.event.location}</span>
                      </div>

                      {rem.ticket && (
                        <button
                          onClick={() => {
                            setIsOpen(false);
                            onViewTicket(rem.ticket!);
                          }}
                          className="inline-flex items-center gap-1 text-blue-900 font-semibold hover:underline"
                        >
                          <QrCode className="h-3 w-3" />
                          View Ticket Pass
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}

              {reminders.length === 0 && (
                <div className="py-6 text-center text-xs text-slate-500">
                  No upcoming registered events.
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
