import { useState } from 'react';
import { CampusEvent, EventCategory, EventRegistration, Ticket, UserProfile } from '../types/index.js';
import { api } from '../lib/api.js';
import { UpcomingReminderBanner } from './UpcomingReminderBanner.js';
import { 
  Calendar, 
  MapPin, 
  Users, 
  Clock, 
  Plus, 
  CheckCircle2, 
  QrCode, 
  AlertCircle,
  Search,
  X
} from 'lucide-react';

interface EventsViewProps {
  events: CampusEvent[];
  myRegistrations: EventRegistration[];
  myTickets: Ticket[];
  currentUser: UserProfile;
  onRefresh: () => void;
  onViewTicket: (ticket: Ticket) => void;
  onOpenScannerForEvent: (event: CampusEvent) => void;
}

export function EventsView({
  events,
  myRegistrations,
  myTickets,
  currentUser,
  onRefresh,
  onViewTicket,
  onOpenScannerForEvent
}: EventsViewProps) {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedDeptFilter, setSelectedDeptFilter] = useState<string>('ALL');
  const [isRegisteringId, setIsRegisteringId] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);

  // New Event Form State
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newLocation, setNewLocation] = useState('');
  const [newCategory, setNewCategory] = useState<EventCategory>('WORKSHOP');
  const [newStart, setNewStart] = useState('2026-11-10T10:00');
  const [newEnd, setNewEnd] = useState('2026-11-10T16:00');
  const [newCapacity, setNewCapacity] = useState('100');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const canCreateEvent = ['ORGANIZER', 'DEPARTMENT_ADMIN', 'COLLEGE_ADMIN', 'SUPER_ADMIN'].includes(currentUser.role);
  const departments = Array.from(new Set(events.map(e => e.department_name).filter(Boolean)));

  const filteredEvents = events.filter(e => {
    if (selectedCategory !== 'ALL' && e.category !== selectedCategory) return false;
    if (selectedDeptFilter !== 'ALL' && e.department_name !== selectedDeptFilter) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = e.title.toLowerCase().includes(q);
      const matchDesc = e.description.toLowerCase().includes(q);
      const matchLocation = e.location.toLowerCase().includes(q);
      const matchDept = (e.department_name || '').toLowerCase().includes(q);
      if (!matchTitle && !matchDesc && !matchLocation && !matchDept) return false;
    }
    return true;
  });

  const getRegistrationForEvent = (eventId: string) => {
    return myRegistrations.find(r => r.event_id === eventId && r.status !== 'CANCELLED');
  };

  const getTicketForEvent = (eventId: string) => {
    return myTickets.find(t => t.event_id === eventId && t.status !== 'VOID');
  };

  const handleRegister = async (eventId: string) => {
    setErrorMessage(null);
    setSuccessMessage(null);
    setIsRegisteringId(eventId);

    try {
      const res = await api.registerForEvent(eventId);
      if (res.success) {
        setSuccessMessage(`Registration confirmed. Digital ticket pass ${res.ticket.public_ticket_id} has been issued.`);
        onRefresh();
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Registration failed.');
    } finally {
      setIsRegisteringId(null);
    }
  };

  const handleCreateEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setErrorMessage(null);

    try {
      await api.createEvent({
        title: newTitle,
        description: newDesc,
        location: newLocation,
        category: newCategory,
        start_at: new Date(newStart).toISOString(),
        end_at: new Date(newEnd).toISOString(),
        capacity: Number(newCapacity),
        department_id: currentUser.department_id
      });
      setShowCreateModal(false);
      setSuccessMessage('New campus event published.');
      onRefresh();
      setNewTitle('');
      setNewDesc('');
      setNewLocation('');
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to create event.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const categories: { label: string; value: string }[] = [
    { label: 'All', value: 'ALL' },
    { label: 'Hackathons', value: 'HACKATHON' },
    { label: 'Workshops', value: 'WORKSHOP' },
    { label: 'Symposiums', value: 'SYMPOSIUM' },
    { label: 'Guest Lectures', value: 'GUEST_LECTURE' },
    { label: 'Cultural', value: 'CULTURAL' }
  ];

  return (
    <div className="space-y-6 text-slate-800">
      {/* Reminder Banner */}
      <UpcomingReminderBanner
        tickets={myTickets}
        registrations={myRegistrations}
        events={events}
        onViewTicket={onViewTicket}
      />

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900">Campus Events & Registrations</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Discover departmental symposiums, workshops, and guest lectures with verified digital attendance passes.
          </p>
        </div>

        {canCreateEvent && (
          <button
            onClick={() => setShowCreateModal(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-900 text-white rounded text-xs font-semibold hover:bg-blue-800 transition-colors shrink-0"
          >
            <Plus className="h-4 w-4" />
            Create Event
          </button>
        )}
      </div>

      {successMessage && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-md p-3 text-xs text-emerald-900 flex items-center gap-2">
          <CheckCircle2 className="h-4 w-4 text-emerald-700 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {errorMessage && (
        <div className="bg-red-50 border border-red-200 rounded-md p-3 text-xs text-red-900 flex items-center gap-2">
          <AlertCircle className="h-4 w-4 text-red-700 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Search and Filters Strip */}
      <div className="bg-white border border-slate-200 rounded-lg p-3 sm:p-4 space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          {/* Search Bar (Requirement) */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search events by title, topics, location..."
              className="w-full pl-9 pr-8 py-1.5 border border-slate-300 rounded text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-blue-900"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <select
              value={selectedDeptFilter}
              onChange={(e) => setSelectedDeptFilter(e.target.value)}
              className="border border-slate-300 rounded px-2.5 py-1.5 text-xs text-slate-800 focus:outline-hidden focus:border-blue-900"
            >
              <option value="ALL">All Departments</option>
              {departments.map(dept => (
                <option key={dept} value={dept}>{dept}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Category Filter Tabs */}
        <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-100 text-xs">
          <div className="flex items-center gap-1 overflow-x-auto no-scrollbar">
            {categories.map(cat => (
              <button
                key={cat.value}
                onClick={() => setSelectedCategory(cat.value)}
                className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                  selectedCategory === cat.value
                    ? 'bg-blue-900 text-white font-semibold'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          <span className="text-slate-500 text-[11px] hidden sm:inline">
            Showing {filteredEvents.length} events
          </span>
        </div>
      </div>

      {/* Events List / Cards (Clean Academic Style) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredEvents.map(event => {
          const userReg = getRegistrationForEvent(event.id);
          const userTicket = getTicketForEvent(event.id);
          const isRegistered = Boolean(userReg);
          const isFull = event.registered_count >= event.capacity;
          const isOrganizerForThis = currentUser.role === 'ORGANIZER' || ['DEPARTMENT_ADMIN', 'COLLEGE_ADMIN', 'SUPER_ADMIN'].includes(currentUser.role);
          const isCheckedIn = userTicket?.status === 'CHECKED_IN';

          return (
            <div
              key={event.id}
              className="bg-white border border-slate-200 rounded-lg p-4 flex flex-col justify-between hover:border-slate-300 transition-colors shadow-2xs"
            >
              <div className="space-y-2.5">
                <div className="flex items-center justify-between text-[11px] text-slate-500">
                  <span className="font-semibold text-blue-900 uppercase">
                    {event.category.replace('_', ' ')}
                  </span>
                  <span>{event.department_name || 'All Campus'}</span>
                </div>

                <div>
                  <h3 className="text-sm font-bold text-slate-900 leading-snug">
                    {event.title}
                  </h3>
                  <p className="text-xs text-slate-600 mt-1 line-clamp-2 leading-relaxed">
                    {event.description}
                  </p>
                </div>

                <div className="text-xs text-slate-600 space-y-1 bg-slate-50 p-2.5 rounded border border-slate-100">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                    <span>
                      {new Date(event.start_at).toLocaleDateString([], {
                        weekday: 'short',
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric'
                      })}
                    </span>
                    <span className="text-slate-300">·</span>
                    <span>{new Date(event.start_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <MapPin className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{event.location}</span>
                  </div>

                  <div className="text-[11px] text-slate-500 pt-0.5 flex justify-between">
                    <span>Capacity: {event.registered_count} / {event.capacity}</span>
                    {event.checked_in_count > 0 && (
                      <span className="text-emerald-700 font-medium">{event.checked_in_count} Checked In</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                {isRegistered && userTicket ? (
                  <button
                    onClick={() => onViewTicket(userTicket)}
                    className="flex-1 inline-flex items-center justify-center gap-1.5 py-1.5 px-3 rounded bg-blue-50 border border-blue-200 text-blue-900 text-xs font-semibold hover:bg-blue-100 transition-colors"
                  >
                    <QrCode className="h-3.5 w-3.5" />
                    {isCheckedIn ? 'Checked In · View Pass' : 'Open Ticket QR Pass'}
                  </button>
                ) : isFull ? (
                  <span className="text-xs text-slate-500 font-medium py-1.5">
                    Registration Closed (Full)
                  </span>
                ) : (
                  <button
                    onClick={() => handleRegister(event.id)}
                    disabled={isRegisteringId === event.id}
                    className="flex-1 inline-flex items-center justify-center gap-1.5 py-1.5 px-3 rounded bg-blue-900 text-white text-xs font-semibold hover:bg-blue-800 disabled:opacity-50 transition-colors"
                  >
                    {isRegisteringId === event.id ? 'Registering...' : 'Register'}
                  </button>
                )}

                {isOrganizerForThis && (
                  <button
                    onClick={() => onOpenScannerForEvent(event)}
                    className="py-1.5 px-2.5 border border-slate-300 rounded text-slate-700 text-xs font-medium hover:bg-slate-50 transition-colors"
                  >
                    Scan Tickets
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {filteredEvents.length === 0 && (
        <div className="py-10 text-center text-xs text-slate-500 bg-white border border-slate-200 rounded-lg">
          No events found matching your search.
        </div>
      )}

      {/* Create Event Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <div className="bg-white rounded-lg border border-slate-200 shadow-xl max-w-lg w-full overflow-hidden text-xs">
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900">Create Campus Event</h2>
              <button onClick={() => setShowCreateModal(false)} className="text-slate-400 hover:text-slate-600">
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateEvent} className="p-5 space-y-3.5">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Event Title *</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Technical Seminar on AI Systems"
                  className="w-full border border-slate-300 rounded px-3 py-1.5 text-xs text-slate-900 focus:outline-hidden focus:border-blue-900"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Description</label>
                <textarea
                  rows={2}
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="Event agenda and instructions."
                  className="w-full border border-slate-300 rounded px-3 py-1.5 text-xs text-slate-900 focus:outline-hidden focus:border-blue-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Category</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as EventCategory)}
                    className="w-full border border-slate-300 rounded px-3 py-1.5 text-xs text-slate-900 focus:outline-hidden focus:border-blue-900"
                  >
                    <option value="WORKSHOP">Workshop</option>
                    <option value="HACKATHON">Hackathon</option>
                    <option value="SYMPOSIUM">Symposium</option>
                    <option value="GUEST_LECTURE">Guest Lecture</option>
                    <option value="CULTURAL">Cultural</option>
                  </select>
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Capacity</label>
                  <input
                    type="number"
                    min="5"
                    required
                    value={newCapacity}
                    onChange={(e) => setNewCapacity(e.target.value)}
                    className="w-full border border-slate-300 rounded px-3 py-1.5 text-xs text-slate-900 focus:outline-hidden focus:border-blue-900"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Venue / Room *</label>
                <input
                  type="text"
                  required
                  value={newLocation}
                  onChange={(e) => setNewLocation(e.target.value)}
                  placeholder="e.g. Seminar Hall 1, Sir MV Block"
                  className="w-full border border-slate-300 rounded px-3 py-1.5 text-xs text-slate-900 focus:outline-hidden focus:border-blue-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Start Time *</label>
                  <input
                    type="datetime-local"
                    required
                    value={newStart}
                    onChange={(e) => setNewStart(e.target.value)}
                    className="w-full border border-slate-300 rounded px-3 py-1.5 text-xs text-slate-900 focus:outline-hidden focus:border-blue-900"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">End Time *</label>
                  <input
                    type="datetime-local"
                    required
                    value={newEnd}
                    onChange={(e) => setNewEnd(e.target.value)}
                    className="w-full border border-slate-300 rounded px-3 py-1.5 text-xs text-slate-900 focus:outline-hidden focus:border-blue-900"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-3 py-1.5 border border-slate-300 rounded text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-1.5 bg-blue-900 text-white rounded font-semibold hover:bg-blue-800 disabled:opacity-50"
                >
                  {isSubmitting ? 'Publishing...' : 'Publish Event'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
