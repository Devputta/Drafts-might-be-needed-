import { useEffect, useState } from 'react';
import { CampusEvent, UserProfile } from '../types/index.js';
import { api } from '../lib/api.js';
import { 
  Users, 
  Camera, 
  Download, 
  Search, 
  CheckCircle2, 
  Clock, 
  ShieldAlert, 
  Building,
  RefreshCw
} from 'lucide-react';

interface AttendeesViewProps {
  events: CampusEvent[];
  currentUser: UserProfile;
  onOpenScanner: (event: CampusEvent) => void;
}

export function AttendeesView({ events, currentUser, onOpenScanner }: AttendeesViewProps) {
  const [selectedEventId, setSelectedEventId] = useState<string>(events[0]?.id || '');
  const [attendeeData, setAttendeeData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'CHECKED_IN' | 'CONFIRMED'>('ALL');

  const selectedEvent = events.find(e => e.id === selectedEventId) || events[0];

  const fetchAttendees = async (eventId: string) => {
    if (!eventId) return;
    setLoading(true);
    try {
      const data = await api.getAttendees(eventId);
      setAttendeeData(data);
    } catch (err) {
      console.error('Failed to load attendees:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (selectedEventId) {
      fetchAttendees(selectedEventId);
    }
  }, [selectedEventId]);

  const handleExportCsv = () => {
    if (!selectedEventId) return;
    window.location.href = api.getAttendanceExportUrl(selectedEventId);
  };

  const filteredAttendees = (attendeeData?.attendees || []).filter((a: any) => {
    const matchesSearch =
      a.student_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (a.student_usn && a.student_usn.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (a.public_ticket_id && a.public_ticket_id.toLowerCase().includes(searchTerm.toLowerCase()));

    if (!matchesSearch) return false;

    if (statusFilter === 'CHECKED_IN') return a.registration_status === 'CHECKED_IN';
    if (statusFilter === 'CONFIRMED') return a.registration_status === 'CONFIRMED';
    return true;
  });

  const checkedInCount = attendeeData?.total_checked_in || 0;
  const registeredCount = attendeeData?.total_registered || 0;
  const capacity = attendeeData?.capacity || 100;
  const attendancePercentage = registeredCount > 0 ? Math.round((checkedInCount / registeredCount) * 100) : 0;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">Organizer Desk & Verification</h1>
          <p className="mt-1 text-xs text-slate-400">
            Real-time gate admission monitor, camera-based QR optical validation, and attendance logs.
          </p>
        </div>

        {selectedEvent && (
          <div className="flex items-center gap-2">
            <button
              onClick={() => onOpenScanner(selectedEvent)}
              className="inline-flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3.5 py-2 text-xs font-semibold text-white shadow-xs hover:bg-indigo-500 transition-colors"
            >
              <Camera className="h-4 w-4" />
              Launch QR Scanner
            </button>
            <button
              onClick={handleExportCsv}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800 px-3.5 py-2 text-xs font-medium text-slate-200 hover:bg-slate-700 hover:text-white transition-colors"
              title="Download authorized CSV attendance report"
            >
              <Download className="h-4 w-4" />
              Export CSV
            </button>
          </div>
        )}
      </div>

      {/* Event Selector & Stats Strip */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Selector Card */}
        <div className="md:col-span-1 rounded-xl border border-slate-800 bg-slate-900/80 p-4 space-y-2">
          <label className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block">
            Select Managed Event
          </label>
          <select
            value={selectedEventId}
            onChange={(e) => setSelectedEventId(e.target.value)}
            className="w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-xs text-slate-100 focus:border-indigo-500 focus:outline-hidden"
          >
            {events.map(ev => (
              <option key={ev.id} value={ev.id}>
                {ev.title}
              </option>
            ))}
          </select>
          <button
            onClick={() => fetchAttendees(selectedEventId)}
            className="inline-flex items-center gap-1 text-[11px] text-slate-400 hover:text-slate-200 pt-1"
          >
            <RefreshCw className="h-3 w-3" />
            Refresh List
          </button>
        </div>

        {/* Real-time Metric Cards (Anti-slop clean typographic display) */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
          <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block">
            Total Registrations
          </span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-white">{registeredCount}</span>
            <span className="text-xs text-slate-500">/ {capacity} cap</span>
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">Confirmed entries</span>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
          <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block">
            Admitted (Checked In)
          </span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-emerald-400">{checkedInCount}</span>
            <span className="text-xs text-emerald-600">verified</span>
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">Single entry enforced</span>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
          <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block">
            Turnout Rate
          </span>
          <div className="mt-1">
            <span className="text-2xl font-bold text-indigo-400">{attendancePercentage}%</span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full mt-2 overflow-hidden">
            <div
              className="bg-indigo-500 h-full rounded-full transition-all"
              style={{ width: `${Math.min(100, attendancePercentage)}%` }}
            />
          </div>
        </div>
      </div>

      {/* Attendees Table Controls */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-900 p-3 rounded-lg border border-slate-800">
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-500" />
          <input
            type="text"
            placeholder="Search by student name, USN, ticket..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full rounded-lg border border-slate-700 bg-slate-800 pl-8 pr-3 py-1.5 text-xs text-slate-100 placeholder-slate-500 focus:border-indigo-500 focus:outline-hidden"
          />
        </div>

        <div className="flex items-center gap-1 self-start sm:self-auto">
          {(['ALL', 'CHECKED_IN', 'CONFIRMED'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setStatusFilter(tab)}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                statusFilter === tab
                  ? 'bg-slate-800 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab === 'ALL' && 'All'}
              {tab === 'CHECKED_IN' && 'Checked In'}
              {tab === 'CONFIRMED' && 'Pending Check-in'}
            </button>
          ))}
        </div>
      </div>

      {/* Practical Table (Clean College Product Table) */}
      <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-900/60 shadow-xs">
        <table className="w-full text-left text-xs text-slate-300">
          <thead className="border-b border-slate-800 bg-slate-900/90 text-[11px] uppercase tracking-wider text-slate-400">
            <tr>
              <th className="py-3 px-4 font-semibold">Student Name</th>
              <th className="py-3 px-4 font-semibold">USN / Roll</th>
              <th className="py-3 px-4 font-semibold">Department</th>
              <th className="py-3 px-4 font-semibold">Ticket ID</th>
              <th className="py-3 px-4 font-semibold">Admission Status</th>
              <th className="py-3 px-4 font-semibold">Gate Timestamp</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {filteredAttendees.map((att: any) => {
              const isCheckedIn = att.registration_status === 'CHECKED_IN';
              return (
                <tr key={att.registration_id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-4 font-medium text-white">
                    {att.student_name}
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-300">
                    {att.student_usn || '—'}
                  </td>
                  <td className="py-3 px-4 text-slate-400">
                    {att.department_name}
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-400">
                    {att.public_ticket_id || '—'}
                  </td>
                  <td className="py-3 px-4">
                    {isCheckedIn ? (
                      <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-400">
                        <CheckCircle2 className="h-3 w-3" />
                        Checked In
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[11px] text-slate-400">
                        <Clock className="h-3 w-3 text-slate-500" />
                        Awaiting Entry
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-400">
                    {att.checked_in_at
                      ? new Date(att.checked_in_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
                      : '—'}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>

        {filteredAttendees.length === 0 && !loading && (
          <div className="py-8 text-center text-xs text-slate-500">
            No attendees match the criteria or no registrations found for this event.
          </div>
        )}
      </div>
    </div>
  );
}
