import { useState } from 'react';
import { Ticket, CampusEvent, EventRegistration } from '../types/index.js';
import { Clock, MapPin, QrCode, X } from 'lucide-react';

interface UpcomingReminderBannerProps {
  tickets: Ticket[];
  registrations: EventRegistration[];
  events: CampusEvent[];
  onViewTicket: (ticket: Ticket) => void;
}

export function UpcomingReminderBanner({
  tickets,
  registrations,
  events,
  onViewTicket
}: UpcomingReminderBannerProps) {
  const [dismissedId, setDismissedId] = useState<string | null>(null);

  const now = new Date().getTime();
  const activeRegs = registrations.filter(r => r.status === 'CONFIRMED' || r.status === 'CHECKED_IN');

  const upcomingEvents = activeRegs
    .map(reg => {
      const event = events.find(e => e.id === reg.event_id);
      if (!event) return null;
      const eventTime = new Date(event.start_at).getTime();
      const diffMs = eventTime - now;
      const days = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
      const hours = Math.ceil(diffMs / (1000 * 60 * 60));
      const ticket = tickets.find(t => t.event_id === event.id && t.status !== 'VOID');
      return { event, reg, ticket, days, hours, eventTime };
    })
    .filter((item): item is NonNullable<typeof item> => item !== null && item.days >= 0 && item.days <= 30)
    .sort((a, b) => a.eventTime - b.eventTime);

  const nearest = upcomingEvents[0];

  if (!nearest || dismissedId === nearest.event.id) {
    return null;
  }

  const isCheckedIn = nearest.ticket?.status === 'CHECKED_IN';

  return (
    <div className="rounded-lg border border-amber-200 bg-amber-50/80 p-4 text-xs text-amber-950">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-start gap-3">
          <Clock className="h-4 w-4 text-amber-700 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="font-bold uppercase tracking-wider text-[10px] text-amber-800 bg-amber-100 px-1.5 py-0.5 rounded">
                Event Reminder
              </span>
              <span className="font-semibold text-slate-900">
                {nearest.days === 0 ? 'Today' : nearest.days === 1 ? 'Tomorrow' : `In ${nearest.days} days`}
              </span>
              <span className="text-slate-400">·</span>
              <span className="text-slate-600">
                {new Date(nearest.event.start_at).toLocaleDateString([], {
                  weekday: 'short',
                  month: 'short',
                  day: 'numeric'
                })}
              </span>
            </div>

            <h3 className="font-bold text-slate-900 text-sm">
              {nearest.event.title}
            </h3>

            <div className="flex items-center gap-3 text-slate-600 text-[11px]">
              <div className="flex items-center gap-1">
                <MapPin className="h-3 w-3 text-slate-400" />
                <span>{nearest.event.location}</span>
              </div>
              {nearest.ticket && (
                <span>Ticket: <strong className="font-mono text-slate-800">{nearest.ticket.public_ticket_id}</strong></span>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {nearest.ticket && (
            <button
              onClick={() => onViewTicket(nearest.ticket!)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-900 text-white rounded text-xs font-semibold hover:bg-blue-800 shadow-xs transition-colors"
            >
              <QrCode className="h-3.5 w-3.5" />
              {isCheckedIn ? 'View Admitted Pass' : 'Open Ticket QR'}
            </button>
          )}

          <button
            onClick={() => setDismissedId(nearest.event.id)}
            className="p-1.5 text-slate-400 hover:text-slate-600"
            title="Dismiss reminder"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
