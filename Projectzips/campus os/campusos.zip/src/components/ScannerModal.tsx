import { useEffect, useRef, useState } from 'react';
import jsQR from 'jsqr';
import { api } from '../lib/api.js';
import { CampusEvent, CheckInResponse } from '../types/index.js';
import { Camera, RefreshCw, X, AlertCircle, CheckCircle2, ShieldAlert, Sparkles, Upload } from 'lucide-react';

interface ScannerModalProps {
  event: CampusEvent;
  onClose: () => void;
  onCheckInSuccess?: () => void;
}

export function ScannerModal({ event, onClose, onCheckInSuccess }: ScannerModalProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [hasCameraPermission, setHasCameraPermission] = useState<boolean | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState(true);
  const [manualTicketInput, setManualTicketInput] = useState('');
  const [scanResult, setScanResult] = useState<CheckInResponse | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [lastScannedCode, setLastScannedCode] = useState<string | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const animationFrameIdRef = useRef<number | null>(null);

  // Play audio chime for scan validation
  const playBeep = (type: 'success' | 'error') => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);

      if (type === 'success') {
        osc.frequency.setValueAtTime(880, audioCtx.currentTime); // A5 note
        osc.frequency.exponentialRampToValueAtTime(1320, audioCtx.currentTime + 0.15); // E6 note
        gain.gain.setValueAtTime(0.2, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.2);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.2);
      } else {
        osc.frequency.setValueAtTime(220, audioCtx.currentTime);
        osc.frequency.setValueAtTime(180, audioCtx.currentTime + 0.1);
        gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.3);
      }
    } catch {
      // AudioContext not allowed or disabled
    }
  };

  // Start Camera
  useEffect(() => {
    let active = true;

    async function startCamera() {
      try {
        setCameraError(null);
        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: 'environment',
            width: { ideal: 1280 },
            height: { ideal: 720 }
          }
        });

        if (!active) {
          stream.getTracks().forEach(t => t.stop());
          return;
        }

        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.setAttribute('playsinline', 'true');
          await videoRef.current.play();
          setHasCameraPermission(true);
        }
      } catch (err: any) {
        console.warn('Camera access could not be acquired:', err);
        setHasCameraPermission(false);
        setCameraError(err.message || 'Camera access was denied or device not found.');
      }
    }

    startCamera();

    return () => {
      active = false;
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(t => t.stop());
      }
      if (animationFrameIdRef.current) {
        cancelAnimationFrame(animationFrameIdRef.current);
      }
    };
  }, []);

  // Frame processing loop
  useEffect(() => {
    if (!hasCameraPermission) return;

    let isProcessing = false;

    const tick = async () => {
      if (videoRef.current && videoRef.current.readyState === videoRef.current.HAVE_ENOUGH_DATA) {
        const video = videoRef.current;
        const canvas = canvasRef.current;

        if (canvas) {
          canvas.width = video.videoWidth;
          canvas.height = video.videoHeight;
          const ctx = canvas.getContext('2d', { willReadFrequently: true });

          if (ctx) {
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);

            const code = jsQR(imageData.data, imageData.width, imageData.height, {
              inversionAttempts: 'dontInvert'
            });

            if (code && code.data && !isProcessing && isScanning) {
              const scannedTicketId = code.data.trim();
              if (scannedTicketId !== lastScannedCode) {
                isProcessing = true;
                setLastScannedCode(scannedTicketId);
                await handleValidateCheckIn(scannedTicketId);
                isProcessing = false;
              }
            }
          }
        }
      }
      animationFrameIdRef.current = requestAnimationFrame(tick);
    };

    animationFrameIdRef.current = requestAnimationFrame(tick);

    return () => {
      if (animationFrameIdRef.current) {
        cancelAnimationFrame(animationFrameIdRef.current);
      }
    };
  }, [hasCameraPermission, isScanning, lastScannedCode]);

  const handleValidateCheckIn = async (ticketId: string) => {
    if (!ticketId || isSubmitting) return;
    setIsSubmitting(true);

    try {
      const response = await api.performCheckIn(ticketId, event.id, 'CampusOS Entrance Station #1');
      setScanResult(response);

      if (response.success) {
        playBeep('success');
        if (onCheckInSuccess) onCheckInSuccess();
      } else {
        playBeep('error');
      }
    } catch (err: any) {
      const data = err.data || { success: false, code: 'INVALID_TICKET', message: err.message };
      setScanResult(data);
      playBeep('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (manualTicketInput.trim()) {
      handleValidateCheckIn(manualTicketInput.trim());
    }
  };

  // Image Upload fallback scanner
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0);
          const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
          const code = jsQR(imgData.data, imgData.width, imgData.height);
          if (code && code.data) {
            handleValidateCheckIn(code.data.trim());
          } else {
            setScanResult({
              success: false,
              code: 'INVALID_TICKET',
              message: 'No readable QR code found in uploaded image.'
            });
            playBeep('error');
          }
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleResetScanner = () => {
    setScanResult(null);
    setLastScannedCode(null);
    setManualTicketInput('');
    setIsScanning(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 p-4 backdrop-blur-xs">
      <div className="flex max-h-[92vh] w-full max-w-2xl flex-col rounded-xl border border-slate-700 bg-slate-900 text-slate-100 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 px-6 py-4 bg-slate-900/90">
          <div>
            <div className="flex items-center gap-2">
              <Camera className="h-5 w-5 text-indigo-400" />
              <h2 className="text-base font-semibold tracking-tight text-white">
                Entrance Check-In Scanner
              </h2>
            </div>
            <p className="mt-0.5 text-xs text-slate-400">
              {event.title} <span className="text-slate-600">·</span> {event.location}
            </p>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
            title="Close scanner"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Result Alert Banners */}
          {scanResult && (
            <div
              className={`rounded-lg border p-4 text-sm transition-all ${
                scanResult.success
                  ? 'border-emerald-600/40 bg-emerald-950/40 text-emerald-200'
                  : scanResult.code === 'ALREADY_CHECKED_IN'
                  ? 'border-red-600/50 bg-red-950/50 text-red-200'
                  : 'border-amber-600/50 bg-amber-950/40 text-amber-200'
              }`}
            >
              <div className="flex items-start gap-3">
                {scanResult.success ? (
                  <CheckCircle2 className="h-5 w-5 text-emerald-400 shrink-0 mt-0.5" />
                ) : scanResult.code === 'ALREADY_CHECKED_IN' ? (
                  <ShieldAlert className="h-5 w-5 text-red-400 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="h-5 w-5 text-amber-400 shrink-0 mt-0.5" />
                )}

                <div className="flex-1 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-white tracking-wide">
                      {scanResult.code === 'SUCCESS' && 'VALID ENTRY GRANTED'}
                      {scanResult.code === 'ALREADY_CHECKED_IN' && 'DUPLICATE ENTRY BLOCKED'}
                      {scanResult.code === 'EVENT_MISMATCH' && 'WRONG EVENT TICKET'}
                      {scanResult.code === 'INVALID_TICKET' && 'INVALID TICKET'}
                      {scanResult.code === 'UNAUTHORIZED' && 'UNAUTHORIZED SCANNER'}
                    </span>
                    <button
                      onClick={handleResetScanner}
                      className="inline-flex items-center gap-1 rounded bg-slate-800 px-2 py-1 text-xs text-slate-300 hover:bg-slate-700 transition-colors"
                    >
                      <RefreshCw className="h-3 w-3" />
                      Scan Next
                    </button>
                  </div>

                  <p className="text-xs leading-relaxed">{scanResult.message}</p>

                  {/* Verified Attendee Card */}
                  {scanResult.attendee && (
                    <div className="mt-3 rounded border border-slate-700/60 bg-slate-900/80 p-3 text-xs space-y-1">
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <span className="text-slate-400 block text-[10px] uppercase tracking-wider">Attendee Name</span>
                          <span className="font-semibold text-slate-100">{scanResult.attendee.name}</span>
                        </div>
                        <div>
                          <span className="text-slate-400 block text-[10px] uppercase tracking-wider">USN / Student ID</span>
                          <span className="font-mono text-slate-200">{scanResult.attendee.student_id || 'N/A'}</span>
                        </div>
                        <div>
                          <span className="text-slate-400 block text-[10px] uppercase tracking-wider">Department</span>
                          <span className="text-slate-200">{scanResult.attendee.department}</span>
                        </div>
                        <div>
                          <span className="text-slate-400 block text-[10px] uppercase tracking-wider">Verified Time</span>
                          <span className="text-slate-200">
                            {new Date(scanResult.attendee.checked_in_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                          </span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Camera Viewfinder */}
          <div className="relative aspect-4/3 w-full overflow-hidden rounded-xl border border-slate-800 bg-black flex items-center justify-center">
            {hasCameraPermission === false ? (
              <div className="text-center p-6 space-y-3">
                <AlertCircle className="mx-auto h-8 w-8 text-amber-400" />
                <p className="text-sm font-medium text-slate-200">Camera Access Unavailable</p>
                <p className="text-xs text-slate-400 max-w-sm">
                  {cameraError || 'Device camera was not granted permission or is in use by another application. Use the manual ticket input or upload an image below.'}
                </p>
              </div>
            ) : (
              <>
                <video
                  ref={videoRef}
                  className="h-full w-full object-cover"
                  autoPlay
                  playsInline
                  muted
                />
                <canvas ref={canvasRef} className="hidden" />

                {/* Reticle Overlay */}
                <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                  <div className="relative h-56 w-56 border-2 border-indigo-400/80 rounded-2xl shadow-[0_0_0_9999px_rgba(15,23,42,0.65)]">
                    {/* Corner accents */}
                    <div className="absolute -top-1 -left-1 h-4 w-4 border-t-4 border-l-4 border-indigo-400" />
                    <div className="absolute -top-1 -right-1 h-4 w-4 border-t-4 border-r-4 border-indigo-400" />
                    <div className="absolute -bottom-1 -left-1 h-4 w-4 border-b-4 border-l-4 border-indigo-400" />
                    <div className="absolute -bottom-1 -right-1 h-4 w-4 border-b-4 border-r-4 border-indigo-400" />

                    {/* Laser scanning beam line */}
                    {isScanning && !scanResult && (
                      <div className="absolute left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_8px_#38bdf8] animate-pulse top-1/2" />
                    )}
                  </div>
                </div>

                {/* Status indicator on viewfinder */}
                <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-[11px] bg-slate-900/85 px-3 py-1.5 rounded-lg border border-slate-800 text-slate-300">
                  <span className="flex items-center gap-1.5">
                    <span className="h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
                    Optical Engine Active
                  </span>
                  <span>Point at attendee QR</span>
                </div>
              </>
            )}
          </div>

          {/* Alternate Manual & File Verification */}
          <div className="rounded-lg border border-slate-800 bg-slate-900/60 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                Manual / Fallback Entry
              </span>
              <label className="cursor-pointer inline-flex items-center gap-1.5 text-xs text-indigo-400 hover:text-indigo-300">
                <Upload className="h-3.5 w-3.5" />
                Upload QR Image
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </label>
            </div>

            <form onSubmit={handleManualSubmit} className="flex gap-2">
              <input
                type="text"
                value={manualTicketInput}
                onChange={(e) => setManualTicketInput(e.target.value)}
                placeholder="Enter Ticket ID (e.g. TKT-2026-HK9B-7A21)"
                className="flex-1 rounded-lg border border-slate-700 bg-slate-800/80 px-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:border-indigo-500 focus:outline-hidden font-mono"
              />
              <button
                type="submit"
                disabled={isSubmitting || !manualTicketInput.trim()}
                className="rounded-lg bg-indigo-600 px-4 py-2 text-xs font-medium text-white hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {isSubmitting ? 'Verifying...' : 'Verify'}
              </button>
            </form>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-slate-800 px-6 py-3 bg-slate-900/90 flex items-center justify-between text-xs text-slate-400">
          <span>CampusOS v1.0 Gate Security Module</span>
          <button
            onClick={onClose}
            className="rounded px-3 py-1.5 hover:bg-slate-800 hover:text-slate-200 transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
