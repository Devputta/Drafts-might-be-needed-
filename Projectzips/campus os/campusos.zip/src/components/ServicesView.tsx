import { useEffect, useState } from 'react';
import { CampusServiceRequest, UserProfile } from '../types/index.js';
import { api } from '../lib/api.js';
import { LifeBuoy, Plus, CheckCircle2, Clock, AlertCircle, MessageSquare, Send } from 'lucide-react';

interface ServicesViewProps {
  currentUser: UserProfile;
}

export function ServicesView({ currentUser }: ServicesViewProps) {
  const [requests, setRequests] = useState<CampusServiceRequest[]>([]);
  const [loading, setLoading] = useState(false);
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState<CampusServiceRequest | null>(null);

  // New Request Form
  const [category, setCategory] = useState<CampusServiceRequest['category']>('DOCUMENT_REQUEST');
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState<CampusServiceRequest['priority']>('MEDIUM');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Resolution Form (Staff / Admin)
  const [statusUpdate, setStatusUpdate] = useState<CampusServiceRequest['status']>('IN_PROGRESS');
  const [resolutionNotes, setResolutionNotes] = useState('');

  const isStaff = currentUser.role !== 'STUDENT';

  const fetchRequests = async () => {
    setLoading(true);
    try {
      const res = await api.getServiceRequests();
      setRequests(res.requests);
    } catch (err) {
      console.error('Failed to load requests:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRequests();
  }, [currentUser.id]);

  const handleSubmitRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await api.createServiceRequest({
        category,
        subject,
        description,
        priority
      });
      setShowSubmitModal(false);
      setSubject('');
      setDescription('');
      fetchRequests();
    } catch (err) {
      console.error('Failed to submit request:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUpdateStatus = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRequest) return;
    try {
      await api.updateServiceRequest(selectedRequest.id, {
        status: statusUpdate,
        resolution_notes: resolutionNotes
      });
      setSelectedRequest(null);
      fetchRequests();
    } catch (err) {
      console.error('Failed to update request:', err);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">Campus Services & Grievance Desk</h1>
          <p className="mt-1 text-xs text-slate-400">
            Submit bonafide certificate requests, academic queries, and campus infrastructure tickets.
          </p>
        </div>

        <button
          onClick={() => setShowSubmitModal(true)}
          className="inline-flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3.5 py-2 text-xs font-semibold text-white shadow-xs hover:bg-indigo-500 transition-colors"
        >
          <Plus className="h-4 w-4" />
          Submit Service Request
        </button>
      </div>

      {/* Requests List */}
      <div className="space-y-4">
        {requests.map(req => {
          const isResolved = req.status === 'RESOLVED';
          const isInProgress = req.status === 'IN_PROGRESS';

          return (
            <div
              key={req.id}
              className="rounded-xl border border-slate-800 bg-slate-900/70 p-5 shadow-xs transition-colors hover:border-slate-700"
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                <div className="space-y-1.5 flex-1">
                  <div className="flex items-center gap-2 text-xs">
                    <span className="font-mono text-indigo-400 font-semibold text-[11px]">
                      {req.id}
                    </span>
                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span className="text-[11px] uppercase tracking-wider text-slate-400">
                      {req.category.replace('_', ' ')}
                    </span>
                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span className="text-slate-400">Priority: {req.priority}</span>
                  </div>

                  <h3 className="text-sm font-bold text-white leading-snug">
                    {req.subject}
                  </h3>

                  <p className="text-xs text-slate-300 leading-relaxed">
                    {req.description}
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <span
                    className={`inline-flex items-center gap-1 text-[11px] font-semibold px-2.5 py-1 rounded border ${
                      isResolved
                        ? 'border-emerald-600/40 bg-emerald-950/40 text-emerald-300'
                        : isInProgress
                        ? 'border-indigo-600/40 bg-indigo-950/40 text-indigo-300'
                        : 'border-amber-600/40 bg-amber-950/40 text-amber-300'
                    }`}
                  >
                    {isResolved && <CheckCircle2 className="h-3 w-3" />}
                    {isInProgress && <Clock className="h-3 w-3" />}
                    {req.status.replace('_', ' ')}
                  </span>

                  {isStaff && (
                    <button
                      onClick={() => {
                        setSelectedRequest(req);
                        setStatusUpdate(req.status);
                        setResolutionNotes(req.resolution_notes || '');
                      }}
                      className="rounded bg-slate-800 px-2.5 py-1 text-xs text-slate-300 hover:bg-slate-700"
                    >
                      Update
                    </button>
                  )}
                </div>
              </div>

              {/* Resolution Notes Box */}
              {req.resolution_notes && (
                <div className="mt-3 rounded-lg bg-slate-950/80 p-3 border border-slate-800/80 text-xs space-y-1">
                  <div className="flex items-center gap-1.5 text-slate-400 text-[11px] font-medium">
                    <MessageSquare className="h-3 w-3 text-indigo-400" />
                    <span>Official Desk Response ({req.assigned_to || 'Department Officer'}):</span>
                  </div>
                  <p className="text-slate-200 leading-relaxed pl-4">
                    {req.resolution_notes}
                  </p>
                </div>
              )}

              <div className="mt-3 pt-2 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-500">
                <span>Submitted by: {req.student_name} ({req.department_name})</span>
                <span>{new Date(req.created_at).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}</span>
              </div>
            </div>
          );
        })}

        {requests.length === 0 && !loading && (
          <div className="rounded-xl border border-dashed border-slate-800 p-12 text-center">
            <LifeBuoy className="mx-auto h-8 w-8 text-slate-600" />
            <h3 className="mt-2 text-sm font-semibold text-slate-300">No active service tickets</h3>
            <p className="mt-1 text-xs text-slate-500">You currently have no open requests or grievances.</p>
          </div>
        )}
      </div>

      {/* New Request Modal */}
      {showSubmitModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 p-4 backdrop-blur-xs">
          <div className="flex max-h-[92vh] w-full max-w-md flex-col rounded-xl border border-slate-800 bg-slate-900 text-slate-100 shadow-2xl overflow-hidden">
            <div className="border-b border-slate-800 px-6 py-4 flex items-center justify-between">
              <h2 className="text-base font-bold text-white">Lodge Campus Service Request</h2>
              <button
                onClick={() => setShowSubmitModal(false)}
                className="text-slate-400 hover:text-white text-xs"
              >
                Cancel
              </button>
            </div>

            <form onSubmit={handleSubmitRequest} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Request Category *</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-xs text-slate-100 focus:border-indigo-500 focus:outline-hidden"
                >
                  <option value="DOCUMENT_REQUEST">Bonafide / Official Document Request</option>
                  <option value="ACADEMIC_QUERY">Academic & Attendance Query</option>
                  <option value="INFRASTRUCTURE">Campus Infrastructure / Wi-Fi</option>
                  <option value="LAB_EQUIPMENT">Laboratory Instrument Maintenance</option>
                  <option value="HOSTEL_MESS">Hostel & Mess Issue</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Subject / Summary *</label>
                <input
                  type="text"
                  required
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="e.g. Request for Bonafide Certificate for Visa / Internship"
                  className="w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-xs text-slate-100 focus:border-indigo-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Detailed Description *</label>
                <textarea
                  rows={4}
                  required
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Provide registration number, relevant course, and exact requirement."
                  className="w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-xs text-slate-100 focus:border-indigo-500 focus:outline-hidden"
                />
              </div>

              <div className="pt-4 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowSubmitModal(false)}
                  className="rounded-lg px-3 py-2 text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="rounded-lg bg-indigo-600 px-4 py-2 text-xs font-semibold text-white hover:bg-indigo-500 disabled:opacity-50"
                >
                  {isSubmitting ? 'Submitting...' : 'Submit Request'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Staff Update Modal */}
      {selectedRequest && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 p-4 backdrop-blur-xs">
          <div className="flex max-h-[92vh] w-full max-w-md flex-col rounded-xl border border-slate-800 bg-slate-900 text-slate-100 shadow-2xl overflow-hidden">
            <div className="border-b border-slate-800 px-6 py-4 flex items-center justify-between">
              <h2 className="text-base font-bold text-white">Update Service Ticket</h2>
              <button
                onClick={() => setSelectedRequest(null)}
                className="text-slate-400 hover:text-white text-xs"
              >
                Close
              </button>
            </div>

            <form onSubmit={handleUpdateStatus} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Status</label>
                <select
                  value={statusUpdate}
                  onChange={(e) => setStatusUpdate(e.target.value as any)}
                  className="w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-xs text-slate-100 focus:border-indigo-500 focus:outline-hidden"
                >
                  <option value="OPEN">Open</option>
                  <option value="IN_PROGRESS">In Progress</option>
                  <option value="RESOLVED">Resolved</option>
                  <option value="REJECTED">Rejected</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Resolution / Progress Notes</label>
                <textarea
                  rows={3}
                  value={resolutionNotes}
                  onChange={(e) => setResolutionNotes(e.target.value)}
                  placeholder="Record certificate dispatch, lab action taken, or comments for the student."
                  className="w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-xs text-slate-100 focus:border-indigo-500 focus:outline-hidden"
                />
              </div>

              <div className="pt-4 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedRequest(null)}
                  className="rounded-lg px-3 py-2 text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-indigo-600 px-4 py-2 text-xs font-semibold text-white hover:bg-indigo-500"
                >
                  Save Status
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
