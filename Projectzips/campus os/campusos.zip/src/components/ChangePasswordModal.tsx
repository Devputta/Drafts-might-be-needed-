import { useState } from 'react';
import { api } from '../lib/api.js';
import { UserProfile } from '../types/index.js';
import { Lock, X, CheckCircle2, AlertCircle, ShieldCheck } from 'lucide-react';

interface ChangePasswordModalProps {
  currentUser: UserProfile;
  onClose: () => void;
  onPasswordChanged?: () => void;
}

export function ChangePasswordModal({ currentUser, onClose, onPasswordChanged }: ChangePasswordModalProps) {
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (newPassword.length < 6) {
      setError('New password must be at least 6 characters long.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setError('New password and confirmation password do not match.');
      return;
    }

    setLoading(true);
    try {
      const res = await api.changePassword({ currentPassword, newPassword });
      if (res.success) {
        setSuccess('Your institutional portal password has been successfully updated. Use your new password for future sign-ins.');
        if (onPasswordChanged) onPasswordChanged();
      }
    } catch (err: any) {
      setError(err.message || 'Failed to update password. Please check your current password.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4">
      <div className="w-full max-w-md bg-white rounded-lg shadow-xl border border-slate-300 overflow-hidden text-slate-800">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-2">
            <Lock className="h-4 w-4 text-blue-900" />
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
              Change Institutional Password
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          <div className="text-[11px] text-slate-500">
            Account: <strong className="text-slate-900">{currentUser.full_name}</strong> ({currentUser.email})
          </div>

          {error && (
            <div className="flex items-start gap-2 p-2.5 rounded bg-red-50 border border-red-200 text-xs text-red-800">
              <AlertCircle className="h-4 w-4 text-red-600 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {success ? (
            <div className="space-y-3 py-2">
              <div className="flex items-start gap-2 p-3 rounded bg-emerald-50 border border-emerald-200 text-xs text-emerald-900">
                <CheckCircle2 className="h-5 w-5 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold">Password Updated</div>
                  <p className="mt-0.5 leading-relaxed">{success}</p>
                </div>
              </div>
              <div className="flex justify-end pt-1">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-1.5 rounded bg-blue-900 text-white text-xs font-semibold hover:bg-blue-800"
                >
                  Close
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Current Password *
                </label>
                <input
                  type="password"
                  required
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  placeholder="Enter current portal password"
                  className="w-full px-3 py-2 border border-slate-300 rounded text-xs text-slate-900 focus:ring-1 focus:ring-blue-800 focus:border-blue-800"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  New Password * (Min 6 characters)
                </label>
                <input
                  type="password"
                  required
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Enter new secure password"
                  className="w-full px-3 py-2 border border-slate-300 rounded text-xs text-slate-900 focus:ring-1 focus:ring-blue-800 focus:border-blue-800"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Confirm New Password *
                </label>
                <input
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Re-enter new secure password"
                  className="w-full px-3 py-2 border border-slate-300 rounded text-xs text-slate-900 focus:ring-1 focus:ring-blue-800 focus:border-blue-800"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-3 py-1.5 rounded border border-slate-300 text-slate-700 hover:bg-slate-50 text-xs font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-4 py-1.5 rounded bg-blue-900 text-white text-xs font-semibold hover:bg-blue-800 disabled:opacity-50"
                >
                  {loading ? 'Updating Password...' : 'Save New Password'}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
