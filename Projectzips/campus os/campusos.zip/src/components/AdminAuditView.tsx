import { useEffect, useState } from 'react';
import { AuditLog, CampusEvent, UserProfile, PasswordResetRequest } from '../types/index.js';
import { api } from '../lib/api.js';
import { 
  ShieldAlert, 
  Activity, 
  Users, 
  Calendar, 
  CheckCircle2, 
  RefreshCw, 
  KeyRound, 
  Mail, 
  Send, 
  Filter, 
  Clock, 
  Check, 
  AlertCircle 
} from 'lucide-react';

interface AdminAuditViewProps {
  currentUser: UserProfile;
  events: CampusEvent[];
  onRefreshEvents: () => void;
}

type AdminTab = 'PASSWORDS' | 'EVENTS' | 'AUDIT';

export function AdminAuditView({ currentUser, events, onRefreshEvents }: AdminAuditViewProps) {
  const [activeTab, setActiveTab] = useState<AdminTab>('PASSWORDS');
  const [passwordRequests, setPasswordRequests] = useState<PasswordResetRequest[]>([]);
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [metricsData, setMetricsData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  // Filters for password requests
  const [deptFilter, setDeptFilter] = useState('ALL');
  const [semesterFilter, setSemesterFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [dispatchingId, setDispatchingId] = useState<string | null>(null);

  const fetchAdminData = async () => {
    setLoading(true);
    setActionError(null);
    try {
      const [logsRes, reportsRes, pwdRes] = await Promise.all([
        api.getAuditLogs(),
        api.getReportsOverview(),
        api.getPasswordRequests()
      ]);
      setLogs(logsRes.logs);
      setMetricsData(reportsRes);
      setPasswordRequests(pwdRes.requests);
    } catch (err: any) {
      console.error('Failed to load admin data:', err);
      setActionError(err.message || 'Failed to fetch administrative records.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, []);

  const handleDispatchPassword = async (requestId: string) => {
    setDispatchingId(requestId);
    setActionSuccess(null);
    setActionError(null);

    try {
      const res = await api.dispatchPassword(requestId);
      if (res.success) {
        setActionSuccess(
          `Success: Randomized password "${res.generated_password}" generated and dispatched to ${res.request.email}. Target user credentials updated.`
        );
        fetchAdminData();
      }
    } catch (err: any) {
      setActionError(err.message || 'Failed to generate/dispatch password.');
    } finally {
      setDispatchingId(null);
    }
  };

  const handleToggleEventStatus = async (event: CampusEvent) => {
    try {
      if (event.status === 'REGISTRATION_OPEN') {
        await api.closeEvent(event.id);
        setActionSuccess(`Registration closed for "${event.title}".`);
      } else {
        await api.publishEvent(event.id);
        setActionSuccess(`Registration opened for "${event.title}".`);
      }
      onRefreshEvents();
      fetchAdminData();
      setTimeout(() => setActionSuccess(null), 4000);
    } catch (err: any) {
      console.error(err);
    }
  };

  // Filtered password requests
  const filteredRequests = passwordRequests.filter(req => {
    if (deptFilter !== 'ALL' && req.department_name !== deptFilter) return false;
    if (semesterFilter !== 'ALL' && String(req.semester) !== semesterFilter) return false;
    if (statusFilter !== 'ALL' && req.status !== statusFilter) return false;
    return true;
  });

  const pendingCount = passwordRequests.filter(r => r.status === 'PENDING').length;
  const dispatchedCount = passwordRequests.filter(r => r.status === 'DISPATCHED').length;
  const metrics = metricsData?.metrics;

  return (
    <div className="space-y-6 text-slate-800">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Institutional Administration & Registry Controls
          </h1>
          <p className="mt-0.5 text-xs text-slate-500">
            Office of the Dean, Academic Administration & Examination Records.
          </p>
        </div>

        <button
          onClick={fetchAdminData}
          disabled={loading}
          className="inline-flex items-center gap-1.5 rounded border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors shrink-0"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>{loading ? 'Refreshing...' : 'Refresh Records'}</span>
        </button>
      </div>

      {actionSuccess && (
        <div className="flex items-start gap-2.5 rounded bg-emerald-50 border border-emerald-200 p-3 text-xs text-emerald-900">
          <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5" />
          <span>{actionSuccess}</span>
        </div>
      )}

      {actionError && (
        <div className="flex items-start gap-2.5 rounded bg-red-50 border border-red-200 p-3 text-xs text-red-900">
          <AlertCircle className="h-4 w-4 text-red-600 shrink-0 mt-0.5" />
          <span>{actionError}</span>
        </div>
      )}

      {/* Admin Module Tabs */}
      <div className="flex border-b border-slate-200 text-xs">
        <button
          onClick={() => setActiveTab('PASSWORDS')}
          className={`py-2 px-4 font-semibold border-b-2 transition-colors flex items-center gap-2 ${
            activeTab === 'PASSWORDS'
              ? 'border-blue-900 text-blue-900'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <KeyRound className="h-4 w-4" />
          <span>Credential & Password Dispatcher</span>
          {pendingCount > 0 && (
            <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900">
              {pendingCount} Pending
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('EVENTS')}
          className={`py-2 px-4 font-semibold border-b-2 transition-colors flex items-center gap-2 ${
            activeTab === 'EVENTS'
              ? 'border-blue-900 text-blue-900'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Calendar className="h-4 w-4" />
          <span>Event Capacity Windows</span>
        </button>

        <button
          onClick={() => setActiveTab('AUDIT')}
          className={`py-2 px-4 font-semibold border-b-2 transition-colors flex items-center gap-2 ${
            activeTab === 'AUDIT'
              ? 'border-blue-900 text-blue-900'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Activity className="h-4 w-4" />
          <span>System Audit Trail</span>
        </button>
      </div>

      {/* TAB 1: Password & Credential Dispatcher */}
      {activeTab === 'PASSWORDS' && (
        <div className="space-y-5">
          {/* Summary Strip */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white border border-slate-200 rounded p-4">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 block">
                Total Reset Requests
              </span>
              <div className="text-2xl font-bold text-slate-900 mt-1">
                {passwordRequests.length}
              </div>
              <span className="text-[11px] text-slate-400 mt-0.5 block">
                Department & semester records
              </span>
            </div>

            <div className="bg-white border border-slate-200 rounded p-4">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-amber-700 block">
                Pending Administrator Action
              </span>
              <div className="text-2xl font-bold text-amber-900 mt-1">
                {pendingCount}
              </div>
              <span className="text-[11px] text-amber-700 mt-0.5 block">
                Awaiting random password generation
              </span>
            </div>

            <div className="bg-white border border-slate-200 rounded p-4">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-emerald-700 block">
                Dispatched to Student Gmail
              </span>
              <div className="text-2xl font-bold text-emerald-900 mt-1">
                {dispatchedCount}
              </div>
              <span className="text-[11px] text-emerald-700 mt-0.5 block">
                Passwords dispatched & verified
              </span>
            </div>
          </div>

          {/* Department & Semester Filters */}
          <div className="bg-white border border-slate-200 rounded p-4 space-y-3">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-900">
              <Filter className="h-3.5 w-3.5 text-blue-900" />
              <span>Filter Registration Requests Department & Semester Wise</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <label className="block text-[11px] text-slate-500 mb-1">Department</label>
                <select
                  value={deptFilter}
                  onChange={(e) => setDeptFilter(e.target.value)}
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded bg-white text-slate-800 text-xs focus:ring-1 focus:ring-blue-900"
                >
                  <option value="ALL">All Departments</option>
                  <option value="Computer Science & Engineering">Computer Science & Engineering</option>
                  <option value="Electronics & Communication Engineering">Electronics & Communication Engineering</option>
                  <option value="Information Science & Engineering">Information Science & Engineering</option>
                  <option value="Mechanical Engineering">Mechanical Engineering</option>
                  <option value="Civil Engineering">Civil Engineering</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] text-slate-500 mb-1">Semester</label>
                <select
                  value={semesterFilter}
                  onChange={(e) => setSemesterFilter(e.target.value)}
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded bg-white text-slate-800 text-xs focus:ring-1 focus:ring-blue-900"
                >
                  <option value="ALL">All Semesters</option>
                  <option value="1">Semester 1</option>
                  <option value="2">Semester 2</option>
                  <option value="3">Semester 3</option>
                  <option value="4">Semester 4</option>
                  <option value="5">Semester 5</option>
                  <option value="6">Semester 6</option>
                  <option value="7">Semester 7</option>
                  <option value="8">Semester 8</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] text-slate-500 mb-1">Dispatch Status</label>
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded bg-white text-slate-800 text-xs focus:ring-1 focus:ring-blue-900"
                >
                  <option value="ALL">All Statuses</option>
                  <option value="PENDING">Pending Action Only</option>
                  <option value="DISPATCHED">Dispatched to Gmail</option>
                </select>
              </div>
            </div>
          </div>

          {/* Requests Table */}
          <div className="bg-white border border-slate-200 rounded overflow-hidden shadow-xs">
            <div className="px-4 py-3 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold text-slate-900">
                  Password Recovery Queue ({filteredRequests.length} records)
                </h3>
                <span className="text-[11px] text-slate-500">
                  Admin will verify details, generate a random password, and dispatch directly to the student's Gmail.
                </span>
              </div>
            </div>

            {filteredRequests.length === 0 ? (
              <div className="py-8 text-center text-xs text-slate-500">
                No password reset requests found matching selected department and semester filters.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="border-b border-slate-200 bg-slate-50/70 text-slate-600 font-semibold text-[11px]">
                    <tr>
                      <th className="py-2.5 px-3">Student / Staff Name</th>
                      <th className="py-2.5 px-3">Registered Gmail</th>
                      <th className="py-2.5 px-3">USN / Staff ID</th>
                      <th className="py-2.5 px-3">Dept & Semester</th>
                      <th className="py-2.5 px-3">Requested At & Reason</th>
                      <th className="py-2.5 px-3">Status</th>
                      <th className="py-2.5 px-3 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredRequests.map(req => {
                      const isPending = req.status === 'PENDING';
                      const isDispatching = dispatchingId === req.id;

                      return (
                        <tr key={req.id} className="hover:bg-slate-50/60 transition-colors">
                          <td className="py-3 px-3">
                            <div className="font-semibold text-slate-900">{req.full_name}</div>
                            <span className="text-[10px] text-slate-500 font-mono">
                              Role: {req.role}
                            </span>
                          </td>

                          <td className="py-3 px-3">
                            <div className="font-mono text-blue-900 font-medium flex items-center gap-1.5">
                              <Mail className="h-3 w-3 text-slate-400 shrink-0" />
                              <span>{req.email}</span>
                            </div>
                            <span className="text-[10px] text-slate-400 block mt-0.5">Destination Gmail</span>
                          </td>

                          <td className="py-3 px-3 font-mono font-medium text-slate-700">
                            {req.student_id_or_staff_id || 'N/A'}
                          </td>

                          <td className="py-3 px-3">
                            <div className="font-medium text-slate-900 truncate max-w-[170px]">
                              {req.department_name}
                            </div>
                            <div className="text-[11px] text-slate-500">
                              {req.semester ? `Semester ${req.semester}` : 'Faculty/Admin'}
                            </div>
                          </td>

                          <td className="py-3 px-3 max-w-[200px]">
                            <div className="text-[11px] text-slate-500">
                              {new Date(req.requested_at).toLocaleDateString([], {
                                month: 'short',
                                day: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit'
                              })}
                            </div>
                            <p className="text-[11px] text-slate-600 truncate mt-0.5">
                              {req.reason || 'Password assistance'}
                            </p>
                          </td>

                          <td className="py-3 px-3">
                            {isPending ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-amber-50 text-amber-800 border border-amber-200">
                                <Clock className="h-3 w-3" /> Pending
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
                                <Check className="h-3 w-3" /> Dispatched
                              </span>
                            )}
                          </td>

                          <td className="py-3 px-3 text-right">
                            {isPending ? (
                              <button
                                onClick={() => handleDispatchPassword(req.id)}
                                disabled={isDispatching}
                                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded bg-blue-900 text-white text-xs font-semibold hover:bg-blue-800 transition-colors disabled:opacity-50 shrink-0"
                              >
                                <Send className="h-3 w-3" />
                                <span>{isDispatching ? 'Dispatching...' : 'Dispatch Random Password'}</span>
                              </button>
                            ) : (
                              <div className="text-right">
                                <span className="font-mono text-[11px] font-bold text-slate-900 block bg-slate-100 px-2 py-0.5 rounded inline-block">
                                  {req.generated_password || 'Campus#7bK9!'}
                                </span>
                                <span className="text-[10px] text-slate-400 block mt-0.5">
                                  Sent to Gmail by {req.dispatched_by || 'Admin'}
                                </span>
                              </div>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: Event Registration Controls */}
      {activeTab === 'EVENTS' && (
        <div className="bg-white border border-slate-200 rounded p-5 shadow-xs space-y-4">
          <div>
            <h2 className="text-sm font-bold text-slate-900 tracking-tight">
              Event Registration Window Controls
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Authorize or close registrations to enforce campus capacity limits.
            </p>
          </div>

          <div className="divide-y divide-slate-100">
            {events.map(ev => (
              <div key={ev.id} className="py-3 flex items-center justify-between gap-3 text-xs">
                <div>
                  <span className="font-semibold text-slate-900 block">{ev.title}</span>
                  <span className="text-slate-500 text-[11px]">
                    {ev.location} · {ev.registered_count} / {ev.capacity} registered
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <span className={`text-[10px] font-semibold uppercase px-2 py-0.5 rounded border ${
                    ev.status === 'REGISTRATION_OPEN'
                      ? 'border-emerald-200 text-emerald-700 bg-emerald-50'
                      : 'border-slate-300 text-slate-600 bg-slate-100'
                  }`}>
                    {ev.status.replace('_', ' ')}
                  </span>

                  <button
                    onClick={() => handleToggleEventStatus(ev)}
                    className="rounded border border-slate-300 bg-white px-3 py-1 text-xs text-slate-700 hover:bg-slate-50 transition-colors"
                  >
                    {ev.status === 'REGISTRATION_OPEN' ? 'Close Window' : 'Open Window'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: System Audit Trail */}
      {activeTab === 'AUDIT' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-900 tracking-tight">
              CampusOS Security & Action Audit Trail
            </h2>
            <span className="text-xs text-slate-500 font-mono">
              Showing recent operations
            </span>
          </div>

          <div className="overflow-x-auto rounded border border-slate-200 bg-white shadow-xs">
            <table className="w-full text-left text-xs text-slate-700">
              <thead className="border-b border-slate-200 bg-slate-50 text-[11px] uppercase tracking-wider text-slate-500">
                <tr>
                  <th className="py-2.5 px-3 font-semibold">Timestamp</th>
                  <th className="py-2.5 px-3 font-semibold">Actor</th>
                  <th className="py-2.5 px-3 font-semibold">Role</th>
                  <th className="py-2.5 px-3 font-semibold">Action</th>
                  <th className="py-2.5 px-3 font-semibold">Target Entity</th>
                  <th className="py-2.5 px-3 font-semibold">IP Reference</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                {logs.map(log => (
                  <tr key={log.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-2.5 px-3 text-slate-500 whitespace-nowrap text-[11px]">
                      {new Date(log.created_at).toLocaleString([], {
                        month: 'short',
                        day: '2-digit',
                        hour: '2-digit',
                        minute: '2-digit',
                        second: '2-digit'
                      })}
                    </td>
                    <td className="py-2.5 px-3 text-slate-900 font-sans font-medium">
                      {log.actor_name}
                    </td>
                    <td className="py-2.5 px-3 text-blue-900 text-[11px] font-semibold">
                      {log.actor_role}
                    </td>
                    <td className="py-2.5 px-3 font-bold text-slate-900 text-[11px]">
                      {log.action}
                    </td>
                    <td className="py-2.5 px-3 text-slate-500 text-[11px]">
                      {log.entity_type} ({log.entity_id})
                    </td>
                    <td className="py-2.5 px-3 text-slate-400 text-[11px]">
                      {log.ip_reference || '127.0.0.1'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
