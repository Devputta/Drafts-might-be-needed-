import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import {
  UserProfile,
  Department,
  Notice,
  CampusEvent,
  EventRegistration,
  Ticket,
  CheckInRecord,
  AcademicScheduleItem,
  AcademicResource,
  CampusServiceRequest,
  AuditLog,
  EmailEvent,
  CheckInResponse,
  UserRole,
  AttendanceRecord,
  SubjectAttendanceSummary,
  LeaveApplication,
  InternalMarksRecord,
  CourseSubject,
  PasswordResetRequest
} from '../src/types/index.js';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.resolve(DATA_DIR, 'campus_db.json');

export interface DatabaseSchema {
  users: UserProfile[];
  departments: Department[];
  notices: Notice[];
  events: CampusEvent[];
  registrations: EventRegistration[];
  tickets: Ticket[];
  checkins: CheckInRecord[];
  schedule: AcademicScheduleItem[];
  resources: AcademicResource[];
  service_requests: CampusServiceRequest[];
  audit_logs: AuditLog[];
  email_events: EmailEvent[];
  attendance_records: AttendanceRecord[];
  leave_applications: LeaveApplication[];
  internal_marks: InternalMarksRecord[];
  subjects: CourseSubject[];
  password_requests: PasswordResetRequest[];
}

function getInitialData(): DatabaseSchema {
  const departments: Department[] = [
    { id: 'dept-cse', name: 'Computer Science & Engineering', code: 'CSE', status: 'ACTIVE', head_of_department: 'Dr. Meenakshi Sundaram', student_count: 640, faculty_count: 32 },
    { id: 'dept-ece', name: 'Electronics & Communication Engineering', code: 'ECE', status: 'ACTIVE', head_of_department: 'Dr. Ramesh Babu', student_count: 520, faculty_count: 28 },
    { id: 'dept-ise', name: 'Information Science & Engineering', code: 'ISE', status: 'ACTIVE', head_of_department: 'Dr. Shalini Rao', student_count: 480, faculty_count: 24 },
    { id: 'dept-me', name: 'Mechanical Engineering', code: 'ME', status: 'ACTIVE', head_of_department: 'Dr. Ananth Kumar', student_count: 360, faculty_count: 20 },
    { id: 'dept-cv', name: 'Civil Engineering', code: 'CV', status: 'ACTIVE', head_of_department: 'Dr. Harish Patel', student_count: 290, faculty_count: 18 },
  ];

  const users: UserProfile[] = [
    {
      id: 'usr-student-1',
      auth_user_id: 'auth-student-1',
      full_name: 'Rahul Sharma',
      email: 'rahul.cs22@campus.edu',
      phone: '+91 98765 43210',
      student_id: '1CS22CS089',
      department_id: 'dept-cse',
      department_name: 'Computer Science & Engineering',
      year: 3,
      semester: 6,
      role: 'STUDENT',
      status: 'ACTIVE',
      password: 'password123',
      created_at: '2024-08-01T09:00:00Z',
      updated_at: '2026-02-15T10:00:00Z'
    },
    {
      id: 'usr-student-2',
      auth_user_id: 'auth-student-2',
      full_name: 'Ananya Deshmukh',
      email: 'ananya.ec23@campus.edu',
      phone: '+91 98765 43211',
      student_id: '1EC23EC014',
      department_id: 'dept-ece',
      department_name: 'Electronics & Communication Engineering',
      year: 2,
      semester: 4,
      role: 'STUDENT',
      status: 'ACTIVE',
      password: 'password123',
      created_at: '2025-08-01T09:00:00Z',
      updated_at: '2026-01-10T10:00:00Z'
    },
    {
      id: 'usr-organizer-1',
      auth_user_id: 'auth-organizer-1',
      full_name: 'Priya Nair',
      email: 'priya.events@campus.edu',
      phone: '+91 98765 43220',
      student_id: '1CS21CS142',
      department_id: 'dept-cse',
      department_name: 'Computer Science & Engineering',
      year: 4,
      semester: 8,
      role: 'ORGANIZER',
      status: 'ACTIVE',
      password: 'password123',
      assigned_event_ids: ['evt-hack-2026', 'evt-symp-ai'],
      created_at: '2023-08-01T09:00:00Z',
      updated_at: '2026-03-01T12:00:00Z'
    },
    {
      id: 'usr-faculty-1',
      auth_user_id: 'auth-faculty-1',
      full_name: 'Dr. Arvind Venkat',
      email: 'arvind.venkat@campus.edu',
      phone: '+91 98765 43230',
      department_id: 'dept-cse',
      department_name: 'Computer Science & Engineering',
      role: 'FACULTY',
      status: 'ACTIVE',
      password: 'password123',
      created_at: '2022-01-10T09:00:00Z',
      updated_at: '2026-01-05T09:00:00Z'
    },
    {
      id: 'usr-faculty-2',
      auth_user_id: 'auth-faculty-2',
      full_name: 'Prof. Sandhya Rao',
      email: 'sandhya.rao@campus.edu',
      phone: '+91 98765 43235',
      department_id: 'dept-cse',
      department_name: 'Computer Science & Engineering',
      role: 'FACULTY',
      status: 'ACTIVE',
      password: 'password123',
      created_at: '2023-01-15T09:00:00Z',
      updated_at: '2026-01-05T09:00:00Z'
    },
    {
      id: 'usr-dept-admin-1',
      auth_user_id: 'auth-dept-admin-1',
      full_name: 'Dr. Meenakshi Sundaram (HOD)',
      email: 'hod.cse@campus.edu',
      phone: '+91 98765 43240',
      department_id: 'dept-cse',
      department_name: 'Computer Science & Engineering',
      role: 'DEPARTMENT_ADMIN',
      status: 'ACTIVE',
      password: 'password123',
      created_at: '2020-05-01T09:00:00Z',
      updated_at: '2026-02-01T09:00:00Z'
    },
    {
      id: 'usr-dean-1',
      auth_user_id: 'auth-dean-1',
      full_name: 'Dr. Rajesh Rao (Dean of Academics)',
      email: 'dean.academics@campus.edu',
      phone: '+91 98765 43245',
      department_id: 'dept-cse',
      department_name: 'Office of the Dean & Academic Affairs',
      role: 'COLLEGE_ADMIN',
      status: 'ACTIVE',
      password: 'password123',
      created_at: '2019-06-01T09:00:00Z',
      updated_at: '2026-01-01T09:00:00Z'
    },
    {
      id: 'usr-college-admin-1',
      auth_user_id: 'auth-college-admin-1',
      full_name: 'Registrar K. Ramesh',
      email: 'registrar@campus.edu',
      phone: '+91 98765 43250',
      department_id: 'dept-cse',
      department_name: 'Central Administration & Records',
      role: 'COLLEGE_ADMIN',
      status: 'ACTIVE',
      password: 'password123',
      created_at: '2019-01-01T09:00:00Z',
      updated_at: '2026-01-01T09:00:00Z'
    },
    {
      id: 'usr-super-admin-1',
      auth_user_id: 'auth-super-admin-1',
      full_name: 'CampusOS Systems Engineer',
      email: 'sysadmin@campus.edu',
      phone: '+91 98765 43299',
      department_id: 'dept-cse',
      department_name: 'IT Systems Infrastructure',
      role: 'SUPER_ADMIN',
      status: 'ACTIVE',
      password: 'password123',
      created_at: '2018-01-01T09:00:00Z',
      updated_at: '2026-01-01T09:00:00Z'
    }
  ];

  const notices: Notice[] = [
    {
      id: 'ntc-101',
      title: 'Mid-Term Examination Schedule & Hall Allocations Announced',
      body: 'The VI Semester Mid-Term Examination begins on October 15, 2026. Hall tickets will be issued through student portal. Check assigned exam block and seating arrangement 20 minutes prior to exam.',
      audience: 'STUDENTS',
      department_id: 'dept-cse',
      department_name: 'Computer Science & Engineering',
      priority: 'ACADEMIC',
      published_at: '2026-10-02T08:30:00Z',
      expires_at: '2026-10-25T18:00:00Z',
      created_by: 'usr-faculty-1',
      author_name: 'Dr. Arvind Venkat',
      pinned: true
    },
    {
      id: 'ntc-102',
      title: 'Urgent: Submission Deadline for Final Year Capstone Project Abstracts',
      body: 'All 7th/8th semester engineering students must submit their project supervisor approval forms and abstracts by October 12, 5:00 PM at the department office.',
      audience: 'DEPARTMENT',
      department_id: 'dept-cse',
      department_name: 'Computer Science & Engineering',
      priority: 'URGENT',
      published_at: '2026-10-01T11:00:00Z',
      expires_at: '2026-10-13T17:00:00Z',
      created_by: 'usr-dept-admin-1',
      author_name: 'Dr. Meenakshi Sundaram (HOD)',
      pinned: true
    },
    {
      id: 'ntc-103',
      title: 'Annual Campus Hackathon 2026 — Registration Now Open',
      body: 'Registrations are open for the 36-hour inter-departmental Hackathon. Industry judges and cash prizes for top 3 teams. Every participant must present their validated QR ticket at entrance.',
      audience: 'ALL',
      priority: 'NORMAL',
      published_at: '2026-09-28T09:00:00Z',
      created_by: 'usr-organizer-1',
      author_name: 'Priya Nair (Club Lead)'
    },
    {
      id: 'ntc-104',
      title: 'Campus Wi-Fi Maintenance & Certificate Renewal',
      body: 'Scheduled network maintenance on Central Academic Block routers on Saturday between 02:00 AM and 05:00 AM. Internet access may experience brief intermittent drops.',
      audience: 'ALL',
      priority: 'NORMAL',
      published_at: '2026-09-25T14:00:00Z',
      created_by: 'usr-super-admin-1',
      author_name: 'CampusOS Systems Engineer'
    }
  ];

  const events: CampusEvent[] = [
    {
      id: 'evt-hack-2026',
      title: 'HackCampus 2026: 36-Hour National Hackathon',
      description: 'The flagship annual hackathon bringing together 200+ collegiate engineers to build production-grade solutions across AI, Cloud, Embedded Systems, and Clean Energy.',
      location: 'Auditorium Complex & Tech Innovation Labs',
      category: 'HACKATHON',
      start_at: '2026-10-18T09:00:00Z',
      end_at: '2026-10-19T21:00:00Z',
      registration_open_at: '2026-09-20T00:00:00Z',
      registration_close_at: '2026-10-16T23:59:59Z',
      capacity: 150,
      registered_count: 2,
      checked_in_count: 0,
      status: 'REGISTRATION_OPEN',
      organizer_id: 'usr-organizer-1',
      organizer_name: 'Priya Nair',
      department_id: 'dept-cse',
      department_name: 'Computer Science & Engineering',
      banner_color: 'from-blue-700 to-indigo-900',
      created_at: '2026-09-18T10:00:00Z',
      updated_at: '2026-09-20T00:00:00Z'
    },
    {
      id: 'evt-symp-ai',
      title: 'National Symposium on Generative Systems & Robotics',
      description: 'Keynotes from leading industry researchers, peer-reviewed paper presentations, and live robotics demonstrations by university labs.',
      location: 'Main Seminar Hall 1, Sir MV Block',
      category: 'SYMPOSIUM',
      start_at: '2026-10-22T09:30:00Z',
      end_at: '2026-10-22T17:30:00Z',
      registration_open_at: '2026-09-25T00:00:00Z',
      registration_close_at: '2026-10-20T23:59:59Z',
      capacity: 80,
      registered_count: 1,
      checked_in_count: 0,
      status: 'REGISTRATION_OPEN',
      organizer_id: 'usr-organizer-1',
      organizer_name: 'Priya Nair',
      department_id: 'dept-cse',
      department_name: 'Computer Science & Engineering',
      banner_color: 'from-emerald-700 to-teal-900',
      created_at: '2026-09-22T10:00:00Z',
      updated_at: '2026-09-25T00:00:00Z'
    },
    {
      id: 'evt-ws-cloud',
      title: 'Hands-on Cloud Infrastructure & Kubernetes Workshop',
      description: 'Full-day interactive lab session on Docker containerization, cluster orchestration, Helm charts, and continuous deployment pipelines.',
      location: 'CSE Systems Lab 4, 3rd Floor',
      category: 'WORKSHOP',
      start_at: '2026-10-28T10:00:00Z',
      end_at: '2026-10-28T16:00:00Z',
      registration_open_at: '2026-10-01T00:00:00Z',
      registration_close_at: '2026-10-26T18:00:00Z',
      capacity: 45,
      registered_count: 0,
      checked_in_count: 0,
      status: 'REGISTRATION_OPEN',
      organizer_id: 'usr-organizer-1',
      organizer_name: 'Priya Nair',
      department_id: 'dept-cse',
      department_name: 'Computer Science & Engineering',
      banner_color: 'from-amber-700 to-orange-900',
      created_at: '2026-09-30T10:00:00Z',
      updated_at: '2026-10-01T00:00:00Z'
    },
    {
      id: 'evt-guest-embedded',
      title: 'Distinguished Lecture: Low-Power RISC-V SoC Architecture',
      description: 'Invited talk by Principal Architect on custom instruction extensions, memory hierarchy, and real-time automotive microcontrollers.',
      location: 'ECE Seminar Hall, 2nd Floor',
      category: 'GUEST_LECTURE',
      start_at: '2026-11-05T14:00:00Z',
      end_at: '2026-11-05T16:30:00Z',
      registration_open_at: '2026-10-10T00:00:00Z',
      registration_close_at: '2026-11-03T23:59:59Z',
      capacity: 120,
      registered_count: 0,
      checked_in_count: 0,
      status: 'PUBLISHED',
      organizer_id: 'usr-organizer-1',
      organizer_name: 'Priya Nair',
      department_id: 'dept-ece',
      department_name: 'Electronics & Communication Engineering',
      banner_color: 'from-purple-800 to-indigo-950',
      created_at: '2026-10-01T14:00:00Z',
      updated_at: '2026-10-01T14:00:00Z'
    }
  ];

  const registrations: EventRegistration[] = [
    {
      id: 'reg-101',
      event_id: 'evt-hack-2026',
      event_title: 'HackCampus 2026: 36-Hour National Hackathon',
      event_location: 'Auditorium Complex & Tech Innovation Labs',
      event_start_at: '2026-10-18T09:00:00Z',
      student_id: 'usr-student-1',
      student_name: 'Rahul Sharma',
      student_email: 'rahul.cs22@campus.edu',
      student_usn: '1CS22CS089',
      department_name: 'Computer Science & Engineering',
      year: 3,
      semester: 6,
      status: 'CONFIRMED',
      registered_at: '2026-09-21T14:22:10Z'
    },
    {
      id: 'reg-102',
      event_id: 'evt-hack-2026',
      event_title: 'HackCampus 2026: 36-Hour National Hackathon',
      event_location: 'Auditorium Complex & Tech Innovation Labs',
      event_start_at: '2026-10-18T09:00:00Z',
      student_id: 'usr-student-2',
      student_name: 'Ananya Deshmukh',
      student_email: 'ananya.ec23@campus.edu',
      student_usn: '1EC23EC014',
      department_name: 'Electronics & Communication Engineering',
      year: 2,
      semester: 4,
      status: 'CONFIRMED',
      registered_at: '2026-09-22T09:15:30Z'
    },
    {
      id: 'reg-103',
      event_id: 'evt-symp-ai',
      event_title: 'National Symposium on Generative Systems & Robotics',
      event_location: 'Main Seminar Hall 1, Sir MV Block',
      event_start_at: '2026-10-22T09:30:00Z',
      student_id: 'usr-student-1',
      student_name: 'Rahul Sharma',
      student_email: 'rahul.cs22@campus.edu',
      student_usn: '1CS22CS089',
      department_name: 'Computer Science & Engineering',
      year: 3,
      semester: 6,
      status: 'CONFIRMED',
      registered_at: '2026-09-26T11:40:00Z'
    }
  ];

  const tickets: Ticket[] = [
    {
      id: 'tkt-101',
      registration_id: 'reg-101',
      event_id: 'evt-hack-2026',
      event_title: 'HackCampus 2026: 36-Hour National Hackathon',
      event_location: 'Auditorium Complex & Tech Innovation Labs',
      event_start_at: '2026-10-18T09:00:00Z',
      student_id: 'usr-student-1',
      student_name: 'Rahul Sharma',
      student_email: 'rahul.cs22@campus.edu',
      student_usn: '1CS22CS089',
      department_name: 'Computer Science & Engineering',
      public_ticket_id: 'TKT-2026-HK9B-7A21',
      status: 'ISSUED',
      issued_at: '2026-09-21T14:22:11Z'
    },
    {
      id: 'tkt-102',
      registration_id: 'reg-102',
      event_id: 'evt-hack-2026',
      event_title: 'HackCampus 2026: 36-Hour National Hackathon',
      event_location: 'Auditorium Complex & Tech Innovation Labs',
      event_start_at: '2026-10-18T09:00:00Z',
      student_id: 'usr-student-2',
      student_name: 'Ananya Deshmukh',
      student_email: 'ananya.ec23@campus.edu',
      student_usn: '1EC23EC014',
      department_name: 'Electronics & Communication Engineering',
      public_ticket_id: 'TKT-2026-AN8C-3F19',
      status: 'ISSUED',
      issued_at: '2026-09-22T09:15:31Z'
    },
    {
      id: 'tkt-103',
      registration_id: 'reg-103',
      event_id: 'evt-symp-ai',
      event_title: 'National Symposium on Generative Systems & Robotics',
      event_location: 'Main Seminar Hall 1, Sir MV Block',
      event_start_at: '2026-10-22T09:30:00Z',
      student_id: 'usr-student-1',
      student_name: 'Rahul Sharma',
      student_email: 'rahul.cs22@campus.edu',
      student_usn: '1CS22CS089',
      department_name: 'Computer Science & Engineering',
      public_ticket_id: 'TKT-2026-SY4E-8D52',
      status: 'ISSUED',
      issued_at: '2026-09-26T11:40:01Z'
    }
  ];

  const checkins: CheckInRecord[] = [];

  const schedule: AcademicScheduleItem[] = [
    {
      id: 'sch-1',
      department_id: 'dept-cse',
      department_name: 'Computer Science & Engineering',
      semester: 6,
      section: 'A',
      day_of_week: 'Monday',
      start_time: '09:00 AM',
      end_time: '10:00 AM',
      subject_code: '22CS61',
      subject_name: 'Distributed Systems & Cloud Computing',
      faculty_name: 'Dr. Arvind Venkat',
      room_no: 'LH-302'
    },
    {
      id: 'sch-2',
      department_id: 'dept-cse',
      department_name: 'Computer Science & Engineering',
      semester: 6,
      section: 'A',
      day_of_week: 'Monday',
      start_time: '10:15 AM',
      end_time: '11:15 AM',
      subject_code: '22CS62',
      subject_name: 'Compiler Design & Automata Theory',
      faculty_name: 'Prof. Sandhya Rao',
      room_no: 'LH-302'
    },
    {
      id: 'sch-3',
      department_id: 'dept-cse',
      department_name: 'Computer Science & Engineering',
      semester: 6,
      section: 'A',
      day_of_week: 'Monday',
      start_time: '11:30 AM',
      end_time: '01:30 PM',
      subject_code: '22CSL67',
      subject_name: 'Cloud Computing & DevOps Lab',
      faculty_name: 'Dr. Arvind Venkat & Lab Staff',
      room_no: 'Lab-4'
    },
    {
      id: 'sch-4',
      department_id: 'dept-cse',
      department_name: 'Computer Science & Engineering',
      semester: 6,
      section: 'A',
      day_of_week: 'Tuesday',
      start_time: '09:00 AM',
      end_time: '10:00 AM',
      subject_code: '22CS63',
      subject_name: 'Information & Network Security',
      faculty_name: 'Dr. Meenakshi Sundaram',
      room_no: 'LH-302'
    },
    {
      id: 'sch-5',
      department_id: 'dept-cse',
      department_name: 'Computer Science & Engineering',
      semester: 6,
      section: 'A',
      day_of_week: 'Tuesday',
      start_time: '10:15 AM',
      end_time: '11:15 AM',
      subject_code: '22CS64',
      subject_name: 'Machine Learning & Applications',
      faculty_name: 'Dr. Praveen Nayak',
      room_no: 'LH-302'
    },
    {
      id: 'sch-6',
      department_id: 'dept-cse',
      department_name: 'Computer Science & Engineering',
      semester: 6,
      section: 'A',
      day_of_week: 'Wednesday',
      start_time: '09:00 AM',
      end_time: '10:00 AM',
      subject_code: '22CS61',
      subject_name: 'Distributed Systems & Cloud Computing',
      faculty_name: 'Dr. Arvind Venkat',
      room_no: 'LH-302'
    },
    {
      id: 'sch-7',
      department_id: 'dept-cse',
      department_name: 'Computer Science & Engineering',
      semester: 6,
      section: 'A',
      day_of_week: 'Thursday',
      start_time: '09:00 AM',
      end_time: '10:00 AM',
      subject_code: '22CS62',
      subject_name: 'Compiler Design & Automata Theory',
      faculty_name: 'Prof. Sandhya Rao',
      room_no: 'LH-302'
    },
    {
      id: 'sch-8',
      department_id: 'dept-cse',
      department_name: 'Computer Science & Engineering',
      semester: 6,
      section: 'A',
      day_of_week: 'Friday',
      start_time: '10:15 AM',
      end_time: '12:15 PM',
      subject_code: '22CS65',
      subject_name: 'Capstone Project Evaluation & Seminars',
      faculty_name: 'Faculty Review Committee',
      room_no: 'Seminar Hall 2'
    }
  ];

  const resources: AcademicResource[] = [
    {
      id: 'res-1',
      title: 'Distributed Systems & Cloud Computing — Course Syllabus & Scheme 2026',
      description: 'Official university curriculum document including unit-wise textbook references, examination scheme, and question paper blueprint.',
      resource_type: 'SYLLABUS',
      department_id: 'dept-cse',
      department_name: 'Computer Science & Engineering',
      semester: 6,
      subject_code: '22CS61',
      file_name: '22CS61_Syllabus_Scheme_2026.pdf',
      file_size: '1.4 MB',
      uploaded_by: 'Dr. Arvind Venkat',
      uploaded_at: '2026-08-10T11:00:00Z',
      download_url: '#'
    },
    {
      id: 'res-2',
      title: 'Module 3: Raft & Paxos Consensus Algorithms Lecture Notes',
      description: 'Comprehensive slides and mathematical formalisms covering leader election, log replication, and safety invariants in distributed clusters.',
      resource_type: 'LECTURE_NOTES',
      department_id: 'dept-cse',
      department_name: 'Computer Science & Engineering',
      semester: 6,
      subject_code: '22CS61',
      file_name: 'Module3_Consensus_Raft_Paxos_Notes.pdf',
      file_size: '4.8 MB',
      uploaded_by: 'Dr. Arvind Venkat',
      uploaded_at: '2026-09-15T09:30:00Z',
      download_url: '#'
    },
    {
      id: 'res-3',
      title: 'Cloud Computing & DevOps Lab Manual — Exercises 1 through 8',
      description: 'Step-by-step instructions for Docker multi-stage builds, Kubernetes pod deployment, ingress configuration, and Prometheus metrics scraping.',
      resource_type: 'LAB_MANUAL',
      department_id: 'dept-cse',
      department_name: 'Computer Science & Engineering',
      semester: 6,
      subject_code: '22CSL67',
      file_name: 'DevOps_Lab_Manual_VI_Sem.pdf',
      file_size: '3.2 MB',
      uploaded_by: 'Dr. Arvind Venkat',
      uploaded_at: '2026-08-20T14:15:00Z',
      download_url: '#'
    },
    {
      id: 'res-4',
      title: 'Model Question Papers & Solved Numerical Problems (2023-2025)',
      description: 'Compiled past university examination papers with detailed solutions and marking rubrics for internal and external assessment.',
      resource_type: 'EXAM_PREP',
      department_id: 'dept-cse',
      department_name: 'Computer Science & Engineering',
      semester: 6,
      subject_code: '22CS63',
      file_name: 'Network_Security_Solved_Papers.pdf',
      file_size: '5.1 MB',
      uploaded_by: 'Dr. Meenakshi Sundaram',
      uploaded_at: '2026-09-28T16:00:00Z',
      download_url: '#'
    }
  ];

  const service_requests: CampusServiceRequest[] = [
    {
      id: 'req-201',
      student_id: 'usr-student-1',
      student_name: 'Rahul Sharma',
      student_email: 'rahul.cs22@campus.edu',
      department_name: 'Computer Science & Engineering',
      category: 'DOCUMENT_REQUEST',
      subject: 'Request for Bonafide Certificate for National Internship Portal',
      description: 'Need an official institutional bonafide student status letter signed by the Registrar for submitting Summer 2026 internship application.',
      priority: 'MEDIUM',
      status: 'IN_PROGRESS',
      assigned_to: 'Registrar Office',
      resolution_notes: 'Verified department enrollment. Letter draft generated and queued for registrar stamp.',
      created_at: '2026-10-02T10:15:00Z',
      updated_at: '2026-10-03T11:00:00Z'
    },
    {
      id: 'req-202',
      student_id: 'usr-student-2',
      student_name: 'Ananya Deshmukh',
      student_email: 'ananya.ec23@campus.edu',
      department_name: 'Electronics & Communication Engineering',
      category: 'INFRASTRUCTURE',
      subject: 'Digital Storage Oscilloscope Channel 2 Calibration in ECE Lab 2',
      description: 'DSO Station #4 displays severe DC offset drift on Channel 2 during waveform measurement experiments.',
      priority: 'LOW',
      status: 'RESOLVED',
      assigned_to: 'Lab Maintenance Staff',
      resolution_notes: 'Probe replaced and channel 2 recalibrated against precision function generator reference.',
      created_at: '2026-09-24T14:30:00Z',
      updated_at: '2026-09-26T16:45:00Z'
    }
  ];

  const audit_logs: AuditLog[] = [
    {
      id: 'aud-1',
      actor_user_id: 'usr-super-admin-1',
      actor_name: 'CampusOS Systems Engineer',
      actor_role: 'SUPER_ADMIN',
      action: 'PLATFORM_INITIALIZATION',
      entity_type: 'SYSTEM',
      entity_id: 'SYS-ROOT',
      metadata: { version: '1.0.0', status: 'READY' },
      ip_reference: '127.0.0.1',
      created_at: '2026-09-01T00:00:00Z'
    },
    {
      id: 'aud-2',
      actor_user_id: 'usr-organizer-1',
      actor_name: 'Priya Nair',
      actor_role: 'ORGANIZER',
      action: 'EVENT_PUBLISHED',
      entity_type: 'EVENT',
      entity_id: 'evt-hack-2026',
      metadata: { event_title: 'HackCampus 2026: 36-Hour National Hackathon', capacity: 150 },
      ip_reference: '192.168.1.45',
      created_at: '2026-09-20T00:00:00Z'
    },
    {
      id: 'aud-3',
      actor_user_id: 'usr-student-1',
      actor_name: 'Rahul Sharma',
      actor_role: 'STUDENT',
      action: 'EVENT_REGISTRATION',
      entity_type: 'REGISTRATION',
      entity_id: 'reg-101',
      metadata: { event_id: 'evt-hack-2026', ticket_id: 'tkt-101' },
      ip_reference: '192.168.1.112',
      created_at: '2026-09-21T14:22:10Z'
    }
  ];

  const email_events: EmailEvent[] = [
    {
      id: 'eml-1',
      recipient_email: 'rahul.cs22@campus.edu',
      recipient_name: 'Rahul Sharma',
      template: 'REGISTRATION_CONFIRMED',
      subject: 'Confirmation & Entry Pass: HackCampus 2026',
      related_entity_id: 'reg-101',
      status: 'SENT',
      created_at: '2026-09-21T14:22:12Z'
    }
  ];

  const subjects: CourseSubject[] = [
    {
      id: 'sub-22cs61',
      code: '22CS61',
      name: 'Distributed Systems & Cloud Computing',
      department_id: 'dept-cse',
      semester: 6,
      credits: 4,
      faculty_id: 'usr-faculty-1',
      faculty_name: 'Dr. Arvind Venkat',
      type: 'THEORY'
    },
    {
      id: 'sub-22cs62',
      code: '22CS62',
      name: 'Compiler Design & Automata Theory',
      department_id: 'dept-cse',
      semester: 6,
      credits: 4,
      faculty_id: 'usr-faculty-2',
      faculty_name: 'Prof. Sandhya Rao',
      type: 'THEORY'
    },
    {
      id: 'sub-22cs63',
      code: '22CS63',
      name: 'Information & Network Security',
      department_id: 'dept-cse',
      semester: 6,
      credits: 3,
      faculty_id: 'usr-dept-admin-1',
      faculty_name: 'Dr. Meenakshi Sundaram (HOD)',
      type: 'THEORY'
    },
    {
      id: 'sub-22cs64',
      code: '22CS64',
      name: 'Machine Learning & Applications',
      department_id: 'dept-cse',
      semester: 6,
      credits: 4,
      faculty_id: 'usr-faculty-3',
      faculty_name: 'Dr. Praveen Nayak',
      type: 'THEORY'
    },
    {
      id: 'sub-22csl67',
      code: '22CSL67',
      name: 'Cloud Computing & DevOps Lab',
      department_id: 'dept-cse',
      semester: 6,
      credits: 2,
      faculty_id: 'usr-faculty-1',
      faculty_name: 'Dr. Arvind Venkat',
      type: 'PRACTICAL'
    }
  ];

  const attendance_records: AttendanceRecord[] = [
    {
      id: 'att-1',
      subject_code: '22CS61',
      subject_name: 'Distributed Systems & Cloud Computing',
      student_id: 'usr-student-1',
      student_name: 'Rahul Sharma',
      student_usn: '1CS22CS089',
      date: '2026-10-02',
      session_time: '09:00 AM - 10:00 AM',
      status: 'PRESENT',
      marked_by: 'Dr. Arvind Venkat'
    },
    {
      id: 'att-2',
      subject_code: '22CS61',
      subject_name: 'Distributed Systems & Cloud Computing',
      student_id: 'usr-student-1',
      student_name: 'Rahul Sharma',
      student_usn: '1CS22CS089',
      date: '2026-09-30',
      session_time: '09:00 AM - 10:00 AM',
      status: 'PRESENT',
      marked_by: 'Dr. Arvind Venkat'
    },
    {
      id: 'att-3',
      subject_code: '22CS63',
      subject_name: 'Information & Network Security',
      student_id: 'usr-student-1',
      student_name: 'Rahul Sharma',
      student_usn: '1CS22CS089',
      date: '2026-09-29',
      session_time: '09:00 AM - 10:00 AM',
      status: 'ABSENT',
      marked_by: 'Dr. Meenakshi Sundaram'
    }
  ];

  const leave_applications: LeaveApplication[] = [
    {
      id: 'lv-101',
      student_id: 'usr-student-1',
      student_name: 'Rahul Sharma',
      student_usn: '1CS22CS089',
      department_name: 'Computer Science & Engineering',
      leave_type: 'ON_DUTY',
      start_date: '2026-10-18',
      end_date: '2026-10-19',
      total_days: 2,
      reason: 'Participation in HackCampus 2026 36-hour National Hackathon event as verified attendee.',
      status: 'APPROVED',
      reviewed_by: 'Dr. Arvind Venkat',
      review_comments: 'Sanctioned for collegiate competition representation.',
      created_at: '2026-09-28T10:00:00Z',
      updated_at: '2026-09-29T11:00:00Z'
    },
    {
      id: 'lv-102',
      student_id: 'usr-student-2',
      student_name: 'Ananya Deshmukh',
      student_usn: '1EC23EC014',
      department_name: 'Electronics & Communication Engineering',
      leave_type: 'MEDICAL',
      start_date: '2026-10-10',
      end_date: '2026-10-12',
      total_days: 3,
      reason: 'Severe viral fever and medical recuperation certified by campus health center.',
      status: 'PENDING',
      created_at: '2026-10-03T09:30:00Z',
      updated_at: '2026-10-03T09:30:00Z'
    }
  ];

  const internal_marks: InternalMarksRecord[] = [
    {
      id: 'mrk-1',
      student_id: 'usr-student-1',
      student_name: 'Rahul Sharma',
      student_usn: '1CS22CS089',
      semester: 6,
      subject_code: '22CS61',
      subject_name: 'Distributed Systems & Cloud Computing',
      test1_marks: 28,
      test2_marks: 27,
      assignment_marks: 19,
      total_internal: 47,
      max_marks: 50,
      percentage: 94,
      grade_point: 'O (Outstanding)'
    },
    {
      id: 'mrk-2',
      student_id: 'usr-student-1',
      student_name: 'Rahul Sharma',
      student_usn: '1CS22CS089',
      semester: 6,
      subject_code: '22CS62',
      subject_name: 'Compiler Design & Automata Theory',
      test1_marks: 25,
      test2_marks: 24,
      assignment_marks: 18,
      total_internal: 43,
      max_marks: 50,
      percentage: 86,
      grade_point: 'A+ (Excellent)'
    },
    {
      id: 'mrk-3',
      student_id: 'usr-student-1',
      student_name: 'Rahul Sharma',
      student_usn: '1CS22CS089',
      semester: 6,
      subject_code: '22CS63',
      subject_name: 'Information & Network Security',
      test1_marks: 22,
      test2_marks: 21,
      assignment_marks: 17,
      total_internal: 39,
      max_marks: 50,
      percentage: 78,
      grade_point: 'A (Very Good)'
    },
    {
      id: 'mrk-4',
      student_id: 'usr-student-1',
      student_name: 'Rahul Sharma',
      student_usn: '1CS22CS089',
      semester: 6,
      subject_code: '22CS64',
      subject_name: 'Machine Learning & Applications',
      test1_marks: 29,
      test2_marks: 28,
      assignment_marks: 20,
      total_internal: 49,
      max_marks: 50,
      percentage: 98,
      grade_point: 'O (Outstanding)'
    },
    {
      id: 'mrk-5',
      student_id: 'usr-student-1',
      student_name: 'Rahul Sharma',
      student_usn: '1CS22CS089',
      semester: 6,
      subject_code: '22CSL67',
      subject_name: 'Cloud Computing & DevOps Lab',
      test1_marks: 29,
      test2_marks: 29,
      assignment_marks: 20,
      lab_marks: 48,
      total_internal: 48,
      max_marks: 50,
      percentage: 96,
      grade_point: 'O (Outstanding)'
    }
  ];

  return {
    users,
    departments,
    notices,
    events,
    registrations,
    tickets,
    checkins,
    schedule,
    resources,
    service_requests,
    audit_logs,
    email_events,
    attendance_records,
    leave_applications,
    internal_marks,
    subjects,
    password_requests: [
      {
        id: 'pwd-req-1',
        full_name: 'Rohan Verma',
        email: 'rohan.verma.ec23@gmail.com',
        student_id_or_staff_id: '1EC23EC045',
        department_name: 'Electronics & Communication Engineering',
        semester: 4,
        role: 'STUDENT',
        reason: 'Device formatted, forgot portal password key',
        requested_at: '2026-10-03T11:20:00Z',
        status: 'PENDING'
      },
      {
        id: 'pwd-req-2',
        full_name: 'Shreya Kulkarni',
        email: 'shreya.me22@gmail.com',
        student_id_or_staff_id: '1ME22ME019',
        department_name: 'Mechanical Engineering',
        semester: 6,
        role: 'STUDENT',
        reason: 'Semester re-registration password assistance',
        requested_at: '2026-10-04T07:15:00Z',
        status: 'PENDING'
      }
    ]
  };
}

class CampusDatabase {
  public data: DatabaseSchema;

  constructor() {
    this.data = this.loadDatabase();
  }

  getTickets(): Ticket[] {
    return this.data.tickets;
  }

  getCheckIns(): CheckInRecord[] {
    return this.data.checkins;
  }

  private loadDatabase(): DatabaseSchema {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        const initial = getInitialData();
        if (!parsed.internal_marks || parsed.internal_marks.length === 0) {
          parsed.internal_marks = initial.internal_marks;
        }
        if (!parsed.attendance_records || parsed.attendance_records.length === 0) {
          parsed.attendance_records = initial.attendance_records;
        }
        if (!parsed.leave_applications || parsed.leave_applications.length === 0) {
          parsed.leave_applications = initial.leave_applications;
        }
        if (!parsed.subjects || parsed.subjects.length === 0) {
          parsed.subjects = initial.subjects;
        }
        if (!parsed.password_requests || parsed.password_requests.length === 0) {
          parsed.password_requests = initial.password_requests;
        }
        // Ensure all users have password and new faculty/dean are present
        parsed.users.forEach((u: UserProfile) => {
          if (!u.password) u.password = 'password123';
        });
        const hasDean = parsed.users.some((u: UserProfile) => u.id === 'usr-dean-1');
        if (!hasDean) {
          const deanUser = initial.users.find(u => u.id === 'usr-dean-1');
          if (deanUser) parsed.users.push(deanUser);
        }
        const hasProf2 = parsed.users.some((u: UserProfile) => u.id === 'usr-faculty-2');
        if (!hasProf2) {
          const prof2 = initial.users.find(u => u.id === 'usr-faculty-2');
          if (prof2) parsed.users.push(prof2);
        }
        return parsed;
      }
    } catch (err) {
      console.error('[CampusDatabase] Failed to read database file, initializing fresh:', err);
    }
    const initial = getInitialData();
    this.saveDatabaseSync(initial);
    return initial;
  }

  private saveDatabaseSync(data: DatabaseSchema) {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
    } catch (err) {
      console.error('[CampusDatabase] Failed to write database file:', err);
    }
  }

  private save() {
    this.saveDatabaseSync(this.data);
  }

  // --- Users & Profiles ---
  getUsers(): UserProfile[] {
    return this.data.users;
  }

  getUserById(id: string): UserProfile | undefined {
    return this.data.users.find(u => u.id === id || u.auth_user_id === id);
  }

  getUserByEmail(email: string): UserProfile | undefined {
    return this.data.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  }

  updateUserProfile(id: string, updates: Partial<UserProfile>): UserProfile | null {
    const idx = this.data.users.findIndex(u => u.id === id);
    if (idx === -1) return null;
    this.data.users[idx] = {
      ...this.data.users[idx],
      ...updates,
      updated_at: new Date().toISOString()
    };
    this.save();
    return this.data.users[idx];
  }

  // --- Departments ---
  getDepartments(): Department[] {
    return this.data.departments;
  }

  getDepartmentById(id: string): Department | undefined {
    return this.data.departments.find(d => d.id === id);
  }

  // --- Notices ---
  getNotices(): Notice[] {
    return [...this.data.notices].sort((a, b) => {
      if (a.pinned && !b.pinned) return -1;
      if (!a.pinned && b.pinned) return 1;
      return new Date(b.published_at).getTime() - new Date(a.published_at).getTime();
    });
  }

  createNotice(notice: Omit<Notice, 'id' | 'published_at'>, actor: UserProfile): Notice {
    const newNotice: Notice = {
      id: `ntc-${Date.now()}`,
      ...notice,
      published_at: new Date().toISOString()
    };
    this.data.notices.unshift(newNotice);
    this.logAudit({
      actor_user_id: actor.id,
      actor_name: actor.full_name,
      actor_role: actor.role,
      action: 'NOTICE_CREATED',
      entity_type: 'NOTICE',
      entity_id: newNotice.id,
      metadata: { title: newNotice.title, audience: newNotice.audience }
    });
    this.save();
    return newNotice;
  }

  // --- Events ---
  getEvents(): CampusEvent[] {
    return [...this.data.events].sort(
      (a, b) => new Date(a.start_at).getTime() - new Date(b.start_at).getTime()
    );
  }

  getEventById(id: string): CampusEvent | undefined {
    return this.data.events.find(e => e.id === id);
  }

  createEvent(eventData: Omit<CampusEvent, 'id' | 'registered_count' | 'checked_in_count' | 'created_at' | 'updated_at'>, actor: UserProfile): CampusEvent {
    const newEvent: CampusEvent = {
      id: `evt-${Date.now()}`,
      ...eventData,
      registered_count: 0,
      checked_in_count: 0,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    this.data.events.push(newEvent);
    this.logAudit({
      actor_user_id: actor.id,
      actor_name: actor.full_name,
      actor_role: actor.role,
      action: 'EVENT_CREATED',
      entity_type: 'EVENT',
      entity_id: newEvent.id,
      metadata: { title: newEvent.title, capacity: newEvent.capacity }
    });
    this.save();
    return newEvent;
  }

  updateEventStatus(eventId: string, newStatus: CampusEvent['status'], actor: UserProfile): CampusEvent | null {
    const event = this.data.events.find(e => e.id === eventId);
    if (!event) return null;
    event.status = newStatus;
    event.updated_at = new Date().toISOString();
    this.logAudit({
      actor_user_id: actor.id,
      actor_name: actor.full_name,
      actor_role: actor.role,
      action: 'EVENT_STATUS_CHANGED',
      entity_type: 'EVENT',
      entity_id: eventId,
      metadata: { newStatus }
    });
    this.save();
    return event;
  }

  // --- Registrations & Tickets ---
  getRegistrations(): EventRegistration[] {
    return this.data.registrations;
  }

  getRegistrationsForEvent(eventId: string): EventRegistration[] {
    return this.data.registrations.filter(r => r.event_id === eventId);
  }

  getRegistrationsForStudent(studentId: string): EventRegistration[] {
    return this.data.registrations.filter(r => r.student_id === studentId);
  }

  getTicketsForStudent(studentId: string): Ticket[] {
    return this.data.tickets.filter(t => t.student_id === studentId);
  }

  getTicketById(ticketId: string): Ticket | undefined {
    return this.data.tickets.find(t => t.id === ticketId || t.public_ticket_id === ticketId);
  }

  /**
   * Atomic Registration:
   * 1. Checks event existence & active registration
   * 2. Checks capacity
   * 3. Enforces unique constraint: (event_id, student_id)
   * 4. Issues opaque Ticket (TKT-YYYY-XXXX-XXXX)
   * 5. Atomically increments registered_count
   * 6. Queues transactional email record & audit log
   */
  registerStudentForEvent(eventId: string, student: UserProfile): { success: boolean; error?: string; registration?: EventRegistration; ticket?: Ticket } {
    const event = this.data.events.find(e => e.id === eventId);
    if (!event) {
      return { success: false, error: 'Event does not exist.' };
    }

    if (event.status !== 'REGISTRATION_OPEN' && event.status !== 'PUBLISHED') {
      return { success: false, error: `Registration is currently not open for this event (status: ${event.status}).` };
    }

    const now = new Date().toISOString();
    if (event.registration_close_at && now > event.registration_close_at) {
      return { success: false, error: 'Registration window for this event has closed.' };
    }

    // Unique constraint: event_id + student_id
    const existing = this.data.registrations.find(
      r => r.event_id === eventId && r.student_id === student.id && r.status !== 'CANCELLED'
    );
    if (existing) {
      return { success: false, error: 'You are already registered for this event.' };
    }

    // Check capacity
    const activeRegistrations = this.data.registrations.filter(
      r => r.event_id === eventId && r.status !== 'CANCELLED'
    );
    if (activeRegistrations.length >= event.capacity) {
      return { success: false, error: 'Event capacity is full.' };
    }

    const regId = `reg-${Date.now()}`;
    const newReg: EventRegistration = {
      id: regId,
      event_id: event.id,
      event_title: event.title,
      event_location: event.location,
      event_start_at: event.start_at,
      student_id: student.id,
      student_name: student.full_name,
      student_email: student.email,
      student_usn: student.student_id,
      department_name: student.department_name,
      year: student.year,
      semester: student.semester,
      status: 'CONFIRMED',
      registered_at: now
    };

    // Generate opaque public ticket identifier: TKT-2026-[hex4]-[hex4]
    const randomHex1 = crypto.randomBytes(2).toString('hex').toUpperCase();
    const randomHex2 = crypto.randomBytes(2).toString('hex').toUpperCase();
    const publicTicketId = `TKT-${new Date().getFullYear()}-${randomHex1}-${randomHex2}`;

    const newTicket: Ticket = {
      id: `tkt-${Date.now()}`,
      registration_id: regId,
      event_id: event.id,
      event_title: event.title,
      event_location: event.location,
      event_start_at: event.start_at,
      student_id: student.id,
      student_name: student.full_name,
      student_email: student.email,
      student_usn: student.student_id,
      department_name: student.department_name,
      public_ticket_id: publicTicketId,
      status: 'ISSUED',
      issued_at: now
    };

    // Update state atomically
    this.data.registrations.push(newReg);
    this.data.tickets.push(newTicket);
    event.registered_count = activeRegistrations.length + 1;

    // Transactional email record
    this.data.email_events.push({
      id: `eml-${Date.now()}`,
      recipient_email: student.email,
      recipient_name: student.full_name,
      template: 'REGISTRATION_CONFIRMED',
      subject: `Registration Confirmed: ${event.title}`,
      related_entity_id: regId,
      status: 'SENT',
      created_at: now
    });

    // Audit log
    this.logAudit({
      actor_user_id: student.id,
      actor_name: student.full_name,
      actor_role: student.role,
      action: 'EVENT_REGISTRATION_SUCCESS',
      entity_type: 'EVENT_REGISTRATION',
      entity_id: regId,
      metadata: { event_id: event.id, public_ticket_id: publicTicketId }
    });

    this.save();
    return { success: true, registration: newReg, ticket: newTicket };
  }

  cancelRegistration(registrationId: string, actor: UserProfile): { success: boolean; error?: string } {
    const reg = this.data.registrations.find(r => r.id === registrationId);
    if (!reg) return { success: false, error: 'Registration not found.' };

    if (actor.role === 'STUDENT' && reg.student_id !== actor.id) {
      return { success: false, error: 'Unauthorized to cancel this registration.' };
    }

    if (reg.status === 'CHECKED_IN') {
      return { success: false, error: 'Cannot cancel a registration that has already been checked in.' };
    }

    reg.status = 'CANCELLED';
    reg.cancelled_at = new Date().toISOString();

    // Void corresponding ticket
    const ticket = this.data.tickets.find(t => t.registration_id === registrationId);
    if (ticket) {
      ticket.status = 'VOID';
    }

    // Decrement event registered count
    const event = this.data.events.find(e => e.id === reg.event_id);
    if (event && event.registered_count > 0) {
      event.registered_count -= 1;
    }

    this.logAudit({
      actor_user_id: actor.id,
      actor_name: actor.full_name,
      actor_role: actor.role,
      action: 'REGISTRATION_CANCELLED',
      entity_type: 'EVENT_REGISTRATION',
      entity_id: reg.id,
      metadata: { event_id: reg.event_id }
    });

    this.save();
    return { success: true };
  }

  /**
   * Atomic Check-In:
   * In compliance with PRD & Security Requirements:
   * 1. Looks up ticket by opaque public_ticket_id or id
   * 2. Rejects if ticket not found (404)
   * 3. Checks event matching
   * 4. Enforces RBAC & Organizer event assignment
   * 5. Enforces duplicate check-in protection: ticket_id uniqueness constraint
   * 6. Atomically commits check-in timestamp, updates ticket & registration, logs audit
   */
  atomicCheckIn(
    ticketIdentifier: string,
    eventId: string,
    scannerUser: UserProfile,
    deviceRef: string = 'CampusOS Web Camera Scanner'
  ): CheckInResponse {
    // Clean identifier (trim spaces and strip any URL wrappers)
    const cleanId = ticketIdentifier.trim().replace(/^.*[?&]ticket=/, '');

    const ticket = this.data.tickets.find(
      t => t.public_ticket_id === cleanId || t.id === cleanId
    );

    if (!ticket) {
      return {
        success: false,
        code: 'INVALID_TICKET',
        message: 'Invalid ticket. No matching registration record found in database.'
      };
    }

    // Verify event match
    if (eventId && ticket.event_id !== eventId) {
      const actualEvent = this.data.events.find(e => e.id === ticket.event_id);
      return {
        success: false,
        code: 'EVENT_MISMATCH',
        message: `This ticket belongs to "${actualEvent ? actualEvent.title : ticket.event_id}", not the currently selected event.`
      };
    }

    // Authorization check: User must be an ORGANIZER assigned to the event, or an ADMIN
    const isGlobalAdmin = scannerUser.role === 'COLLEGE_ADMIN' || scannerUser.role === 'SUPER_ADMIN';
    const isDeptAdmin = scannerUser.role === 'DEPARTMENT_ADMIN';
    const isAssignedOrganizer = scannerUser.role === 'ORGANIZER' && (
      (scannerUser.assigned_event_ids && scannerUser.assigned_event_ids.includes(ticket.event_id)) ||
      scannerUser.assigned_event_ids?.length === 0 // or if event organizer match
    );

    if (!isGlobalAdmin && !isDeptAdmin && !isAssignedOrganizer) {
      return {
        success: false,
        code: 'UNAUTHORIZED',
        message: 'You are not authorized to check in attendees for this event.'
      };
    }

    // Check duplicate check-in
    if (ticket.status === 'CHECKED_IN') {
      const existingCheckin = this.data.checkins.find(c => c.ticket_id === ticket.id);
      const timeFormatted = existingCheckin ? new Date(existingCheckin.checked_in_at).toLocaleTimeString() : 'earlier';
      const inspector = existingCheckin?.checked_in_by_name || 'an authorized organizer';
      return {
        success: false,
        code: 'ALREADY_CHECKED_IN',
        message: `DUPLICATE CHECK-IN BLOCKED: This ticket was already checked in at ${timeFormatted} by ${inspector}.`,
        ticket,
        attendee: {
          name: ticket.student_name,
          student_id: ticket.student_usn,
          department: ticket.department_name,
          email: ticket.student_email,
          checked_in_at: existingCheckin?.checked_in_at || ticket.checked_in_at || '',
          checked_in_by_name: inspector
        }
      };
    }

    if (ticket.status === 'VOID') {
      return {
        success: false,
        code: 'INVALID_TICKET',
        message: 'This ticket has been cancelled or voided.'
      };
    }

    // Find registration
    const registration = this.data.registrations.find(r => r.id === ticket.registration_id);
    if (!registration || registration.status !== 'CONFIRMED') {
      return {
        success: false,
        code: 'REGISTRATION_NOT_CONFIRMED',
        message: 'Registration is not in CONFIRMED state.'
      };
    }

    // Commit check-in atomically
    const now = new Date().toISOString();
    ticket.status = 'CHECKED_IN';
    ticket.checked_in_at = now;
    ticket.checked_in_by_name = scannerUser.full_name;

    registration.status = 'CHECKED_IN';
    registration.checked_in_at = now;
    registration.checked_in_by = scannerUser.id;

    const checkInRecord: CheckInRecord = {
      id: `chk-${Date.now()}`,
      ticket_id: ticket.id,
      public_ticket_id: ticket.public_ticket_id,
      event_id: ticket.event_id,
      registration_id: registration.id,
      student_name: ticket.student_name,
      student_usn: ticket.student_usn,
      department_name: ticket.department_name,
      checked_in_by: scannerUser.id,
      checked_in_by_name: scannerUser.full_name,
      checked_in_at: now,
      scanner_device_reference: deviceRef
    };
    this.data.checkins.push(checkInRecord);

    // Increment event checked-in count
    const event = this.data.events.find(e => e.id === ticket.event_id);
    if (event) {
      event.checked_in_count = (event.checked_in_count || 0) + 1;
    }

    // Log audit record
    this.logAudit({
      actor_user_id: scannerUser.id,
      actor_name: scannerUser.full_name,
      actor_role: scannerUser.role,
      action: 'TICKET_CHECKED_IN',
      entity_type: 'CHECKIN',
      entity_id: checkInRecord.id,
      metadata: {
        public_ticket_id: ticket.public_ticket_id,
        student_name: ticket.student_name,
        event_id: ticket.event_id
      }
    });

    this.save();

    return {
      success: true,
      code: 'SUCCESS',
      message: `Verified: ${ticket.student_name} successfully checked in.`,
      ticket,
      attendee: {
        name: ticket.student_name,
        student_id: ticket.student_usn,
        department: ticket.department_name,
        email: ticket.student_email,
        checked_in_at: now,
        checked_in_by_name: scannerUser.full_name
      }
    };
  }

  // --- Academic Schedule ---
  getSchedule(departmentId?: string, semester?: number): AcademicScheduleItem[] {
    let items = this.data.schedule;
    if (departmentId) {
      items = items.filter(s => s.department_id === departmentId);
    }
    if (semester) {
      items = items.filter(s => s.semester === Number(semester));
    }
    return items;
  }

  // --- Academic Resources ---
  getResources(departmentId?: string, semester?: number): AcademicResource[] {
    let items = this.data.resources;
    if (departmentId) {
      items = items.filter(r => r.department_id === departmentId);
    }
    if (semester) {
      items = items.filter(r => r.semester === Number(semester));
    }
    return items;
  }

  createResource(resourceData: Omit<AcademicResource, 'id' | 'uploaded_at'>, actor: UserProfile): AcademicResource {
    const newRes: AcademicResource = {
      id: `res-${Date.now()}`,
      ...resourceData,
      uploaded_at: new Date().toISOString()
    };
    this.data.resources.push(newRes);
    this.logAudit({
      actor_user_id: actor.id,
      actor_name: actor.full_name,
      actor_role: actor.role,
      action: 'ACADEMIC_RESOURCE_UPLOADED',
      entity_type: 'ACADEMIC_RESOURCE',
      entity_id: newRes.id,
      metadata: { title: newRes.title, subject_code: newRes.subject_code }
    });
    this.save();
    return newRes;
  }

  // --- Service Requests ---
  getServiceRequests(studentId?: string): CampusServiceRequest[] {
    if (studentId) {
      return this.data.service_requests.filter(r => r.student_id === studentId);
    }
    return this.data.service_requests;
  }

  createServiceRequest(requestData: Omit<CampusServiceRequest, 'id' | 'created_at' | 'updated_at'>, actor: UserProfile): CampusServiceRequest {
    const newReq: CampusServiceRequest = {
      id: `req-${Date.now()}`,
      ...requestData,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    this.data.service_requests.unshift(newReq);
    this.logAudit({
      actor_user_id: actor.id,
      actor_name: actor.full_name,
      actor_role: actor.role,
      action: 'SERVICE_REQUEST_SUBMITTED',
      entity_type: 'SERVICE_REQUEST',
      entity_id: newReq.id,
      metadata: { subject: newReq.subject, category: newReq.category }
    });
    this.save();
    return newReq;
  }

  updateServiceRequest(requestId: string, updates: Partial<CampusServiceRequest>, actor: UserProfile): CampusServiceRequest | null {
    const req = this.data.service_requests.find(r => r.id === requestId);
    if (!req) return null;
    Object.assign(req, updates, { updated_at: new Date().toISOString() });
    this.logAudit({
      actor_user_id: actor.id,
      actor_name: actor.full_name,
      actor_role: actor.role,
      action: 'SERVICE_REQUEST_UPDATED',
      entity_type: 'SERVICE_REQUEST',
      entity_id: requestId,
      metadata: { status: req.status, resolution_notes: req.resolution_notes }
    });
    this.save();
    return req;
  }

  // --- Audit Logs ---
  getAuditLogs(limit: number = 50): AuditLog[] {
    return [...this.data.audit_logs]
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      .slice(0, limit);
  }

  logAudit(entry: Omit<AuditLog, 'id' | 'created_at'>): AuditLog {
    const newLog: AuditLog = {
      id: `aud-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      ...entry,
      created_at: new Date().toISOString()
    };
    this.data.audit_logs.unshift(newLog);
    return newLog;
  }

  // --- College ERP Methods (Ansarimajid/College-ERP Inspired) ---

  getSubjects(departmentId?: string, semester?: number): CourseSubject[] {
    let list = this.data.subjects || [];
    if (departmentId) list = list.filter(s => s.department_id === departmentId);
    if (semester) list = list.filter(s => s.semester === Number(semester));
    return list;
  }

  getStudentAttendanceSummary(studentId: string): SubjectAttendanceSummary[] {
    const defaultSubjects: SubjectAttendanceSummary[] = [
      {
        subject_code: '22CS61',
        subject_name: 'Distributed Systems & Cloud Computing',
        faculty_name: 'Dr. Arvind Venkat',
        total_classes: 42,
        attended_classes: 38,
        percentage: 90.5,
        status: 'ELIGIBLE',
        min_required_percentage: 75
      },
      {
        subject_code: '22CS62',
        subject_name: 'Compiler Design & Automata Theory',
        faculty_name: 'Prof. Sandhya Rao',
        total_classes: 36,
        attended_classes: 31,
        percentage: 86.1,
        status: 'ELIGIBLE',
        min_required_percentage: 75
      },
      {
        subject_code: '22CS63',
        subject_name: 'Information & Network Security',
        faculty_name: 'Dr. Meenakshi Sundaram (HOD)',
        total_classes: 35,
        attended_classes: 25,
        percentage: 71.4,
        status: 'SHORTAGE_WARNING',
        min_required_percentage: 75
      },
      {
        subject_code: '22CS64',
        subject_name: 'Machine Learning & Applications',
        faculty_name: 'Dr. Praveen Nayak',
        total_classes: 40,
        attended_classes: 34,
        percentage: 85.0,
        status: 'ELIGIBLE',
        min_required_percentage: 75
      },
      {
        subject_code: '22CSL67',
        subject_name: 'Cloud Computing & DevOps Lab',
        faculty_name: 'Dr. Arvind Venkat',
        total_classes: 20,
        attended_classes: 18,
        percentage: 90.0,
        status: 'ELIGIBLE',
        min_required_percentage: 75
      }
    ];
    return defaultSubjects;
  }

  getClassAttendanceRegister(subjectCode: string, date: string): AttendanceRecord[] {
    return (this.data.attendance_records || []).filter(
      a => a.subject_code === subjectCode && a.date === date
    );
  }

  markClassAttendance(records: Omit<AttendanceRecord, 'id'>[], actor: UserProfile) {
    if (!this.data.attendance_records) {
      this.data.attendance_records = [];
    }
    const newRecords = records.map((r, i) => ({
      ...r,
      id: `att-${Date.now()}-${i}`
    }));
    this.data.attendance_records.push(...newRecords);
    this.logAudit({
      actor_user_id: actor.id,
      actor_name: actor.full_name,
      actor_role: actor.role,
      action: 'ATTENDANCE_MARKED',
      entity_type: 'ATTENDANCE_SESSION',
      entity_id: records[0]?.subject_code || 'CLASS',
      metadata: { total_students: records.length, date: records[0]?.date }
    });
    this.save();
    return newRecords;
  }

  getLeaveApplications(studentId?: string): LeaveApplication[] {
    let list = this.data.leave_applications || [];
    if (studentId) {
      list = list.filter(l => l.student_id === studentId);
    }
    return [...list].sort(
      (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    );
  }

  applyLeave(
    app: Omit<LeaveApplication, 'id' | 'status' | 'created_at' | 'updated_at'>,
    actor: UserProfile
  ): LeaveApplication {
    if (!this.data.leave_applications) {
      this.data.leave_applications = [];
    }
    const now = new Date().toISOString();
    const newApp: LeaveApplication = {
      ...app,
      id: `lv-${Date.now()}`,
      status: 'PENDING',
      created_at: now,
      updated_at: now
    };
    this.data.leave_applications.unshift(newApp);
    this.logAudit({
      actor_user_id: actor.id,
      actor_name: actor.full_name,
      actor_role: actor.role,
      action: 'LEAVE_APPLIED',
      entity_type: 'LEAVE',
      entity_id: newApp.id,
      metadata: { leave_type: newApp.leave_type, days: newApp.total_days }
    });
    this.save();
    return newApp;
  }

  reviewLeave(
    leaveId: string,
    status: 'APPROVED' | 'REJECTED',
    comments: string,
    reviewer: UserProfile
  ): LeaveApplication | null {
    const app = (this.data.leave_applications || []).find(l => l.id === leaveId);
    if (!app) return null;
    app.status = status;
    app.reviewed_by = reviewer.full_name;
    app.review_comments = comments;
    app.updated_at = new Date().toISOString();
    this.logAudit({
      actor_user_id: reviewer.id,
      actor_name: reviewer.full_name,
      actor_role: reviewer.role,
      action: `LEAVE_${status}`,
      entity_type: 'LEAVE',
      entity_id: leaveId,
      metadata: { student_id: app.student_id, comments }
    });
    this.save();
    return app;
  }

  getInternalMarksForStudent(studentId: string): InternalMarksRecord[] {
    return (this.data.internal_marks || []).filter(
      m => m.student_id === studentId || m.student_id === 'usr-student-1'
    );
  }

  // --- Password Recovery & Administration ---
  getPasswordRequests(): PasswordResetRequest[] {
    if (!this.data.password_requests) {
      this.data.password_requests = [];
    }
    return [...this.data.password_requests].sort(
      (a, b) => new Date(b.requested_at).getTime() - new Date(a.requested_at).getTime()
    );
  }

  createPasswordRequest(
    req: Omit<PasswordResetRequest, 'id' | 'requested_at' | 'status'>
  ): PasswordResetRequest {
    if (!this.data.password_requests) {
      this.data.password_requests = [];
    }
    const newReq: PasswordResetRequest = {
      ...req,
      id: `pwd-req-${Date.now()}`,
      requested_at: new Date().toISOString(),
      status: 'PENDING'
    };
    this.data.password_requests.unshift(newReq);
    const mappedRole: UserRole = req.role === 'ADMIN' ? 'COLLEGE_ADMIN' : req.role;
    this.logAudit({
      actor_user_id: 'SYSTEM_ANONYMOUS',
      actor_name: req.full_name,
      actor_role: mappedRole,
      action: 'PASSWORD_RESET_REQUESTED',
      entity_type: 'CREDENTIAL_RECOVERY',
      entity_id: newReq.id,
      metadata: {
        email: req.email,
        department: req.department_name,
        semester: req.semester,
        student_id: req.student_id_or_staff_id
      }
    });
    this.save();
    return newReq;
  }

  dispatchRandomPassword(
    requestId: string,
    adminUser: UserProfile
  ): {
    success: boolean;
    generated_password: string;
    request: PasswordResetRequest;
    targetUser?: UserProfile;
    message: string;
  } {
    const req = (this.data.password_requests || []).find(r => r.id === requestId);
    if (!req) {
      throw new Error('Password reset request not found');
    }

    // Generate clean, secure randomized temporary password (e.g. Campus#7bK9m2)
    const randomChars = Math.random().toString(36).substring(2, 6).toUpperCase();
    const randomDigits = Math.floor(100 + Math.random() * 900);
    const generatedPassword = `Campus#${randomChars}${randomDigits}!`;

    const now = new Date().toISOString();
    req.status = 'DISPATCHED';
    req.generated_password = generatedPassword;
    req.dispatched_at = now;
    req.dispatched_by = adminUser.full_name;

    // Find target user by email or student ID and update their active password
    const targetEmail = req.email.toLowerCase().trim();
    const targetId = (req.student_id_or_staff_id || '').toLowerCase().trim();

    let matchedUser = this.data.users.find(u => 
      u.email.toLowerCase() === targetEmail ||
      (targetId && u.student_id && u.student_id.toLowerCase() === targetId)
    );

    if (matchedUser) {
      matchedUser.password = generatedPassword;
      matchedUser.updated_at = now;
    }

    // Log email event dispatched to student Gmail
    const emailEvent: EmailEvent = {
      id: `eml-pwd-${Date.now()}`,
      recipient_email: req.email,
      recipient_name: req.full_name,
      template: 'PASSWORD_RESET',
      subject: `[CampusOS] Temporary Portal Credentials for Semester ${req.semester || 'Academic'}`,
      related_entity_id: req.id,
      status: 'SENT',
      created_at: now
    };
    this.data.email_events.push(emailEvent);

    // Audit log
    this.logAudit({
      actor_user_id: adminUser.id,
      actor_name: adminUser.full_name,
      actor_role: adminUser.role,
      action: 'ADMIN_PASSWORD_DISPATCH',
      entity_type: 'CREDENTIAL_RECOVERY',
      entity_id: req.id,
      metadata: {
        dispatched_to: req.email,
        student_id: req.student_id_or_staff_id,
        department: req.department_name,
        semester: req.semester,
        matched_user_id: matchedUser?.id
      }
    });

    this.save();
    return {
      success: true,
      generated_password: generatedPassword,
      request: req,
      targetUser: matchedUser,
      message: `Password ${generatedPassword} successfully generated and dispatched to ${req.email}`
    };
  }

  updateUserPassword(userId: string, newPassword: string): { success: boolean; message: string } {
    const user = this.getUserById(userId);
    if (!user) {
      throw new Error('User not found');
    }
    user.password = newPassword;
    user.updated_at = new Date().toISOString();

    this.logAudit({
      actor_user_id: user.id,
      actor_name: user.full_name,
      actor_role: user.role,
      action: 'USER_PASSWORD_CHANGED',
      entity_type: 'AUTH_SESSION',
      entity_id: user.id,
      metadata: { email: user.email }
    });

    this.save();
    return { success: true, message: 'Password updated successfully' };
  }
}

export const db = new CampusDatabase();
