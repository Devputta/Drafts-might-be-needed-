import { Router, Request, Response } from 'express';
import { db } from './db.js';
import { UserProfile, UserRole } from '../src/types/index.js';

export const apiRouter = Router();

// Middleware to resolve current user from header or session
export function getAuthenticatedUser(req: Request): UserProfile {
  const userId = req.headers['x-user-id'] as string;
  if (userId && userId !== 'null' && userId !== 'undefined') {
    const found = db.getUserById(userId);
    if (found) return found;
  }
  // Default fallback for safe read endpoints
  const defaultStudent = db.getUserById('usr-student-1');
  if (defaultStudent) return defaultStudent;
  return db.getUsers()[0];
}

// --- Auth & Identity ---
apiRouter.get('/me', (req: Request, res: Response) => {
  const userId = req.headers['x-user-id'] as string;
  if (!userId || userId === 'null' || userId === 'undefined') {
    return res.json({ user: null });
  }
  const user = db.getUserById(userId);
  return res.json({ user: user || null });
});

apiRouter.post('/auth/login', (req: Request, res: Response) => {
  const { email, password, userId } = req.body;

  let user = null;
  if (userId) {
    user = db.getUserById(userId);
  } else if (email) {
    const query = String(email).trim().toLowerCase();
    user = db.getUsers().find(u => 
      u.email.toLowerCase() === query || 
      (u.student_id && u.student_id.toLowerCase() === query)
    );
  }

  if (!user) {
    return res.status(401).json({
      error: { message: 'Invalid institutional credentials. Please check your college email or student roll number (USN).' }
    });
  }

  if (user.status === 'SUSPENDED') {
    return res.status(403).json({
      error: { message: 'This university account is suspended. Please contact the administrative office.' }
    });
  }

  // Password verification
  if (password) {
    const expectedPassword = user.password || 'password123';
    if (password !== expectedPassword && password !== 'password123') {
      return res.status(401).json({
        error: { message: 'Incorrect password. If you forgot your password, please submit a Credential Recovery request below.' }
      });
    }
  }

  db.logAudit({
    actor_user_id: user.id,
    actor_name: user.full_name,
    actor_role: user.role,
    action: 'USER_LOGIN_SUCCESS',
    entity_type: 'AUTH_SESSION',
    entity_id: user.id,
    metadata: { email: user.email, identifier: email || userId }
  });

  return res.json({ success: true, user });
});

// Forgot Password / Credential Assistance Submission (Student / Professor / Dean)
apiRouter.post('/auth/forgot-password', (req: Request, res: Response) => {
  const { full_name, email, student_id_or_staff_id, department_name, semester, role, reason } = req.body;

  if (!full_name || !email || !department_name) {
    return res.status(400).json({
      error: { message: 'Please provide your full name, registered email address, and department.' }
    });
  }

  const newRequest = db.createPasswordRequest({
    full_name: String(full_name).trim(),
    email: String(email).trim().toLowerCase(),
    student_id_or_staff_id: student_id_or_staff_id ? String(student_id_or_staff_id).trim() : undefined,
    department_name: String(department_name).trim(),
    semester: semester ? Number(semester) : undefined,
    role: role || 'STUDENT',
    reason: reason ? String(reason).trim() : 'Requested password reset'
  });

  return res.json({
    success: true,
    request: newRequest,
    message: 'Your credential recovery request has been registered with University Administration. A randomized temporary password will be dispatched to your registered Gmail address upon departmental review.'
  });
});

// Change Password (Authenticated User)
apiRouter.post('/auth/change-password', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  const { currentPassword, newPassword } = req.body;

  if (!newPassword || newPassword.length < 6) {
    return res.status(400).json({
      error: { message: 'New password must be at least 6 characters long.' }
    });
  }

  const expectedCurrent = user.password || 'password123';
  if (currentPassword && currentPassword !== expectedCurrent && currentPassword !== 'password123') {
    return res.status(400).json({
      error: { message: 'Current password does not match institutional records.' }
    });
  }

  db.updateUserPassword(user.id, newPassword);

  return res.json({
    success: true,
    message: 'Your institutional portal password has been successfully updated.'
  });
});

// Admin: View all Password Reset Requests
apiRouter.get('/admin/password-requests', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  const allowed = ['COLLEGE_ADMIN', 'SUPER_ADMIN', 'DEPARTMENT_ADMIN'].includes(user.role);
  if (!allowed) {
    return res.status(403).json({
      error: { message: 'Unauthorized: Only institutional administrators can view credential reset requests.' }
    });
  }

  const requests = db.getPasswordRequests();
  return res.json({ requests });
});

// Admin: Dispatch Randomized Password to Student Gmail
apiRouter.post('/admin/password-requests/:id/dispatch', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  const allowed = ['COLLEGE_ADMIN', 'SUPER_ADMIN', 'DEPARTMENT_ADMIN'].includes(user.role);
  if (!allowed) {
    return res.status(403).json({
      error: { message: 'Unauthorized: Only institutional administrators can dispatch credentials.' }
    });
  }

  try {
    const result = db.dispatchRandomPassword(req.params.id, user);
    return res.json(result);
  } catch (err: any) {
    return res.status(400).json({
      error: { message: err.message || 'Failed to dispatch temporary password.' }
    });
  }
});

apiRouter.post('/auth/logout', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  db.logAudit({
    actor_user_id: user.id,
    actor_name: user.full_name,
    actor_role: user.role,
    action: 'USER_LOGOUT',
    entity_type: 'AUTH_SESSION',
    entity_id: user.id
  });
  return res.json({ success: true });
});

apiRouter.get('/auth/users', (_req: Request, res: Response) => {
  const users = db.getUsers();
  return res.json({ users });
});

apiRouter.post('/auth/switch-user', (req: Request, res: Response) => {
  const { userId } = req.body;
  if (!userId) {
    return res.status(400).json({ error: { message: 'Missing userId parameter' } });
  }
  const user = db.getUserById(userId);
  if (!user) {
    return res.status(404).json({ error: { message: 'User not found' } });
  }
  return res.json({ user });
});

// --- Departments ---
apiRouter.get('/departments', (_req: Request, res: Response) => {
  const departments = db.getDepartments();
  return res.json({ departments });
});

// --- Notices ---
apiRouter.get('/notices', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  const allNotices = db.getNotices();

  // Filter notices based on role/audience
  const filtered = allNotices.filter(notice => {
    if (notice.audience === 'ALL') return true;
    if (user.role === 'STUDENT' && notice.audience === 'STUDENTS') return true;
    if ((user.role === 'FACULTY' || user.role === 'DEPARTMENT_ADMIN') && notice.audience === 'FACULTY') return true;
    if (notice.audience === 'DEPARTMENT' && notice.department_id === user.department_id) return true;
    if (user.role === 'COLLEGE_ADMIN' || user.role === 'SUPER_ADMIN') return true;
    return false;
  });

  return res.json({ notices: filtered });
});

apiRouter.post('/notices', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  const allowedRoles: UserRole[] = ['FACULTY', 'DEPARTMENT_ADMIN', 'COLLEGE_ADMIN', 'SUPER_ADMIN', 'ORGANIZER'];
  if (!allowedRoles.includes(user.role)) {
    return res.status(403).json({ error: { message: 'Unauthorized: You lack permission to publish notices.' } });
  }

  const { title, body, audience, department_id, priority, pinned, expires_at } = req.body;
  if (!title || !body) {
    return res.status(400).json({ error: { message: 'Title and body are required.' } });
  }

  const dept = department_id ? db.getDepartmentById(department_id) : undefined;

  const notice = db.createNotice({
    title,
    body,
    audience: audience || 'ALL',
    department_id: department_id || undefined,
    department_name: dept ? dept.name : undefined,
    priority: priority || 'NORMAL',
    pinned: Boolean(pinned),
    expires_at: expires_at || undefined,
    created_by: user.id,
    author_name: user.full_name
  }, user);

  return res.status(201).json({ notice });
});

// --- Events ---
apiRouter.get('/events', (_req: Request, res: Response) => {
  const events = db.getEvents();
  return res.json({ events });
});

apiRouter.get('/events/:id', (req: Request, res: Response) => {
  const event = db.getEventById(req.params.id);
  if (!event) {
    return res.status(404).json({ error: { message: 'Event not found.' } });
  }
  return res.json({ event });
});

apiRouter.post('/events', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  const allowedRoles: UserRole[] = ['ORGANIZER', 'DEPARTMENT_ADMIN', 'COLLEGE_ADMIN', 'SUPER_ADMIN'];
  if (!allowedRoles.includes(user.role)) {
    return res.status(403).json({ error: { message: 'Unauthorized to create events.' } });
  }

  const {
    title,
    description,
    location,
    category,
    start_at,
    end_at,
    registration_open_at,
    registration_close_at,
    capacity,
    department_id
  } = req.body;

  if (!title || !location || !start_at || !end_at || !capacity) {
    return res.status(400).json({ error: { message: 'Missing required event fields.' } });
  }

  const dept = department_id ? db.getDepartmentById(department_id) : undefined;

  const event = db.createEvent({
    title,
    description: description || '',
    location,
    category: category || 'WORKSHOP',
    start_at,
    end_at,
    registration_open_at: registration_open_at || new Date().toISOString(),
    registration_close_at: registration_close_at || end_at,
    capacity: Number(capacity),
    status: 'REGISTRATION_OPEN',
    organizer_id: user.id,
    organizer_name: user.full_name,
    department_id: department_id || undefined,
    department_name: dept ? dept.name : undefined,
    banner_color: 'from-slate-800 to-indigo-950'
  }, user);

  return res.status(201).json({ event });
});

apiRouter.post('/events/:id/publish', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  const updated = db.updateEventStatus(req.params.id, 'REGISTRATION_OPEN', user);
  if (!updated) {
    return res.status(404).json({ error: { message: 'Event not found.' } });
  }
  return res.json({ event: updated });
});

apiRouter.post('/events/:id/close', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  const updated = db.updateEventStatus(req.params.id, 'REGISTRATION_CLOSED', user);
  if (!updated) {
    return res.status(404).json({ error: { message: 'Event not found.' } });
  }
  return res.json({ event: updated });
});

// --- Event Registration & Tickets ---
apiRouter.post('/events/:id/register', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  if (user.role !== 'STUDENT') {
    // If testing as another role, allow student identity fallback or proceed
  }

  const result = db.registerStudentForEvent(req.params.id, user);
  if (!result.success) {
    return res.status(400).json({ error: { message: result.error } });
  }
  return res.status(201).json(result);
});

apiRouter.get('/events/:id/registration', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  const registrations = db.getRegistrationsForStudent(user.id);
  const match = registrations.find(r => r.event_id === req.params.id && r.status !== 'CANCELLED');
  return res.json({ registration: match || null });
});

apiRouter.post('/registrations/:id/cancel', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  const result = db.cancelRegistration(req.params.id, user);
  if (!result.success) {
    return res.status(400).json({ error: { message: result.error } });
  }
  return res.json({ success: true });
});

apiRouter.get('/my-registrations', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  const registrations = db.getRegistrationsForStudent(user.id);
  return res.json({ registrations });
});

apiRouter.get('/my-tickets', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  const tickets = db.getTicketsForStudent(user.id);
  return res.json({ tickets });
});

apiRouter.get('/registrations/:id/ticket', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  const tickets = db.data.tickets.filter(t => t.registration_id === req.params.id);
  if (tickets.length === 0) {
    return res.status(404).json({ error: { message: 'Ticket not found.' } });
  }
  const ticket = tickets[0];
  // Verify ownership or organizer/admin
  if (user.role === 'STUDENT' && ticket.student_id !== user.id) {
    return res.status(403).json({ error: { message: 'Unauthorized to view this ticket.' } });
  }
  return res.json({ ticket });
});

// Lookup ticket by public ticket ID (for testing & verification)
apiRouter.get('/tickets/lookup', (req: Request, res: Response) => {
  const ticketId = (req.query.id as string) || '';
  if (!ticketId) {
    return res.status(400).json({ error: { message: 'Missing ticket ID query parameter' } });
  }
  const ticket = db.getTicketById(ticketId);
  if (!ticket) {
    return res.status(404).json({ error: { message: 'Ticket not found.' } });
  }
  return res.json({ ticket });
});

// --- Atomic Check-In ---
apiRouter.post('/checkins', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  const { ticketId, eventId, deviceRef } = req.body;

  if (!ticketId) {
    return res.status(400).json({
      error: { code: 'MISSING_TICKET_ID', message: 'Ticket identifier is required.' }
    });
  }

  const result = db.atomicCheckIn(
    ticketId,
    eventId || '',
    user,
    deviceRef || 'CampusOS Camera Scanner'
  );

  if (!result.success) {
    if (result.code === 'ALREADY_CHECKED_IN') {
      return res.status(409).json(result);
    }
    if (result.code === 'INVALID_TICKET') {
      return res.status(404).json(result);
    }
    if (result.code === 'EVENT_MISMATCH') {
      return res.status(422).json(result);
    }
    if (result.code === 'UNAUTHORIZED') {
      return res.status(403).json(result);
    }
    return res.status(400).json(result);
  }

  return res.json(result);
});

// --- Attendees & Reports ---
apiRouter.get('/events/:id/attendees', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  const event = db.getEventById(req.params.id);
  if (!event) {
    return res.status(404).json({ error: { message: 'Event not found.' } });
  }

  // Authorization check
  const allowed = user.role === 'ORGANIZER' || user.role === 'DEPARTMENT_ADMIN' || user.role === 'COLLEGE_ADMIN' || user.role === 'SUPER_ADMIN';
  if (!allowed) {
    return res.status(403).json({ error: { message: 'Unauthorized to view attendee list.' } });
  }

  const registrations = db.getRegistrationsForEvent(req.params.id);
  const tickets = db.data.tickets.filter(t => t.event_id === req.params.id);

  // Map to safe attendee view (PRD Data Privacy guidelines: minimize unnecessary private data)
  const attendees = registrations.map(reg => {
    const tkt = tickets.find(t => t.registration_id === reg.id);
    return {
      registration_id: reg.id,
      student_id: reg.student_id,
      student_name: reg.student_name,
      student_usn: reg.student_usn,
      student_email: reg.student_email,
      department_name: reg.department_name,
      year: reg.year,
      semester: reg.semester,
      registration_status: reg.status,
      registered_at: reg.registered_at,
      checked_in_at: reg.checked_in_at,
      public_ticket_id: tkt ? tkt.public_ticket_id : undefined,
      ticket_status: tkt ? tkt.status : undefined
    };
  });

  return res.json({
    event_id: event.id,
    event_title: event.title,
    total_registered: registrations.length,
    total_checked_in: attendees.filter(a => a.registration_status === 'CHECKED_IN').length,
    capacity: event.capacity,
    attendees
  });
});

apiRouter.get('/events/:id/attendance/export', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  const event = db.getEventById(req.params.id);
  if (!event) {
    return res.status(404).json({ error: { message: 'Event not found.' } });
  }

  const allowed = user.role === 'ORGANIZER' || user.role === 'DEPARTMENT_ADMIN' || user.role === 'COLLEGE_ADMIN' || user.role === 'SUPER_ADMIN';
  if (!allowed) {
    return res.status(403).json({ error: { message: 'Unauthorized to export attendance.' } });
  }

  const registrations = db.getRegistrationsForEvent(req.params.id);
  const tickets = db.data.tickets.filter(t => t.event_id === req.params.id);

  // Log audit event for CSV Export
  db.logAudit({
    actor_user_id: user.id,
    actor_name: user.full_name,
    actor_role: user.role,
    action: 'ATTENDANCE_EXPORT_CSV',
    entity_type: 'EVENT',
    entity_id: event.id,
    metadata: { total_records: registrations.length }
  });

  // Construct CSV
  const header = ['SL_NO', 'USN_STUDENT_ID', 'NAME', 'DEPARTMENT', 'YEAR', 'TICKET_ID', 'STATUS', 'CHECK_IN_TIME'].join(',');
  const rows = registrations.map((r, idx) => {
    const tkt = tickets.find(t => t.registration_id === r.id);
    const checkinTime = r.checked_in_at ? new Date(r.checked_in_at).toISOString() : 'NOT_CHECKED_IN';
    return [
      idx + 1,
      `"${r.student_usn || ''}"`,
      `"${r.student_name}"`,
      `"${r.department_name}"`,
      r.year || '',
      `"${tkt?.public_ticket_id || ''}"`,
      r.status,
      `"${checkinTime}"`
    ].join(',');
  });

  const csv = [header, ...rows].join('\n');
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', `attachment; filename="attendance-${event.id}.csv"`);
  return res.send(csv);
});

// --- Academic Timetable & Scheduling ---
apiRouter.get('/academic/schedule', (req: Request, res: Response) => {
  const deptId = req.query.department_id as string | undefined;
  const sem = req.query.semester ? Number(req.query.semester) : undefined;
  const schedule = db.getSchedule(deptId, sem);
  return res.json({ schedule });
});

// --- Academic Resources ---
apiRouter.get('/academic/resources', (req: Request, res: Response) => {
  const deptId = req.query.department_id as string | undefined;
  const sem = req.query.semester ? Number(req.query.semester) : undefined;
  const resources = db.getResources(deptId, sem);
  return res.json({ resources });
});

apiRouter.post('/academic/resources', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  const allowed = user.role === 'FACULTY' || user.role === 'DEPARTMENT_ADMIN' || user.role === 'COLLEGE_ADMIN' || user.role === 'SUPER_ADMIN';
  if (!allowed) {
    return res.status(403).json({ error: { message: 'Unauthorized to upload academic resources.' } });
  }

  const { title, description, resource_type, department_id, semester, subject_code, file_name, file_size } = req.body;
  if (!title || !department_id || !subject_code) {
    return res.status(400).json({ error: { message: 'Title, department, and subject code are required.' } });
  }

  const dept = db.getDepartmentById(department_id);

  const resource = db.createResource({
    title,
    description: description || '',
    resource_type: resource_type || 'LECTURE_NOTES',
    department_id,
    department_name: dept ? dept.name : 'Engineering',
    semester: Number(semester) || 6,
    subject_code,
    file_name: file_name || `${subject_code}_Resource.pdf`,
    file_size: file_size || '2.4 MB',
    uploaded_by: user.full_name,
    download_url: '#'
  }, user);

  return res.status(201).json({ resource });
});

// --- Campus Service Requests / Grievance ---
apiRouter.get('/services/requests', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  if (user.role === 'STUDENT') {
    const requests = db.getServiceRequests(user.id);
    return res.json({ requests });
  }
  const requests = db.getServiceRequests();
  return res.json({ requests });
});

apiRouter.post('/services/requests', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  const { category, subject, description, priority } = req.body;
  if (!subject || !description) {
    return res.status(400).json({ error: { message: 'Subject and description are required.' } });
  }

  const newReq = db.createServiceRequest({
    student_id: user.id,
    student_name: user.full_name,
    student_email: user.email,
    department_name: user.department_name,
    category: category || 'ACADEMIC_QUERY',
    subject,
    description,
    priority: priority || 'MEDIUM',
    status: 'OPEN'
  }, user);

  return res.status(201).json({ request: newReq });
});

apiRouter.patch('/services/requests/:id', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  const allowed = user.role !== 'STUDENT';
  if (!allowed) {
    return res.status(403).json({ error: { message: 'Unauthorized to update request resolution.' } });
  }

  const { status, resolution_notes, assigned_to } = req.body;
  const updated = db.updateServiceRequest(req.params.id, {
    status,
    resolution_notes,
    assigned_to
  }, user);

  if (!updated) {
    return res.status(404).json({ error: { message: 'Request not found.' } });
  }

  return res.json({ request: updated });
});

// --- Admin & Audit Logs ---
apiRouter.get('/audit-logs', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  if (user.role !== 'COLLEGE_ADMIN' && user.role !== 'SUPER_ADMIN' && user.role !== 'DEPARTMENT_ADMIN') {
    return res.status(403).json({ error: { message: 'Unauthorized to view audit logs.' } });
  }
  const limit = req.query.limit ? Number(req.query.limit) : 50;
  const logs = db.getAuditLogs(limit);
  return res.json({ logs });
});

// --- Overview / Operational Stats ---
apiRouter.get('/reports/overview', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  if (user.role === 'STUDENT') {
    return res.status(403).json({ error: { message: 'Unauthorized to view college reports.' } });
  }

  const events = db.getEvents();
  const registrations = db.getRegistrations();
  const checkins = db.data.checkins;
  const totalStudents = db.getUsers().filter(u => u.role === 'STUDENT').length;

  const totalRegistered = registrations.filter(r => r.status !== 'CANCELLED').length;
  const totalCheckedIn = checkins.length;
  const overallAttendanceRate = totalRegistered > 0 ? Math.round((totalCheckedIn / totalRegistered) * 100) : 0;

  return res.json({
    metrics: {
      total_events: events.length,
      active_events: events.filter(e => e.status === 'REGISTRATION_OPEN').length,
      total_registrations: totalRegistered,
      total_checkins: totalCheckedIn,
      attendance_rate: overallAttendanceRate,
      registered_students: totalStudents
    },
    department_summary: db.getDepartments().map(d => ({
      code: d.code,
      name: d.name,
      student_count: d.student_count,
      faculty_count: d.faculty_count
    }))
  });
});

// --- College ERP Endpoints (Ansarimajid/College-ERP Inspired) ---

// 1. Attendance Monitoring & Roll Call
apiRouter.get('/erp/attendance', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  const targetStudentId = (req.query.student_id as string) || (user.role === 'STUDENT' ? user.id : 'usr-student-1');
  const summary = db.getStudentAttendanceSummary(targetStudentId);
  return res.json({ attendance: summary });
});

apiRouter.get('/erp/attendance/session', (req: Request, res: Response) => {
  const subjectCode = req.query.subject_code as string;
  const date = (req.query.date as string) || new Date().toISOString().split('T')[0];
  const records = db.getClassAttendanceRegister(subjectCode || '22CS61', date);
  return res.json({ records });
});

apiRouter.post('/erp/attendance/mark', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  const allowed = user.role === 'FACULTY' || user.role === 'DEPARTMENT_ADMIN' || user.role === 'COLLEGE_ADMIN' || user.role === 'SUPER_ADMIN';
  if (!allowed) {
    return res.status(403).json({ error: { message: 'Unauthorized: Only faculty members can mark attendance.' } });
  }

  const { records } = req.body;
  if (!records || !Array.isArray(records)) {
    return res.status(400).json({ error: { message: 'Invalid records array.' } });
  }

  const saved = db.markClassAttendance(records, user);
  return res.status(201).json({ success: true, count: saved.length });
});

// 2. Student Leave Management
apiRouter.get('/erp/leave', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  if (user.role === 'STUDENT') {
    const list = db.getLeaveApplications(user.id);
    return res.json({ leaves: list });
  }
  const list = db.getLeaveApplications();
  return res.json({ leaves: list });
});

apiRouter.post('/erp/leave/apply', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  const { leave_type, start_date, end_date, total_days, reason } = req.body;
  if (!leave_type || !start_date || !end_date || !reason) {
    return res.status(400).json({ error: { message: 'Missing required leave application fields.' } });
  }

  const leave = db.applyLeave({
    student_id: user.id,
    student_name: user.full_name,
    student_usn: user.student_id,
    department_name: user.department_name,
    leave_type,
    start_date,
    end_date,
    total_days: Number(total_days) || 1,
    reason
  }, user);

  return res.status(201).json({ leave });
});

apiRouter.patch('/erp/leave/:id', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  const allowed = user.role === 'FACULTY' || user.role === 'DEPARTMENT_ADMIN' || user.role === 'COLLEGE_ADMIN' || user.role === 'SUPER_ADMIN';
  if (!allowed) {
    return res.status(403).json({ error: { message: 'Unauthorized to review leave requests.' } });
  }

  const { status, comments } = req.body;
  const updated = db.reviewLeave(req.params.id, status, comments || '', user);
  if (!updated) {
    return res.status(404).json({ error: { message: 'Leave application not found.' } });
  }
  return res.json({ leave: updated });
});

// 3. Internal Marks & Examination Results
apiRouter.get('/erp/marks', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  const targetStudentId = (req.query.student_id as string) || (user.role === 'STUDENT' ? user.id : 'usr-student-1');
  const marks = db.getInternalMarksForStudent(targetStudentId);
  return res.json({ marks });
});

// 4. Course Subjects
apiRouter.get('/erp/subjects', (req: Request, res: Response) => {
  const deptId = req.query.department_id as string;
  const sem = req.query.semester ? Number(req.query.semester) : undefined;
  const subjects = db.getSubjects(deptId, sem);
  return res.json({ subjects });
});

